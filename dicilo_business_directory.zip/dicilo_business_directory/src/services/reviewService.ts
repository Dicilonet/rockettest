import { supabase } from '../lib/supabase';

export interface ReviewData {
  id: string;
  rating: number;
  comment: string;
  businessId: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  date: string;
  helpful: number;
  notHelpful: number;
  userVoteType?: 'helpful' | 'notHelpful';
}

interface ReviewFromDB {
  id: string;
  rating: number;
  comment: string | null;
  business_id: string;
  user_id: string;
  created_at: string;
  updated_at: string;
  helpful_count: number;
  not_helpful_count: number;
  user_profiles?: {
    full_name: string;
    email: string;
  };
}

const convertReviewToClient = (dbReview: ReviewFromDB): ReviewData => {
  return {
    id: dbReview.id,
    rating: dbReview.rating,
    comment: dbReview.comment || '',
    businessId: dbReview.business_id,
    userId: dbReview.user_id,
    userName: dbReview.user_profiles?.full_name || 'Anonymer Benutzer',
    userAvatar: undefined,
    date: dbReview.created_at,
    helpful: dbReview.helpful_count,
    notHelpful: dbReview.not_helpful_count,
    userVoteType: undefined // Will be determined by separate query if needed
  };
};

export const reviewService = {
  // Get reviews for a business
  async getBusinessReviews(businessId: string): Promise<ReviewData[]> {
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select(`
          *,
          user_profiles(full_name, email)
        `)
        .eq('business_id', businessId)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Database error:', error);
        if (error.code === 'PGRST205' || error.message?.includes('table') || error.message?.includes('schema cache')) {
          throw new Error('Database schema not applied. Please contact support to apply the migration.');
        }
        throw error;
      }

      return (data || []).map(convertReviewToClient);
    } catch (error: any) {
      console.error('Error fetching reviews:', error);
      if (error.message?.includes('Database schema not applied')) {
        throw error;
      }
      return [];
    }
  },

  // Create new review
  async createReview(reviewData: {
    businessId: string;
    rating: number;
    comment: string;
    userId: string;
  }): Promise<{ data: ReviewData | null; error: any }> {
    try {
      const { data, error } = await supabase
        .from('reviews')
        .insert({
          business_id: reviewData.businessId,
          rating: reviewData.rating,
          comment: reviewData.comment,
          user_id: reviewData.userId
        })
        .select(`
          *,
          user_profiles(full_name, email)
        `)
        .single();

      if (error) {
        console.error('Create review error:', error);
        if (error.code === 'PGRST205' || error.message?.includes('table') || error.message?.includes('schema cache')) {
          return { data: null, error: new Error('Database schema not applied. Please contact support to apply the migration.') };
        }
        throw error;
      }

      // Update business rating
      await this.updateBusinessRating(reviewData.businessId);

      return { data: data ? convertReviewToClient(data as ReviewFromDB) : null, error: null };
    } catch (error) {
      console.error('Unexpected error creating review:', error);
      return { data: null, error };
    }
  },

  // Vote on review (helpful/not helpful)
  async voteOnReview(reviewId: string, voteType: 'helpful' | 'notHelpful', userId: string): Promise<{ error: any }> {
    try {
      // Check if user already voted
      const { data: existingVote } = await supabase
        .from('review_votes')
        .select('*')
        .eq('review_id', reviewId)
        .eq('user_id', userId)
        .single();

      if (existingVote) {
        // Update existing vote
        const { error } = await supabase
          .from('review_votes')
          .update({
            is_helpful: voteType === 'helpful'
          })
          .eq('id', existingVote.id);

        if (error) throw error;
      } else {
        // Create new vote
        const { error } = await supabase
          .from('review_votes')
          .insert({
            review_id: reviewId,
            user_id: userId,
            is_helpful: voteType === 'helpful'
          });

        if (error) throw error;
      }

      // Update review vote counts
      await this.updateReviewVoteCounts(reviewId);

      return { error: null };
    } catch (error: any) {
      console.error('Error voting on review:', error);
      if (error.code === 'PGRST205' || error.message?.includes('table') || error.message?.includes('schema cache')) {
        return { error: new Error('Database schema not applied. Please contact support to apply the migration.') };
      }
      return { error };
    }
  },

  // Update review vote counts
  async updateReviewVoteCounts(reviewId: string): Promise<void> {
    try {
      const { data: votes } = await supabase
        .from('review_votes')
        .select('is_helpful')
        .eq('review_id', reviewId);

      if (votes) {
        const helpfulCount = votes.filter(vote => vote.is_helpful).length;
        const notHelpfulCount = votes.filter(vote => !vote.is_helpful).length;

        await supabase
          .from('reviews')
          .update({
            helpful_count: helpfulCount,
            not_helpful_count: notHelpfulCount
          })
          .eq('id', reviewId);
      }
    } catch (error) {
      console.error('Error updating vote counts:', error);
    }
  },

  // Update business rating and review count
  async updateBusinessRating(businessId: string): Promise<void> {
    try {
      const { data: reviews } = await supabase
        .from('reviews')
        .select('rating')
        .eq('business_id', businessId);

      if (reviews && reviews.length > 0) {
        const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
        const averageRating = totalRating / reviews.length;

        await supabase
          .from('businesses')
          .update({
            rating: averageRating,
            review_count: reviews.length
          })
          .eq('id', businessId);
      }
    } catch (error) {
      console.error('Error updating business rating:', error);
    }
  },

  // Delete review (user can delete their own, admin can delete any)
  async deleteReview(reviewId: string, userId: string): Promise<{ error: any }> {
    try {
      const { error } = await supabase
        .from('reviews')
        .delete()
        .eq('id', reviewId)
        .eq('user_id', userId);

      if (error) {
        console.error('Delete review error:', error);
        if (error.code === 'PGRST205' || error.message?.includes('table') || error.message?.includes('schema cache')) {
          return { error: new Error('Database schema not applied. Please contact support to apply the migration.') };
        }
        throw error;
      }

      return { error: null };
    } catch (error) {
      console.error('Unexpected error deleting review:', error);
      return { error };
    }
  }
};