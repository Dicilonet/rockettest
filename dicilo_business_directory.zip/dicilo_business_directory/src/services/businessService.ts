import { supabase } from '../lib/supabase';
import { Business, BusinessImage, OperatingHours, Location, SpecialOffer } from '../pages/business-details/types';

// Helper function to validate UUID format
const isValidUUID = (id: string): boolean => {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(id);
};

interface BusinessFromDB {
  id: string;
  name: string;
  category_id: string | null;
  rating: number;
  review_count: number;
  address: string;
  phone: string | null;
  website: string | null;
  email: string | null;
  description: string | null;
  price_range: string | null;
  verified: boolean;
  status: string;
  latitude: number | null;
  longitude: number | null;
  city: string | null;
  state: string | null;
  zip_code: string | null;
  country: string | null;
  features: string[] | null;
  social_facebook: string | null;
  social_instagram: string | null;
  social_twitter: string | null;
  social_linkedin: string | null;
  created_at: string;
  updated_at: string;
  business_categories?: {
    name: string;
    name_de: string;
  };
  business_images?: Array<{
    id: string;
    url: string;
    alt_text: string;
    is_primary: boolean;
    category: string;
  }>;
  business_hours?: Array<{
    day_of_week: number;
    is_open: boolean;
    open_time: string | null;
    close_time: string | null;
  }>;
  special_offers?: Array<{
    id: string;
    title: string;
    description: string | null;
    discount: string | null;
    valid_until: string | null;
  }>;
}

// Convert snake_case database to camelCase React
const convertBusinessToClient = (dbBusiness: BusinessFromDB): Business => {
  // Convert operating hours
  const operatingHours: OperatingHours = {
    monday: { isOpen: false },
    tuesday: { isOpen: false },
    wednesday: { isOpen: false },
    thursday: { isOpen: false },
    friday: { isOpen: false },
    saturday: { isOpen: false },
    sunday: { isOpen: false }
  };

  const dayMapping = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  
  if (dbBusiness.business_hours) {
    dbBusiness.business_hours.forEach(hour => {
      const dayName = dayMapping[hour.day_of_week] as keyof OperatingHours;
      operatingHours[dayName] = {
        isOpen: hour.is_open,
        openTime: hour.open_time || undefined,
        closeTime: hour.close_time || undefined
      };
    });
  }

  // Convert images
  const images: BusinessImage[] = (dbBusiness.business_images || []).map(img => ({
    id: img.id,
    url: img.url,
    alt: img.alt_text,
    isPrimary: img.is_primary,
    category: img.category as BusinessImage['category']
  }));

  // Convert location
  const location: Location = {
    latitude: dbBusiness.latitude || 0,
    longitude: dbBusiness.longitude || 0,
    city: dbBusiness.city || '',
    state: dbBusiness.state || '',
    zipCode: dbBusiness.zip_code || '',
    country: dbBusiness.country || 'Deutschland'
  };

  // Convert special offers
  const specialOffers: SpecialOffer[] = (dbBusiness.special_offers || []).map(offer => ({
    id: offer.id,
    title: offer.title,
    description: offer.description || '',
    validUntil: offer.valid_until || '',
    discount: offer.discount || undefined
  }));

  return {
    id: dbBusiness.id,
    name: dbBusiness.name,
    category: dbBusiness.business_categories?.name_de || 'Unbekannt',
    rating: dbBusiness.rating,
    reviewCount: dbBusiness.review_count,
    address: dbBusiness.address,
    phone: dbBusiness.phone || '',
    website: dbBusiness.website || undefined,
    email: dbBusiness.email || undefined,
    description: dbBusiness.description || '',
    images,
    operatingHours,
    location,
    socialMedia: {
      facebook: dbBusiness.social_facebook || undefined,
      instagram: dbBusiness.social_instagram || undefined,
      twitter: dbBusiness.social_twitter || undefined,
      linkedin: dbBusiness.social_linkedin || undefined
    },
    features: dbBusiness.features || [],
    priceRange: dbBusiness.price_range || '',
    verified: dbBusiness.verified,
    specialOffers
  };
};

export const businessService = {
  // Get all businesses with proper error handling
  async getAllBusinesses(): Promise<Business[]> {
    try {
      const { data, error } = await supabase
        .from('businesses')
        .select(`
          *,
          business_categories(name, name_de),
          business_images(*),
          business_hours(*),
          special_offers(*)
        `)
        .eq('status', 'active')
        .order('name');

      if (error) {
        console.error('Database error:', error);
        // Check if it's a table not found error
        if (error.code === 'PGRST205' || error.message?.includes('table') || error.message?.includes('schema cache')) {
          throw new Error('Database schema not applied. Please contact support to apply the migration.');
        }
        throw error;
      }

      return (data || []).map(convertBusinessToClient);
    } catch (error: any) {
      console.error('Error fetching businesses:', error);
      if (error.message?.includes('Database schema not applied')) {
        throw error;
      }
      throw new Error('Failed to load businesses. Please try again.');
    }
  },

  // Get business by ID with proper error handling and UUID validation
  async getBusinessById(id: string): Promise<Business | null> {
    // Validate UUID format first
    if (!id || !isValidUUID(id)) {
      throw new Error('Invalid business ID format. Expected a valid UUID.');
    }

    try {
      const { data, error } = await supabase
        .from('businesses').select(`*,business_categories(name, name_de),business_images(*),business_hours(*),special_offers(*)`).eq('id', id)
        .single();

      if (error) {
        console.error('Database error:', error);
        if (error.code === 'PGRST205' || error.message?.includes('table') || error.message?.includes('schema cache')) {
          throw new Error('Database schema not applied. Please contact support to apply the migration.');
        }
        if (error.code === 'PGRST116') {
          return null; // Not found
        }
        // Handle UUID format errors specifically
        if (error.code === '22P02' || error.message?.includes('invalid input syntax for type uuid')) {
          throw new Error('Invalid business ID format. Expected a valid UUID.');
        }
        throw error;
      }

      return data ? convertBusinessToClient(data) : null;
    } catch (error: any) {
      console.error('Error fetching business:', error);
      if (error.message?.includes('Database schema not applied') || error.message?.includes('Invalid business ID format')) {
        throw error;
      }
      return null;
    }
  },

  // Update business (superadmin only) with better error handling and UUID validation
  async updateBusiness(id: string, updates: Partial<Business>): Promise<{ error: any }> {
    // Validate UUID format first
    if (!id || !isValidUUID(id)) {
      return { error: new Error('Invalid business ID format. Expected a valid UUID.') };
    }

    try {
      // Convert camelCase to snake_case for database
      const dbUpdates: any = {};
      
      if (updates.name !== undefined) dbUpdates.name = updates.name;
      if (updates.address !== undefined) dbUpdates.address = updates.address;
      if (updates.phone !== undefined) dbUpdates.phone = updates.phone;
      if (updates.website !== undefined) dbUpdates.website = updates.website;
      if (updates.email !== undefined) dbUpdates.email = updates.email;
      if (updates.description !== undefined) dbUpdates.description = updates.description;
      if (updates.priceRange !== undefined) dbUpdates.price_range = updates.priceRange;
      if (updates.features !== undefined) dbUpdates.features = updates.features;
      if (updates.location?.latitude !== undefined) dbUpdates.latitude = updates.location.latitude;
      if (updates.location?.longitude !== undefined) dbUpdates.longitude = updates.location.longitude;
      if (updates.location?.city !== undefined) dbUpdates.city = updates.location.city;
      if (updates.location?.state !== undefined) dbUpdates.state = updates.location.state;
      if (updates.location?.zipCode !== undefined) dbUpdates.zip_code = updates.location.zipCode;
      if (updates.socialMedia?.facebook !== undefined) dbUpdates.social_facebook = updates.socialMedia.facebook;
      if (updates.socialMedia?.instagram !== undefined) dbUpdates.social_instagram = updates.socialMedia.instagram;

      dbUpdates.updated_at = new Date().toISOString();

      const { error } = await supabase
        .from('businesses')
        .update(dbUpdates)
        .eq('id', id);

      if (error) {
        console.error('Update error:', error);
        if (error.code === 'PGRST205' || error.message?.includes('table') || error.message?.includes('schema cache')) {
          return { error: new Error('Database schema not applied. Please contact support to apply the migration.') };
        }
        // Handle UUID format errors specifically
        if (error.code === '22P02' || error.message?.includes('invalid input syntax for type uuid')) {
          return { error: new Error('Invalid business ID format. Expected a valid UUID.') };
        }
      }

      return { error };
    } catch (error) {
      console.error('Unexpected error:', error);
      return { error };
    }
  },

  // Create new business (admin only) with error handling
  async createBusiness(business: Omit<Business, 'id' | 'rating' | 'reviewCount'>): Promise<{ data: Business | null; error: any }> {
    try {
      const { data, error } = await supabase
        .from('businesses')
        .insert({
          name: business.name,
          address: business.address,
          phone: business.phone || null,
          website: business.website || null,
          email: business.email || null,
          description: business.description,
          price_range: business.priceRange,
          features: business.features,
          latitude: business.location.latitude,
          longitude: business.location.longitude,
          city: business.location.city,
          state: business.location.state,
          zip_code: business.location.zipCode,
          country: business.location.country,
          social_facebook: business.socialMedia?.facebook || null,
          social_instagram: business.socialMedia?.instagram || null,
          verified: business.verified
        })
        .select()
        .single();

      if (error) {
        console.error('Create error:', error);
        if (error.code === 'PGRST205' || error.message?.includes('table') || error.message?.includes('schema cache')) {
          return { data: null, error: new Error('Database schema not applied. Please contact support to apply the migration.') };
        }
        throw error;
      }

      return { data: data ? convertBusinessToClient(data as BusinessFromDB) : null, error: null };
    } catch (error) {
      console.error('Unexpected error:', error);
      return { data: null, error };
    }
  },

  // Delete business (superadmin only) with UUID validation
  async deleteBusiness(id: string): Promise<{ error: any }> {
    // Validate UUID format first
    if (!id || !isValidUUID(id)) {
      return { error: new Error('Invalid business ID format. Expected a valid UUID.') };
    }

    try {
      const { error } = await supabase
        .from('businesses')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Delete error:', error);
        if (error.code === 'PGRST205' || error.message?.includes('table') || error.message?.includes('schema cache')) {
          return { error: new Error('Database schema not applied. Please contact support to apply the migration.') };
        }
        // Handle UUID format errors specifically
        if (error.code === '22P02' || error.message?.includes('invalid input syntax for type uuid')) {
          return { error: new Error('Invalid business ID format. Expected a valid UUID.') };
        }
      }

      return { error };
    } catch (error) {
      console.error('Unexpected error:', error);
      return { error };
    }
  }
};