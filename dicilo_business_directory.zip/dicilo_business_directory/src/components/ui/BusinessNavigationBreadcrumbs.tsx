import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

interface BreadcrumbItem {
  label: string;
  path?: string;
  icon?: string;
}

interface BusinessNavigationBreadcrumbsProps {
  searchQuery?: string;
  businessName?: string;
  category?: string;
  location?: string;
  customItems?: BreadcrumbItem[];
}

const BusinessNavigationBreadcrumbs = ({
  searchQuery,
  businessName,
  category,
  location: searchLocation,
  customItems
}: BusinessNavigationBreadcrumbsProps) => {
  const navigate = useNavigate();
  const location = useLocation();

  const generateBreadcrumbs = (): BreadcrumbItem[] => {
    if (customItems) {
      return customItems;
    }

    const breadcrumbs: BreadcrumbItem[] = [
      {
        label: 'Unternehmen',
        path: '/business-directory',
        icon: 'MapPin'
      }
    ];

    if (location.pathname === '/search-results') {
      if (searchQuery) {
        breadcrumbs.push({
          label: `Suche: "${searchQuery}"`,
          icon: 'Search'
        });
      } else if (category) {
        breadcrumbs.push({
          label: `Kategorie: ${category}`,
          icon: 'Tag'
        });
      } else {
        breadcrumbs.push({
          label: 'Suchergebnisse',
          icon: 'Search'
        });
      }

      if (searchLocation) {
        breadcrumbs.push({
          label: `in ${searchLocation}`,
          icon: 'MapPin'
        });
      }
    }

    if (location.pathname === '/business-details') {
      if (searchQuery || category) {
        breadcrumbs.push({
          label: 'Suchergebnisse',
          path: '/search-results',
          icon: 'Search'
        });
      }

      if (businessName) {
        breadcrumbs.push({
          label: businessName,
          icon: 'Building'
        });
      } else {
        breadcrumbs.push({
          label: 'Unternehmensdetails',
          icon: 'Building'
        });
      }
    }

    return breadcrumbs;
  };

  const breadcrumbs = generateBreadcrumbs();

  if (breadcrumbs.length <= 1) {
    return null;
  }

  const handleBreadcrumbClick = (item: BreadcrumbItem) => {
    if (item.path) {
      navigate(item.path);
    }
  };

  return (
    <nav className="flex items-center space-x-2 py-3 text-sm" aria-label="Breadcrumb">
      <div className="flex items-center space-x-2 overflow-x-auto scrollbar-hide">
        {breadcrumbs.map((item, index) => (
          <React.Fragment key={index}>
            <div className="flex items-center space-x-2 whitespace-nowrap">
              {item.path ? (
                <button
                  onClick={() => handleBreadcrumbClick(item)}
                  className="flex items-center space-x-1 text-muted-foreground hover:text-primary transition-colors duration-200 group"
                >
                  {item.icon && (
                    <Icon 
                      name={item.icon} 
                      size={14} 
                      className="group-hover:text-primary transition-colors duration-200" 
                    />
                  )}
                  <span className="group-hover:underline">{item.label}</span>
                </button>
              ) : (
                <div className="flex items-center space-x-1 text-foreground">
                  {item.icon && (
                    <Icon 
                      name={item.icon} 
                      size={14} 
                      className="text-primary" 
                    />
                  )}
                  <span className="font-medium">{item.label}</span>
                </div>
              )}
            </div>

            {index < breadcrumbs.length - 1 && (
              <Icon 
                name="ChevronRight" 
                size={14} 
                className="text-muted-foreground flex-shrink-0" 
              />
            )}
          </React.Fragment>
        ))}
      </div>

      {/* Mobile Back Button */}
      <div className="md:hidden ml-auto">
        {breadcrumbs.length > 1 && breadcrumbs[breadcrumbs.length - 2].path && (
          <button
            onClick={() => handleBreadcrumbClick(breadcrumbs[breadcrumbs.length - 2])}
            className="flex items-center space-x-1 px-2 py-1 text-muted-foreground hover:text-primary bg-muted hover:bg-muted/80 rounded-sm transition-colors duration-200"
          >
            <Icon name="ArrowLeft" size={16} />
            <span className="text-xs">Zurück</span>
          </button>
        )}
      </div>
    </nav>
  );
};

export default BusinessNavigationBreadcrumbs;