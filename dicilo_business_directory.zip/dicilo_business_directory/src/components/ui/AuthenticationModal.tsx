import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';
import Input from './Input';
import { Checkbox } from './Checkbox';

interface AuthenticationModalProps {
  isOpen: boolean;
  mode: 'login' | 'register';
  onClose: () => void;
  onModeChange: (mode: 'login' | 'register') => void;
  onAuthenticate?: (userData: any) => void;
}

const AuthenticationModal = ({
  isOpen,
  mode,
  onClose,
  onModeChange,
  onAuthenticate
}: AuthenticationModalProps) => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    lastName: '',
    acceptTerms: false,
    acceptPrivacy: false
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const resetForm = () => {
    setFormData({
      email: '',
      password: '',
      confirmPassword: '',
      firstName: '',
      lastName: '',
      acceptTerms: false,
      acceptPrivacy: false
    });
    setErrors({});
  };

  useEffect(() => {
    if (isOpen) {
      resetForm();
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, mode]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.email) {
      newErrors.email = 'E-Mail-Adresse ist erforderlich';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Ungültige E-Mail-Adresse';
    }

    if (!formData.password) {
      newErrors.password = 'Passwort ist erforderlich';
    } else if (formData.password.length < 6) {
      newErrors.password = 'Passwort muss mindestens 6 Zeichen lang sein';
    }

    if (mode === 'register') {
      if (!formData.firstName) {
        newErrors.firstName = 'Vorname ist erforderlich';
      }

      if (!formData.lastName) {
        newErrors.lastName = 'Nachname ist erforderlich';
      }

      if (!formData.confirmPassword) {
        newErrors.confirmPassword = 'Passwort bestätigen ist erforderlich';
      } else if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = 'Passwörter stimmen nicht überein';
      }

      if (!formData.acceptTerms) {
        newErrors.acceptTerms = 'Sie müssen den Nutzungsbedingungen zustimmen';
      }

      if (!formData.acceptPrivacy) {
        newErrors.acceptPrivacy = 'Sie müssen der Datenschutzerklärung zustimmen';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));

      const userData = {
        name: mode === 'register' ? `${formData.firstName} ${formData.lastName}` : 'Test User',
        email: formData.email,
        id: Date.now().toString()
      };

      if (onAuthenticate) {
        onAuthenticate(userData);
      }

      onClose();
      
      if (mode === 'register') {
        navigate('/business-directory');
      }
    } catch (error) {
      setErrors({ general: 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut.' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const handleModeSwitch = (newMode: 'login' | 'register') => {
    resetForm();
    onModeChange(newMode);
  };

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-1020 animate-fade-in"
      onClick={handleOverlayClick}
    >
      <div className="bg-card rounded-lg shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto animate-scale-in">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Icon name="MapPin" size={20} color="white" />
              </div>
              <div>
                <h2 className="text-xl font-semibold text-card-foreground">
                  {mode === 'login' ? 'Anmelden' : 'Registrieren'}
                </h2>
                <p className="text-sm text-muted-foreground">
                  Dicilo Business Directory
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-md hover:bg-muted transition-colors duration-200"
            >
              <Icon name="X" size={20} />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {errors.general && (
              <div className="p-3 bg-error/10 border border-error/20 rounded-md">
                <p className="text-sm text-error">{errors.general}</p>
              </div>
            )}

            {mode === 'register' && (
              <div className="grid grid-cols-2 gap-3">
                <Input
                  label="Vorname"
                  type="text"
                  value={formData.firstName}
                  onChange={(e) => handleInputChange('firstName', e.target.value)}
                  error={errors.firstName}
                  required
                />
                <Input
                  label="Nachname"
                  type="text"
                  value={formData.lastName}
                  onChange={(e) => handleInputChange('lastName', e.target.value)}
                  error={errors.lastName}
                  required
                />
              </div>
            )}

            <Input
              label="E-Mail-Adresse"
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              error={errors.email}
              required
            />

            <Input
              label="Passwort"
              type="password"
              value={formData.password}
              onChange={(e) => handleInputChange('password', e.target.value)}
              error={errors.password}
              required
            />

            {mode === 'register' && (
              <Input
                label="Passwort bestätigen"
                type="password"
                value={formData.confirmPassword}
                onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                error={errors.confirmPassword}
                required
              />
            )}

            {mode === 'register' && (
              <div className="space-y-3">
                <Checkbox
                  label="Ich stimme den Nutzungsbedingungen zu"
                  checked={formData.acceptTerms}
                  onChange={(e) => handleInputChange('acceptTerms', e.target.checked)}
                  error={errors.acceptTerms}
                  required
                />
                <Checkbox
                  label="Ich stimme der Datenschutzerklärung zu"
                  checked={formData.acceptPrivacy}
                  onChange={(e) => handleInputChange('acceptPrivacy', e.target.checked)}
                  error={errors.acceptPrivacy}
                  required
                />
              </div>
            )}

            <Button
              type="submit"
              variant="default"
              fullWidth
              loading={isLoading}
              className="mt-6"
            >
              {mode === 'login' ? 'Anmelden' : 'Registrieren'}
            </Button>
          </form>

          {/* Mode Switch */}
          <div className="mt-6 pt-4 border-t border-border text-center">
            <p className="text-sm text-muted-foreground">
              {mode === 'login' ? 'Noch kein Konto?' : 'Bereits ein Konto?'}
              <button
                type="button"
                onClick={() => handleModeSwitch(mode === 'login' ? 'register' : 'login')}
                className="ml-1 text-primary hover:underline font-medium"
              >
                {mode === 'login' ? 'Registrieren' : 'Anmelden'}
              </button>
            </p>
          </div>

          {/* Social Login (Login mode only) */}
          {mode === 'login' && (
            <div className="mt-4">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-border" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card px-2 text-muted-foreground">Oder</span>
                </div>
              </div>
              <div className="mt-4 space-y-2">
                <Button
                  variant="outline"
                  fullWidth
                  iconName="Chrome"
                  iconPosition="left"
                  onClick={() => {}}
                >
                  Mit Google anmelden
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AuthenticationModal;