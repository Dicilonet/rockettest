import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Button from './Button';
import UserAccountDropdown from './UserAccountDropdown';
import Icon from '../AppIcon';

interface MainHeaderProps {
  isAuthenticated: boolean;
  user: any;
  onLogin: () => void;
  onLogout: () => void;
}

const MainHeader: React.FC<MainHeaderProps> = ({
  isAuthenticated,
  user,
  onLogin,
  onLogout
}) => {
  const navigate = useNavigate();

  const handleDashboardAccess = () => {
    if (user?.role === 'superadmin') {
      navigate('/admin-dashboard');
    } else {
      navigate('/user-profile');
    }
  };

  // Demo credentials display
  const demoCredentials = [
    { email: 'superadmin@dicilo.net', password: 'admin123', role: 'Superadmin' },
    { email: 'admin@dicilo.net', password: 'admin123', role: 'Admin' },
    { email: 'user@dicilo.net', password: 'user123', role: 'User' }
  ];

  return (
    <header className="fixed top-0 left-0 right-0 bg-background/95 backdrop-blur-sm border-b border-border z-50">
      <div className="max-w-7xl mx-auto flex items-center justify-between h-16 px-4 lg:px-6">
        {/* Logo */}
        <Link to="/" className="text-2xl font-bold text-primary">
          Dicilo.net
        </Link>

        {/* Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
            Vorteile
          </Link>
          <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
            Pläne
          </Link>
          <Link to="/" className="text-muted-foreground hover:text-foreground transition-colors">
            Über uns
          </Link>
          {!isAuthenticated && (
            <button
              onClick={onLogin}
              className="text-muted-foreground hover:text-foreground transition-colors"
            >
              Anmelden
            </button>
          )}
        </nav>

        {/* Auth Section */}
        <div className="flex items-center space-x-4">
          {isAuthenticated && user ? (
            <>
              {/* Dashboard Button for Superadmin */}
              {user.role === 'superadmin' && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleDashboardAccess}
                  iconName="Settings"
                  iconPosition="left"
                >
                  Dashboard
                </Button>
              )}
              
              <UserAccountDropdown 
                user={user} 
                onLogout={onLogout}
                onProfile={() => navigate('/user-profile')}
              />
            </>
          ) : (
            <>
              <Button variant="outline" size="sm" onClick={onLogin}>
                Anmelden
              </Button>
              <Button size="sm" onClick={() => navigate('/register')}>
                Registrieren
              </Button>
            </>
          )}
        </div>
      </div>

      {/* Demo Credentials Display (only when not authenticated) */}
      {!isAuthenticated && (
        <div className="bg-yellow-50 border-b border-yellow-200 px-4 py-2">
          <div className="max-w-7xl mx-auto">
            <p className="text-xs text-yellow-800 mb-1">
              <Icon name="Info" size={12} className="inline mr-1" />
              Demo-Zugangsdaten zum Testen:
            </p>
            <div className="flex flex-wrap gap-4 text-xs">
              {demoCredentials.map((cred, index) => (
                <span key={index} className="text-yellow-700">
                  <strong>{cred.role}:</strong> {cred.email} / {cred.password}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default MainHeader;