import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';

interface User {
  name: string;
  email: string;
  avatar?: string;
  favoriteCount?: number;
}

interface UserAccountDropdownProps {
  user: User;
  onLogout: () => void;
  className?: string;
}

const UserAccountDropdown = ({ 
  user, 
  onLogout, 
  className = '' 
}: UserAccountDropdownProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();
  const dropdownRef = useRef<HTMLDivElement>(null);

  const menuItems = [
    {
      label: 'Mein Profil',
      path: '/user-profile',
      icon: 'User',
      description: 'Profil bearbeiten und Einstellungen'
    },
    {
      label: 'Favoriten',
      path: '/favorites',
      icon: 'Heart',
      description: `${user.favoriteCount || 0} gespeicherte Unternehmen`,
      badge: user.favoriteCount
    },
    {
      label: 'Bewertungen',
      path: '/reviews',
      icon: 'Star',
      description: 'Meine Bewertungen verwalten'
    }
  ];

  const handleToggle = () => {
    setIsOpen(!isOpen);
  };

  const handleItemClick = (path: string) => {
    navigate(path);
    setIsOpen(false);
  };

  const handleLogout = () => {
    onLogout();
    setIsOpen(false);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    const handleEscapeKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscapeKey);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscapeKey);
    };
  }, [isOpen]);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      {/* Trigger Button */}
      <button
        onClick={handleToggle}
        className="flex items-center space-x-2 p-2 rounded-md hover:bg-muted transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
        aria-expanded={isOpen}
        aria-haspopup="true"
      >
        <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center overflow-hidden">
          {user.avatar ? (
            <img 
              src={user.avatar} 
              alt={`${user.name} Avatar`}
              className="w-full h-full object-cover"
            />
          ) : (
            <span className="text-sm font-medium text-primary-foreground">
              {getInitials(user.name)}
            </span>
          )}
        </div>
        <div className="hidden sm:block text-left">
          <p className="text-sm font-medium text-foreground">
            {user.name}
          </p>
          <p className="text-xs text-muted-foreground truncate max-w-32">
            {user.email}
          </p>
        </div>
        <Icon 
          name="ChevronDown" 
          size={16} 
          className={`hidden sm:block transition-transform duration-200 ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-64 bg-popover border border-border rounded-md shadow-lg animate-fade-in z-1010">
          <div className="p-2">
            {/* User Info Header */}
            <div className="px-3 py-2 border-b border-border">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center overflow-hidden">
                  {user.avatar ? (
                    <img 
                      src={user.avatar} 
                      alt={`${user.name} Avatar`}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <span className="text-sm font-medium text-primary-foreground">
                      {getInitials(user.name)}
                    </span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-popover-foreground truncate">
                    {user.name}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">
                    {user.email}
                  </p>
                </div>
              </div>
            </div>

            {/* Menu Items */}
            <div className="py-1">
              {menuItems.map((item) => (
                <button
                  key={item.path}
                  onClick={() => handleItemClick(item.path)}
                  className="flex items-center justify-between w-full px-3 py-2 text-sm text-popover-foreground hover:bg-muted rounded-sm transition-colors duration-200 group"
                >
                  <div className="flex items-center space-x-3">
                    <Icon 
                      name={item.icon} 
                      size={16} 
                      className="text-muted-foreground group-hover:text-foreground transition-colors duration-200" 
                    />
                    <div className="text-left">
                      <p className="font-medium">{item.label}</p>
                      <p className="text-xs text-muted-foreground">
                        {item.description}
                      </p>
                    </div>
                  </div>
                  {item.badge && (
                    <span className="bg-primary text-primary-foreground text-xs px-2 py-1 rounded-full">
                      {item.badge}
                    </span>
                  )}
                </button>
              ))}
            </div>

            {/* Logout */}
            <div className="pt-1 border-t border-border">
              <button
                onClick={handleLogout}
                className="flex items-center space-x-3 w-full px-3 py-2 text-sm text-destructive hover:bg-destructive/10 rounded-sm transition-colors duration-200 group"
              >
                <Icon 
                  name="LogOut" 
                  size={16} 
                  className="group-hover:text-destructive transition-colors duration-200" 
                />
                <span className="font-medium">Abmelden</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserAccountDropdown;