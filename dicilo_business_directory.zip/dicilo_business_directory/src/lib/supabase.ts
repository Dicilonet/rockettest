import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Supabase environment variables are required');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types (matching snake_case from database)
export interface Database {
  public: {
    Tables: {
      user_profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string;
          role: 'superadmin' | 'admin' | 'manager' | 'user';
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
      };
      businesses: {
        Row: {
          id: string;
          name: string;
          category_id: string | null;
          rating: number;
          review_count: number;
          address: string;
          phone: string | null;
          website: string | null;
          email: string | null;
          description: string | null;
          price_range: string | null;
          verified: boolean;
          status: 'active' | 'inactive' | 'pending' | 'suspended';
          latitude: number | null;
          longitude: number | null;
          city: string | null;
          state: string | null;
          zip_code: string | null;
          country: string | null;
          features: string[] | null;
          social_facebook: string | null;
          social_instagram: string | null;
          social_twitter: string | null;
          social_linkedin: string | null;
          created_by: string | null;
          created_at: string;
          updated_at: string;
        };
      };
      business_categories: {
        Row: {
          id: string;
          name: string;
          name_de: string;
          created_at: string;
        };
      };
      business_images: {
        Row: {
          id: string;
          business_id: string;
          url: string;
          alt_text: string;
          is_primary: boolean;
          category: 'exterior' | 'interior' | 'product' | 'team' | 'other';
          created_at: string;
        };
      };
      business_hours: {
        Row: {
          id: string;
          business_id: string;
          day_of_week: number;
          is_open: boolean;
          open_time: string | null;
          close_time: string | null;
          created_at: string;
        };
      };
      reviews: {
        Row: {
          id: string;
          business_id: string;
          user_id: string;
          rating: number;
          comment: string | null;
          helpful_count: number;
          not_helpful_count: number;
          created_at: string;
          updated_at: string;
        };
      };
      user_favorites: {
        Row: {
          id: string;
          user_id: string;
          business_id: string;
          created_at: string;
        };
      };
    };
  };
}