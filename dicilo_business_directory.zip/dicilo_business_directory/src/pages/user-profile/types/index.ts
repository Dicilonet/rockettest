export interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  avatar?: string;
  location: {
    city: string;
    state: string;
    country: string;
    postalCode?: string;
  };
  preferences: {
    language: 'de' | 'en';
    currency: 'EUR' | 'USD';
    notifications: {
      email: boolean;
      push: boolean;
      marketing: boolean;
      businessUpdates: boolean;
      recommendations: boolean;
    };
    privacy: {
      profileVisible: boolean;
      showReviews: boolean;
      showFavorites: boolean;
    };
    searchRadius: number;
  };
  memberSince: Date;
  lastActive: Date;
}

export interface FavoriteBusiness {
  id: string;
  name: string;
  category: string;
  rating: number;
  reviewCount: number;
  image: string;
  alt: string;
  address: string;
  distance: string;
  addedDate: Date;
  isOpen: boolean;
}

export interface UserReview {
  id: string;
  businessId: string;
  businessName: string;
  businessImage: string;
  businessImageAlt: string;
  rating: number;
  title: string;
  content: string;
  date: Date;
  helpful: number;
  images?: {
    url: string;
    alt: string;
  }[];
  response?: {
    content: string;
    date: Date;
    author: string;
  };
}

export interface ActivityItem {
  id: string;
  type: 'review' | 'favorite' | 'visit' | 'update';
  title: string;
  description: string;
  date: Date;
  businessName?: string;
  businessId?: string;
  icon: string;
}

export interface TabConfig {
  id: string;
  label: string;
  icon: string;
  count?: number;
}

export interface NotificationSettings {
  email: boolean;
  push: boolean;
  marketing: boolean;
  businessUpdates: boolean;
  recommendations: boolean;
}

export interface PrivacySettings {
  profileVisible: boolean;
  showReviews: boolean;
  showFavorites: boolean;
}

export interface LocationPreference {
  city: string;
  state: string;
  country: string;
  radius: number;
  isPrimary: boolean;
}