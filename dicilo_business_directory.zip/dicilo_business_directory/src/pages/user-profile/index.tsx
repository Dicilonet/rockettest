import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import MainHeader from '../../components/ui/MainHeader';
import BusinessNavigationBreadcrumbs from '../../components/ui/BusinessNavigationBreadcrumbs';
import AuthenticationModal from '../../components/ui/AuthenticationModal';
import ProfileHeader from './components/ProfileHeader';
import ProfileTabs from './components/ProfileTabs';
import PersonalInfoTab from './components/PersonalInfoTab';
import FavoritesTab from './components/FavoritesTab';
import ReviewsTab from './components/ReviewsTab';
import SettingsTab from './components/SettingsTab';
import {
  User,
  FavoriteBusiness,
  UserReview,
  TabConfig,
  NotificationSettings,
  PrivacySettings } from
'./types';
import Icon from '../../components/AppIcon';


const UserProfile = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(true);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [activeTab, setActiveTab] = useState('profile');
  const [user, setUser] = useState<User>({
    id: "user_123",
    firstName: "Maria",
    lastName: "Schmidt",
    email: "maria.schmidt@email.com",
    phone: "+49 30 12345678",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=400&fit=crop&crop=face",
    location: {
      city: "Berlin",
      state: "Berlin",
      country: "Deutschland",
      postalCode: "10115"
    },
    preferences: {
      language: 'de',
      currency: 'EUR',
      notifications: {
        email: true,
        push: true,
        marketing: false,
        businessUpdates: true,
        recommendations: true
      },
      privacy: {
        profileVisible: true,
        showReviews: true,
        showFavorites: false
      },
      searchRadius: 25
    },
    memberSince: new Date('2023-03-15'),
    lastActive: new Date(Date.now() - 2 * 60 * 60 * 1000)
  });

  const [favorites] = useState<FavoriteBusiness[]>([
  {
    id: "fav_1",
    name: "Café Central",
    category: "restaurant",
    rating: 4.5,
    reviewCount: 127,
    image: "https://images.unsplash.com/photo-1691067987594-b1b7f84ba55a",
    alt: "Gemütliches Café mit warmer Beleuchtung und Holzmöbeln, Gäste sitzen an kleinen Tischen",
    address: "Unter den Linden 15, 10117 Berlin",
    distance: "0.8 km",
    addedDate: new Date('2024-01-15'),
    isOpen: true
  },
  {
    id: "fav_2",
    name: "TechRepair Pro",
    category: "service",
    rating: 4.8,
    reviewCount: 89,
    image: "https://images.unsplash.com/photo-1727893141025-35d62b3f4a03",
    alt: "Moderne Werkstatt mit Techniker der Smartphone repariert, aufgeräumter Arbeitsplatz mit Werkzeugen",
    address: "Friedrichstraße 42, 10117 Berlin",
    distance: "1.2 km",
    addedDate: new Date('2024-01-10'),
    isOpen: false
  },
  {
    id: "fav_3",
    name: "Boutique Luna",
    category: "shopping",
    rating: 4.3,
    reviewCount: 156,
    image: "https://images.unsplash.com/photo-1490286262898-03a689323630",
    alt: "Elegante Boutique mit Kleiderstangen voller Designer-Mode, moderne Einrichtung mit Spiegeln",
    address: "Hackescher Markt 8, 10178 Berlin",
    distance: "2.1 km",
    addedDate: new Date('2024-01-05'),
    isOpen: true
  },
  {
    id: "fav_4",
    name: "Fitness First Berlin",
    category: "health",
    rating: 4.2,
    reviewCount: 203,
    image: "https://images.unsplash.com/photo-1664284602615-bc1348fa085c",
    alt: "Modernes Fitnessstudio mit Trainingsgeräten und Menschen beim Workout, helle Beleuchtung",
    address: "Potsdamer Platz 1, 10785 Berlin",
    distance: "3.5 km",
    addedDate: new Date('2023-12-20'),
    isOpen: true
  },
  {
    id: "fav_5",
    name: "Kino International",
    category: "entertainment",
    rating: 4.6,
    reviewCount: 312,
    image: "https://images.unsplash.com/photo-1716025124533-afb841434576",
    alt: "Klassisches Kino mit roten Samtsitzen und großer Leinwand, gedämpfte Beleuchtung",
    address: "Karl-Marx-Allee 33, 10178 Berlin",
    distance: "4.2 km",
    addedDate: new Date('2023-12-15'),
    isOpen: true
  },
  {
    id: "fav_6",
    name: "Restaurant Zur Linde",
    category: "restaurant",
    rating: 4.4,
    reviewCount: 98,
    image: "https://images.unsplash.com/photo-1663059365551-ef41747f3c06",
    alt: "Traditionelles deutsches Restaurant mit Holztischen und gemütlicher Atmosphäre, Kellner serviert Essen",
    address: "Prenzlauer Berg 12, 10405 Berlin",
    distance: "5.1 km",
    addedDate: new Date('2023-11-30'),
    isOpen: false
  },
  {
    id: "fav_7",
    name: "Buchhandlung Lesezeit",
    category: "shopping",
    rating: 4.7,
    reviewCount: 67,
    image: "https://images.unsplash.com/photo-1695332886554-eb2034ff4bf1",
    alt: "Gemütliche Buchhandlung mit hohen Regalen voller Bücher, Leseecke mit bequemen Sesseln",
    address: "Savignyplatz 5, 10623 Berlin",
    distance: "6.8 km",
    addedDate: new Date('2023-11-15'),
    isOpen: true
  },
  {
    id: "fav_8",
    name: "Wellness Oase",
    category: "health",
    rating: 4.9,
    reviewCount: 145,
    image: "https://images.unsplash.com/photo-1672983668116-2138ba936d83",
    alt: "Luxuriöses Spa mit Entspannungsbereich, warme Beleuchtung und Wellness-Liegen",
    address: "Kurfürstendamm 180, 10707 Berlin",
    distance: "7.3 km",
    addedDate: new Date('2023-10-28'),
    isOpen: true
  }]
  );

  const [reviews] = useState<UserReview[]>([
  {
    id: "review_1",
    businessId: "fav_1",
    businessName: "Café Central",
    businessImage: "https://img.rocket.new/generatedImages/rocket_gen_img_1a3c413b1-1763139335503.png",
    businessImageAlt: "Café Central Logo mit Kaffeetasse und warmem Licht",
    rating: 5,
    title: "Perfekter Ort für Meetings",
    content: `Das Café Central ist mein absoluter Lieblingsort für Geschäftsmeetings geworden. Die Atmosphäre ist professionell aber entspannt, der Kaffee ist ausgezeichnet und das WLAN funktioniert einwandfrei.\n\nBesonders beeindruckt hat mich der Service - das Personal ist aufmerksam ohne aufdringlich zu sein. Die Kuchen sind hausgemacht und schmecken fantastisch.`,
    date: new Date('2024-01-20'),
    helpful: 12,
    images: [
    {
      url: "https://images.unsplash.com/photo-1657657190200-93d3ebd7928b",
      alt: "Cappuccino mit Latte Art auf Holztisch neben Laptop"
    },
    {
      url: "https://images.unsplash.com/photo-1562007908-17c67e878c88",
      alt: "Hausgemachter Apfelkuchen auf weißem Teller mit Gabel"
    }],

    response: {
      content: "Vielen Dank für Ihre wunderbare Bewertung! Es freut uns sehr, dass Sie sich bei uns wohlfühlen. Wir freuen uns auf Ihren nächsten Besuch!",
      date: new Date('2024-01-22'),
      author: "Café Central Team"
    }
  },
  {
    id: "review_2",
    businessId: "fav_2",
    businessName: "TechRepair Pro",
    businessImage: "https://images.unsplash.com/photo-1631972241361-330c704b90f1",
    businessImageAlt: "TechRepair Pro Werkstatt mit Reparatur-Tools und Geräten",
    rating: 4,
    title: "Schnelle und professionelle Reparatur",
    content: `Mein iPhone Display war komplett zerbrochen und ich dachte schon, ich müsste ein neues Handy kaufen. TechRepair Pro hat das Display innerhalb von 2 Stunden ausgetauscht und es funktioniert wie neu.\n\nDer Preis war fair und die Garantie auf die Reparatur gibt mir ein gutes Gefühl. Einziger Kritikpunkt: Die Wartezeit hätte besser kommuniziert werden können.`,
    date: new Date('2024-01-18'),
    helpful: 8
  },
  {
    id: "review_3",
    businessId: "fav_3",
    businessName: "Boutique Luna",
    businessImage: "https://images.unsplash.com/photo-1707376081814-bdba706c6f8e",
    businessImageAlt: "Boutique Luna Schaufenster mit eleganter Mode-Auslage",
    rating: 5,
    title: "Einzigartige Mode und tolle Beratung",
    content: `Boutique Luna ist ein echter Geheimtipp! Die Auswahl ist zwar nicht riesig, aber dafür sehr durchdacht und einzigartig. Ich habe hier Stücke gefunden, die ich nirgendwo anders gesehen habe.\n\nDie Beratung ist persönlich und kompetent. Die Inhaberin hat ein tolles Gespür für Stil und hilft dabei, den perfekten Look zu finden.`,
    date: new Date('2024-01-12'),
    helpful: 15,
    images: [
    {
      url: "https://images.unsplash.com/photo-1687405181685-9f27883eb11b",
      alt: "Elegantes schwarzes Kleid auf Kleiderbügel in Boutique"
    }]

  }]
  );

  const tabs: TabConfig[] = [
  {
    id: 'profile',
    label: 'Profil',
    icon: 'User'
  },
  {
    id: 'favorites',
    label: 'Favoriten',
    icon: 'Heart',
    count: favorites.length
  },
  {
    id: 'reviews',
    label: 'Bewertungen',
    icon: 'Star',
    count: reviews.length
  },
  {
    id: 'settings',
    label: 'Einstellungen',
    icon: 'Settings'
  }];


  const handleLogin = () => {
    setAuthMode('login');
    setShowAuthModal(true);
  };

  const handleAuthenticate = (userData: any) => {
    setIsAuthenticated(true);
    setShowAuthModal(false);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  const handleUpdateUser = (updatedData: Partial<User>) => {
    setUser((prev) => ({ ...prev, ...updatedData }));
  };

  const handleRemoveFavorite = (businessId: string) => {
    // In a real app, this would make an API call
    console.log('Removing favorite:', businessId);
  };

  const handleEditReview = (reviewId: string) => {
    // In a real app, this would open an edit modal
    console.log('Editing review:', reviewId);
  };

  const handleDeleteReview = (reviewId: string) => {
    // In a real app, this would make an API call
    console.log('Deleting review:', reviewId);
  };

  const handleUpdateNotifications = (settings: NotificationSettings) => {
    setUser((prev) => ({
      ...prev,
      preferences: {
        ...prev.preferences,
        notifications: settings
      }
    }));
  };

  const handleUpdatePrivacy = (settings: PrivacySettings) => {
    setUser((prev) => ({
      ...prev,
      preferences: {
        ...prev.preferences,
        privacy: settings
      }
    }));
  };

  const handleChangePassword = async (currentPassword: string, newPassword: string) => {
    // In a real app, this would make an API call
    await new Promise((resolve) => setTimeout(resolve, 1000));
    console.log('Password changed successfully');
  };

  const handleDeleteAccount = () => {
    // In a real app, this would make an API call and redirect
    console.log('Account deleted');
  };

  const handleExportData = () => {
    // In a real app, this would generate and download user data
    const userData = {
      profile: user,
      favorites: favorites,
      reviews: reviews,
      exportDate: new Date().toISOString()
    };

    const dataStr = JSON.stringify(userData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);

    const link = document.createElement('a');
    link.href = url;
    link.download = `dicilo-user-data-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const renderTabContent = () => {
    switch (activeTab) {
      case 'profile':
        return (
          <PersonalInfoTab
            user={user}
            onUpdateUser={handleUpdateUser} />);


      case 'favorites':
        return (
          <FavoritesTab
            favorites={favorites}
            onRemoveFavorite={handleRemoveFavorite} />);


      case 'reviews':
        return (
          <ReviewsTab
            reviews={reviews}
            onEditReview={handleEditReview}
            onDeleteReview={handleDeleteReview} />);


      case 'settings':
        return (
          <SettingsTab
            user={user}
            onUpdateNotifications={handleUpdateNotifications}
            onUpdatePrivacy={handleUpdatePrivacy}
            onChangePassword={handleChangePassword}
            onDeleteAccount={handleDeleteAccount}
            onExportData={handleExportData} />);


      default:
        return null;
    }
  };

  useEffect(() => {
    if (!isAuthenticated) {
      setShowAuthModal(true);
    }
  }, [isAuthenticated]);

  return (
    <>
      <Helmet>
        <title>Mein Profil - Dicilo Business Directory</title>
        <meta name="description" content="Verwalten Sie Ihr Profil, Favoriten, Bewertungen und Einstellungen in der Dicilo Business Directory." />
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <MainHeader
          isAuthenticated={isAuthenticated}
          user={isAuthenticated ? {
            name: `${user.firstName} ${user.lastName}`,
            email: user.email,
            avatar: user.avatar
          } : undefined}
          onLogin={handleLogin}
          onLogout={handleLogout} />


        <main className="pt-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <BusinessNavigationBreadcrumbs
              customItems={[
              {
                label: 'Unternehmen',
                path: '/business-directory',
                icon: 'MapPin'
              },
              {
                label: 'Mein Profil',
                icon: 'User'
              }]
              } />


            {isAuthenticated ?
            <>
                <ProfileHeader
                user={user}
                onEditProfile={() => setActiveTab('profile')} />


                <ProfileTabs
                tabs={tabs}
                activeTab={activeTab}
                onTabChange={setActiveTab} />


                {renderTabContent()}
              </> :

            <div className="text-center py-12">
                <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                  <Icon name="User" size={32} className="text-muted-foreground" />
                </div>
                <h2 className="text-2xl font-semibold text-foreground mb-2">
                  Anmeldung erforderlich
                </h2>
                <p className="text-muted-foreground mb-6">
                  Melden Sie sich an, um auf Ihr Profil zuzugreifen
                </p>
              </div>
            }
          </div>
        </main>

        <AuthenticationModal
          isOpen={showAuthModal}
          mode={authMode}
          onClose={() => setShowAuthModal(false)}
          onModeChange={setAuthMode}
          onAuthenticate={handleAuthenticate} />

      </div>
    </>);

};

export default UserProfile;