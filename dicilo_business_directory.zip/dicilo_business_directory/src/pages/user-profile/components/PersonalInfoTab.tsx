import React, { useState } from 'react';

import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { User } from '../types';

interface PersonalInfoTabProps {
  user: User;
  onUpdateUser: (updatedUser: Partial<User>) => void;
}

const PersonalInfoTab = ({ user, onUpdateUser }: PersonalInfoTabProps) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    firstName: user.firstName,
    lastName: user.lastName,
    email: user.email,
    phone: user.phone || '',
    city: user.location.city,
    state: user.location.state,
    postalCode: user.location.postalCode || ''
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  const languageOptions = [
    { value: 'de', label: 'Deutsch' },
    { value: 'en', label: 'English' }
  ];

  const currencyOptions = [
    { value: 'EUR', label: 'Euro (€)' },
    { value: 'USD', label: 'US Dollar ($)' }
  ];

  const radiusOptions = [
    { value: 5, label: '5 km' },
    { value: 10, label: '10 km' },
    { value: 25, label: '25 km' },
    { value: 50, label: '50 km' },
    { value: 100, label: '100 km' }
  ];

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.firstName.trim()) {
      newErrors.firstName = 'Vorname ist erforderlich';
    }

    if (!formData.lastName.trim()) {
      newErrors.lastName = 'Nachname ist erforderlich';
    }

    if (!formData.email.trim()) {
      newErrors.email = 'E-Mail ist erforderlich';
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = 'Ungültige E-Mail-Adresse';
    }

    if (formData.phone && !/^[\+]?[0-9\s\-\(\)]+$/.test(formData.phone)) {
      newErrors.phone = 'Ungültige Telefonnummer';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSave = async () => {
    if (!validateForm()) return;

    setIsLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      onUpdateUser({
        firstName: formData.firstName,
        lastName: formData.lastName,
        email: formData.email,
        phone: formData.phone,
        location: {
          ...user.location,
          city: formData.city,
          state: formData.state,
          postalCode: formData.postalCode
        }
      });
      
      setIsEditing(false);
    } catch (error) {
      setErrors({ general: 'Fehler beim Speichern der Daten' });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancel = () => {
    setFormData({
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      phone: user.phone || '',
      city: user.location.city,
      state: user.location.state,
      postalCode: user.location.postalCode || ''
    });
    setErrors({});
    setIsEditing(false);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">
          Persönliche Informationen
        </h2>
        {!isEditing && (
          <Button
            variant="outline"
            onClick={() => setIsEditing(true)}
            iconName="Edit"
            iconPosition="left"
          >
            Bearbeiten
          </Button>
        )}
      </div>

      {errors.general && (
        <div className="mb-6 p-4 bg-error/10 border border-error/20 rounded-md">
          <p className="text-sm text-error">{errors.general}</p>
        </div>
      )}

      <div className="space-y-6">
        {/* Basic Information */}
        <div>
          <h3 className="text-lg font-medium text-foreground mb-4">
            Grundinformationen
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              label="Vorname"
              type="text"
              value={formData.firstName}
              onChange={(e) => handleInputChange('firstName', e.target.value)}
              error={errors.firstName}
              disabled={!isEditing}
              required
            />
            <Input
              label="Nachname"
              type="text"
              value={formData.lastName}
              onChange={(e) => handleInputChange('lastName', e.target.value)}
              error={errors.lastName}
              disabled={!isEditing}
              required
            />
            <Input
              label="E-Mail-Adresse"
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              error={errors.email}
              disabled={!isEditing}
              required
            />
            <Input
              label="Telefonnummer"
              type="tel"
              value={formData.phone}
              onChange={(e) => handleInputChange('phone', e.target.value)}
              error={errors.phone}
              disabled={!isEditing}
              placeholder="+49 123 456789"
            />
          </div>
        </div>

        {/* Location Information */}
        <div>
          <h3 className="text-lg font-medium text-foreground mb-4">
            Standortinformationen
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              label="Stadt"
              type="text"
              value={formData.city}
              onChange={(e) => handleInputChange('city', e.target.value)}
              disabled={!isEditing}
            />
            <Input
              label="Bundesland"
              type="text"
              value={formData.state}
              onChange={(e) => handleInputChange('state', e.target.value)}
              disabled={!isEditing}
            />
            <Input
              label="Postleitzahl"
              type="text"
              value={formData.postalCode}
              onChange={(e) => handleInputChange('postalCode', e.target.value)}
              disabled={!isEditing}
            />
          </div>
        </div>

        {/* Preferences */}
        <div>
          <h3 className="text-lg font-medium text-foreground mb-4">
            Einstellungen
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Select
              label="Sprache"
              options={languageOptions}
              value={user.preferences.language}
              onChange={(value) => onUpdateUser({
                preferences: {
                  ...user.preferences,
                  language: value as 'de' | 'en'
                }
              })}
              disabled={isEditing}
            />
            <Select
              label="Währung"
              options={currencyOptions}
              value={user.preferences.currency}
              onChange={(value) => onUpdateUser({
                preferences: {
                  ...user.preferences,
                  currency: value as 'EUR' | 'USD'
                }
              })}
              disabled={isEditing}
            />
            <Select
              label="Suchradius"
              options={radiusOptions}
              value={user.preferences.searchRadius}
              onChange={(value) => onUpdateUser({
                preferences: {
                  ...user.preferences,
                  searchRadius: Number(value)
                }
              })}
              disabled={isEditing}
            />
          </div>
        </div>

        {/* Action Buttons */}
        {isEditing && (
          <div className="flex items-center space-x-3 pt-4 border-t border-border">
            <Button
              variant="default"
              onClick={handleSave}
              loading={isLoading}
              iconName="Save"
              iconPosition="left"
            >
              Speichern
            </Button>
            <Button
              variant="outline"
              onClick={handleCancel}
              disabled={isLoading}
            >
              Abbrechen
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default PersonalInfoTab;