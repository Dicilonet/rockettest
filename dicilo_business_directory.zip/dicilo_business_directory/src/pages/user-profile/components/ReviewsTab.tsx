import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { UserReview } from '../types';

interface ReviewsTabProps {
  reviews: UserReview[];
  onEditReview: (reviewId: string) => void;
  onDeleteReview: (reviewId: string) => void;
}

const ReviewsTab = ({ reviews, onEditReview, onDeleteReview }: ReviewsTabProps) => {
  const [sortBy, setSortBy] = useState('recent');
  const [filterRating, setFilterRating] = useState('all');
  const navigate = useNavigate();

  const sortOptions = [
    { value: 'recent', label: 'Neueste zuerst' },
    { value: 'oldest', label: 'Älteste zuerst' },
    { value: 'rating-high', label: 'Höchste Bewertung' },
    { value: 'rating-low', label: 'Niedrigste Bewertung' },
    { value: 'helpful', label: 'Hilfreichste' }
  ];

  const ratingOptions = [
    { value: 'all', label: 'Alle Bewertungen' },
    { value: '5', label: '5 Sterne' },
    { value: '4', label: '4 Sterne' },
    { value: '3', label: '3 Sterne' },
    { value: '2', label: '2 Sterne' },
    { value: '1', label: '1 Stern' }
  ];

  const filteredReviews = reviews
    .filter(review => {
      if (filterRating === 'all') return true;
      return review.rating === parseInt(filterRating);
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'oldest':
          return a.date.getTime() - b.date.getTime();
        case 'rating-high':
          return b.rating - a.rating;
        case 'rating-low':
          return a.rating - b.rating;
        case 'helpful':
          return b.helpful - a.helpful;
        case 'recent':
        default:
          return b.date.getTime() - a.date.getTime();
      }
    });

  const handleBusinessClick = (businessId: string) => {
    navigate(`/business-details?id=${businessId}`);
  };

  const handleDeleteReview = (reviewId: string, businessName: string) => {
    if (window.confirm(`Möchten Sie Ihre Bewertung für "${businessName}" wirklich löschen?`)) {
      onDeleteReview(reviewId);
    }
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('de-DE', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Icon
        key={index}
        name="Star"
        size={16}
        className={index < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}
      />
    ));
  };

  const getAverageRating = () => {
    if (reviews.length === 0) return 0;
    const sum = reviews.reduce((acc, review) => acc + review.rating, 0);
    return (sum / reviews.length).toFixed(1);
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-semibold text-foreground">
            Meine Bewertungen ({reviews.length})
          </h2>
          {reviews.length > 0 && (
            <p className="text-sm text-muted-foreground mt-1">
              Durchschnittliche Bewertung: {getAverageRating()} Sterne
            </p>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <Select
          label="Sortieren nach"
          options={sortOptions}
          value={sortBy}
          onChange={setSortBy}
        />
        <Select
          label="Nach Bewertung filtern"
          options={ratingOptions}
          value={filterRating}
          onChange={setFilterRating}
        />
      </div>

      {/* Reviews List */}
      {filteredReviews.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="Star" size={32} className="text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium text-foreground mb-2">
            {filterRating !== 'all' ? 'Keine Bewertungen gefunden' : 'Noch keine Bewertungen'}
          </h3>
          <p className="text-muted-foreground mb-4">
            {filterRating !== 'all' ?'Versuchen Sie andere Filter' :'Besuchen Sie Unternehmen und teilen Sie Ihre Erfahrungen'
            }
          </p>
          {filterRating === 'all' && (
            <Button
              variant="default"
              onClick={() => navigate('/business-directory')}
              iconName="Search"
              iconPosition="left"
            >
              Unternehmen entdecken
            </Button>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          {filteredReviews.map((review) => (
            <div
              key={review.id}
              className="bg-background border border-border rounded-lg p-6"
            >
              {/* Review Header */}
              <div className="flex items-start space-x-4 mb-4">
                <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                  <Image
                    src={review.businessImage}
                    alt={review.businessImageAlt}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-2">
                    <button
                      onClick={() => handleBusinessClick(review.businessId)}
                      className="text-lg font-semibold text-foreground hover:text-primary transition-colors duration-200"
                    >
                      {review.businessName}
                    </button>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onEditReview(review.id)}
                        iconName="Edit"
                        iconPosition="left"
                      >
                        Bearbeiten
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteReview(review.id, review.businessName)}
                        iconName="Trash2"
                        iconPosition="left"
                        className="text-destructive hover:text-destructive"
                      >
                        Löschen
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                    <div className="flex items-center space-x-1">
                      {renderStars(review.rating)}
                      <span className="ml-1 font-medium">{review.rating} Sterne</span>
                    </div>
                    <span>{formatDate(review.date)}</span>
                    <div className="flex items-center space-x-1">
                      <Icon name="ThumbsUp" size={14} />
                      <span>{review.helpful} hilfreich</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Review Content */}
              <div className="mb-4">
                {review.title && (
                  <h4 className="font-medium text-foreground mb-2">
                    {review.title}
                  </h4>
                )}
                <p className="text-foreground leading-relaxed">
                  {review.content}
                </p>
              </div>

              {/* Review Images */}
              {review.images && review.images.length > 0 && (
                <div className="flex space-x-2 mb-4 overflow-x-auto">
                  {review.images.map((image, index) => (
                    <div
                      key={index}
                      className="w-20 h-20 rounded-lg overflow-hidden flex-shrink-0"
                    >
                      <Image
                        src={image.url}
                        alt={image.alt}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                </div>
              )}

              {/* Business Response */}
              {review.response && (
                <div className="bg-muted rounded-lg p-4 border-l-4 border-primary">
                  <div className="flex items-center space-x-2 mb-2">
                    <Icon name="MessageSquare" size={16} className="text-primary" />
                    <span className="text-sm font-medium text-foreground">
                      Antwort von {review.response.author}
                    </span>
                    <span className="text-sm text-muted-foreground">
                      {formatDate(review.response.date)}
                    </span>
                  </div>
                  <p className="text-sm text-foreground">
                    {review.response.content}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ReviewsTab;