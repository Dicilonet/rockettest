import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import { User } from '../types';

interface ProfileHeaderProps {
  user: User;
  onEditProfile: () => void;
}

const ProfileHeader = ({ user, onEditProfile }: ProfileHeaderProps) => {
  const [isImageLoading, setIsImageLoading] = useState(false);

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
  };

  const formatMemberSince = (date: Date) => {
    return new Intl.DateTimeFormat('de-DE', {
      year: 'numeric',
      month: 'long'
    }).format(date);
  };

  const formatLastActive = (date: Date) => {
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
      return `Vor ${diffInHours} Stunden aktiv`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `Vor ${diffInDays} Tagen aktiv`;
    }
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6 mb-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-4 sm:space-y-0 sm:space-x-6">
        {/* Profile Image */}
        <div className="relative">
          <div className="w-24 h-24 rounded-full overflow-hidden bg-muted flex items-center justify-center">
            {user.avatar ? (
              <Image
                src={user.avatar}
                alt={`Profilbild von ${user.firstName} ${user.lastName}`}
                className="w-full h-full object-cover"
                loading="eager"
              />
            ) : (
              <span className="text-2xl font-semibold text-muted-foreground">
                {getInitials(user.firstName, user.lastName)}
              </span>
            )}
          </div>
          <button
            onClick={onEditProfile}
            className="absolute -bottom-1 -right-1 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center hover:bg-primary/90 transition-colors duration-200 shadow-md"
            title="Profilbild bearbeiten"
          >
            <Icon name="Camera" size={16} />
          </button>
        </div>

        {/* User Info */}
        <div className="flex-1">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">
                {user.firstName} {user.lastName}
              </h1>
              <p className="text-muted-foreground mt-1">
                {user.email}
              </p>
              {user.phone && (
                <p className="text-muted-foreground text-sm">
                  {user.phone}
                </p>
              )}
            </div>
            <Button
              variant="outline"
              onClick={onEditProfile}
              iconName="Edit"
              iconPosition="left"
              className="mt-3 sm:mt-0"
            >
              Profil bearbeiten
            </Button>
          </div>

          {/* Location and Member Info */}
          <div className="flex flex-wrap items-center gap-4 mt-4 text-sm text-muted-foreground">
            <div className="flex items-center space-x-1">
              <Icon name="MapPin" size={16} />
              <span>
                {user.location.city}, {user.location.state}
              </span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Calendar" size={16} />
              <span>
                Mitglied seit {formatMemberSince(user.memberSince)}
              </span>
            </div>
            <div className="flex items-center space-x-1">
              <Icon name="Clock" size={16} />
              <span>
                {formatLastActive(user.lastActive)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-border">
        <div className="text-center">
          <div className="text-2xl font-bold text-primary">12</div>
          <div className="text-sm text-muted-foreground">Bewertungen</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-primary">8</div>
          <div className="text-sm text-muted-foreground">Favoriten</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-primary">24</div>
          <div className="text-sm text-muted-foreground">Besuche</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-primary">4.8</div>
          <div className="text-sm text-muted-foreground">Durchschnitt</div>
        </div>
      </div>
    </div>
  );
};

export default ProfileHeader;