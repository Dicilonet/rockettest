import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { FavoriteBusiness } from '../types';

interface FavoritesTabProps {
  favorites: FavoriteBusiness[];
  onRemoveFavorite: (businessId: string) => void;
}

const FavoritesTab = ({ favorites, onRemoveFavorite }: FavoritesTabProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('recent');
  const navigate = useNavigate();

  const categoryOptions = [
    { value: 'all', label: 'Alle Kategorien' },
    { value: 'restaurant', label: 'Restaurants' },
    { value: 'shopping', label: 'Einkaufen' },
    { value: 'service', label: 'Dienstleistungen' },
    { value: 'health', label: 'Gesundheit' },
    { value: 'entertainment', label: 'Unterhaltung' }
  ];

  const sortOptions = [
    { value: 'recent', label: 'Zuletzt hinzugefügt' },
    { value: 'name', label: 'Name A-Z' },
    { value: 'rating', label: 'Bewertung' },
    { value: 'distance', label: 'Entfernung' }
  ];

  const filteredFavorites = favorites
    .filter(business => {
      const matchesSearch = business.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           business.category.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesCategory = selectedCategory === 'all' || business.category === selectedCategory;
      return matchesSearch && matchesCategory;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case 'name':
          return a.name.localeCompare(b.name);
        case 'rating':
          return b.rating - a.rating;
        case 'distance':
          return parseFloat(a.distance) - parseFloat(b.distance);
        case 'recent':
        default:
          return b.addedDate.getTime() - a.addedDate.getTime();
      }
    });

  const handleBusinessClick = (businessId: string) => {
    navigate(`/business-details?id=${businessId}`);
  };

  const handleRemoveFavorite = (businessId: string, businessName: string) => {
    if (window.confirm(`Möchten Sie "${businessName}" aus Ihren Favoriten entfernen?`)) {
      onRemoveFavorite(businessId);
    }
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('de-DE', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    }).format(date);
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Icon
        key={index}
        name="Star"
        size={16}
        className={index < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}
      />
    ));
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-foreground">
          Meine Favoriten ({favorites.length})
        </h2>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Input
          type="search"
          placeholder="Unternehmen suchen..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <Select
          options={categoryOptions}
          value={selectedCategory}
          onChange={setSelectedCategory}
          placeholder="Kategorie wählen"
        />
        <Select
          options={sortOptions}
          value={sortBy}
          onChange={setSortBy}
          placeholder="Sortieren nach"
        />
      </div>

      {/* Favorites List */}
      {filteredFavorites.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
            <Icon name="Heart" size={32} className="text-muted-foreground" />
          </div>
          <h3 className="text-lg font-medium text-foreground mb-2">
            {searchQuery || selectedCategory !== 'all' ? 'Keine Ergebnisse gefunden' : 'Noch keine Favoriten'}
          </h3>
          <p className="text-muted-foreground mb-4">
            {searchQuery || selectedCategory !== 'all' ?'Versuchen Sie andere Suchbegriffe oder Filter' :'Speichern Sie Unternehmen als Favoriten, um sie hier zu sehen'
            }
          </p>
          {!searchQuery && selectedCategory === 'all' && (
            <Button
              variant="default"
              onClick={() => navigate('/business-directory')}
              iconName="Search"
              iconPosition="left"
            >
              Unternehmen entdecken
            </Button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredFavorites.map((business) => (
            <div
              key={business.id}
              className="bg-background border border-border rounded-lg overflow-hidden hover:shadow-md transition-shadow duration-200"
            >
              {/* Business Image */}
              <div className="relative h-48 overflow-hidden">
                <Image
                  src={business.image}
                  alt={business.alt}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 right-3">
                  <button
                    onClick={() => handleRemoveFavorite(business.id, business.name)}
                    className="w-8 h-8 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-sm transition-colors duration-200"
                    title="Aus Favoriten entfernen"
                  >
                    <Icon name="Heart" size={16} className="text-red-500 fill-current" />
                  </button>
                </div>
                {business.isOpen && (
                  <div className="absolute top-3 left-3">
                    <span className="bg-green-500 text-white text-xs px-2 py-1 rounded-full">
                      Geöffnet
                    </span>
                  </div>
                )}
              </div>

              {/* Business Info */}
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-foreground line-clamp-1">
                    {business.name}
                  </h3>
                  <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">
                    {business.category}
                  </span>
                </div>

                <div className="flex items-center space-x-1 mb-2">
                  {renderStars(business.rating)}
                  <span className="text-sm font-medium text-foreground ml-1">
                    {business.rating.toFixed(1)}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    ({business.reviewCount})
                  </span>
                </div>

                <div className="flex items-center text-sm text-muted-foreground mb-2">
                  <Icon name="MapPin" size={14} className="mr-1" />
                  <span className="line-clamp-1">{business.address}</span>
                </div>

                <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                  <span>{business.distance}</span>
                  <span>Hinzugefügt: {formatDate(business.addedDate)}</span>
                </div>

                <Button
                  variant="outline"
                  fullWidth
                  onClick={() => handleBusinessClick(business.id)}
                  iconName="ExternalLink"
                  iconPosition="right"
                >
                  Details ansehen
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default FavoritesTab;