import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';
import { User, NotificationSettings, PrivacySettings } from '../types';

interface SettingsTabProps {
  user: User;
  onUpdateNotifications: (settings: NotificationSettings) => void;
  onUpdatePrivacy: (settings: PrivacySettings) => void;
  onChangePassword: (currentPassword: string, newPassword: string) => void;
  onDeleteAccount: () => void;
  onExportData: () => void;
}

const SettingsTab = ({
  user,
  onUpdateNotifications,
  onUpdatePrivacy,
  onChangePassword,
  onDeleteAccount,
  onExportData
}: SettingsTabProps) => {
  const [passwordData, setPasswordData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });
  const [passwordErrors, setPasswordErrors] = useState<Record<string, string>>({});
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  const handleNotificationChange = (key: keyof NotificationSettings, value: boolean) => {
    onUpdateNotifications({
      ...user.preferences.notifications,
      [key]: value
    });
  };

  const handlePrivacyChange = (key: keyof PrivacySettings, value: boolean) => {
    onUpdatePrivacy({
      ...user.preferences.privacy,
      [key]: value
    });
  };

  const validatePasswordForm = () => {
    const errors: Record<string, string> = {};

    if (!passwordData.currentPassword) {
      errors.currentPassword = 'Aktuelles Passwort ist erforderlich';
    }

    if (!passwordData.newPassword) {
      errors.newPassword = 'Neues Passwort ist erforderlich';
    } else if (passwordData.newPassword.length < 8) {
      errors.newPassword = 'Passwort muss mindestens 8 Zeichen lang sein';
    }

    if (!passwordData.confirmPassword) {
      errors.confirmPassword = 'Passwort bestätigen ist erforderlich';
    } else if (passwordData.newPassword !== passwordData.confirmPassword) {
      errors.confirmPassword = 'Passwörter stimmen nicht überein';
    }

    if (passwordData.currentPassword === passwordData.newPassword) {
      errors.newPassword = 'Neues Passwort muss sich vom aktuellen unterscheiden';
    }

    setPasswordErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handlePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validatePasswordForm()) return;

    setIsChangingPassword(true);
    try {
      await onChangePassword(passwordData.currentPassword, passwordData.newPassword);
      setPasswordData({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
      });
      setPasswordErrors({});
    } catch (error) {
      setPasswordErrors({ general: 'Fehler beim Ändern des Passworts' });
    } finally {
      setIsChangingPassword(false);
    }
  };

  const handleDeleteAccount = () => {
    if (showDeleteConfirm) {
      onDeleteAccount();
    } else {
      setShowDeleteConfirm(true);
      setTimeout(() => setShowDeleteConfirm(false), 10000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Notification Settings */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">
          Benachrichtigungseinstellungen
        </h3>
        <div className="space-y-4">
          <Checkbox
            label="E-Mail-Benachrichtigungen"
            description="Erhalten Sie Updates per E-Mail"
            checked={user.preferences.notifications.email}
            onChange={(e) => handleNotificationChange('email', e.target.checked)}
          />
          <Checkbox
            label="Push-Benachrichtigungen"
            description="Erhalten Sie Browser-Benachrichtigungen"
            checked={user.preferences.notifications.push}
            onChange={(e) => handleNotificationChange('push', e.target.checked)}
          />
          <Checkbox
            label="Marketing-E-Mails"
            description="Erhalten Sie Informationen über neue Features und Angebote"
            checked={user.preferences.notifications.marketing}
            onChange={(e) => handleNotificationChange('marketing', e.target.checked)}
          />
          <Checkbox
            label="Unternehmens-Updates"
            description="Benachrichtigungen über Updates Ihrer favorisierten Unternehmen"
            checked={user.preferences.notifications.businessUpdates}
            onChange={(e) => handleNotificationChange('businessUpdates', e.target.checked)}
          />
          <Checkbox
            label="Empfehlungen"
            description="Personalisierte Unternehmensempfehlungen basierend auf Ihren Präferenzen"
            checked={user.preferences.notifications.recommendations}
            onChange={(e) => handleNotificationChange('recommendations', e.target.checked)}
          />
        </div>
      </div>

      {/* Privacy Settings */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">
          Datenschutzeinstellungen
        </h3>
        <div className="space-y-4">
          <Checkbox
            label="Profil öffentlich sichtbar"
            description="Andere Nutzer können Ihr Profil sehen"
            checked={user.preferences.privacy.profileVisible}
            onChange={(e) => handlePrivacyChange('profileVisible', e.target.checked)}
          />
          <Checkbox
            label="Bewertungen öffentlich anzeigen"
            description="Ihre Bewertungen sind für andere Nutzer sichtbar"
            checked={user.preferences.privacy.showReviews}
            onChange={(e) => handlePrivacyChange('showReviews', e.target.checked)}
          />
          <Checkbox
            label="Favoriten öffentlich anzeigen"
            description="Ihre Favoriten sind für andere Nutzer sichtbar"
            checked={user.preferences.privacy.showFavorites}
            onChange={(e) => handlePrivacyChange('showFavorites', e.target.checked)}
          />
        </div>
      </div>

      {/* Password Change */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">
          Passwort ändern
        </h3>
        <form onSubmit={handlePasswordSubmit} className="space-y-4">
          {passwordErrors.general && (
            <div className="p-3 bg-error/10 border border-error/20 rounded-md">
              <p className="text-sm text-error">{passwordErrors.general}</p>
            </div>
          )}
          <Input
            label="Aktuelles Passwort"
            type="password"
            value={passwordData.currentPassword}
            onChange={(e) => setPasswordData(prev => ({ ...prev, currentPassword: e.target.value }))}
            error={passwordErrors.currentPassword}
            required
          />
          <Input
            label="Neues Passwort"
            type="password"
            value={passwordData.newPassword}
            onChange={(e) => setPasswordData(prev => ({ ...prev, newPassword: e.target.value }))}
            error={passwordErrors.newPassword}
            description="Mindestens 8 Zeichen"
            required
          />
          <Input
            label="Neues Passwort bestätigen"
            type="password"
            value={passwordData.confirmPassword}
            onChange={(e) => setPasswordData(prev => ({ ...prev, confirmPassword: e.target.value }))}
            error={passwordErrors.confirmPassword}
            required
          />
          <Button
            type="submit"
            variant="default"
            loading={isChangingPassword}
            iconName="Lock"
            iconPosition="left"
          >
            Passwort ändern
          </Button>
        </form>
      </div>

      {/* Data Management */}
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">
          Datenverwaltung
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
            <div>
              <h4 className="font-medium text-foreground">Daten exportieren</h4>
              <p className="text-sm text-muted-foreground">
                Laden Sie eine Kopie Ihrer Daten herunter (DSGVO-konform)
              </p>
            </div>
            <Button
              variant="outline"
              onClick={onExportData}
              iconName="Download"
              iconPosition="left"
            >
              Exportieren
            </Button>
          </div>
          
          <div className="flex items-center justify-between p-4 bg-destructive/5 border border-destructive/20 rounded-lg">
            <div>
              <h4 className="font-medium text-foreground">Konto löschen</h4>
              <p className="text-sm text-muted-foreground">
                Alle Ihre Daten werden permanent gelöscht. Diese Aktion kann nicht rückgängig gemacht werden.
              </p>
            </div>
            <Button
              variant={showDeleteConfirm ? "destructive" : "outline"}
              onClick={handleDeleteAccount}
              iconName="Trash2"
              iconPosition="left"
            >
              {showDeleteConfirm ? 'Bestätigen' : 'Konto löschen'}
            </Button>
          </div>
          
          {showDeleteConfirm && (
            <div className="p-4 bg-warning/10 border border-warning/20 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Icon name="AlertTriangle" size={16} className="text-warning" />
                <span className="text-sm font-medium text-warning">Achtung!</span>
              </div>
              <p className="text-sm text-foreground">
                Klicken Sie erneut auf "Bestätigen", um Ihr Konto permanent zu löschen. 
                Diese Aktion kann nicht rückgängig gemacht werden.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SettingsTab;