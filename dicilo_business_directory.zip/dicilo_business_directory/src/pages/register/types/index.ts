export interface RegisterFormData {
  firstName: string;
  lastName: string;
  email: string;
  password: string;
  confirmPassword: string;
  location: string;
  businessInterests: string[];
  acceptTerms: boolean;
  acceptPrivacy: boolean;
  acceptMarketing: boolean;
}

export interface FormErrors {
  firstName?: string;
  lastName?: string;
  email?: string;
  password?: string;
  confirmPassword?: string;
  location?: string;
  businessInterests?: string;
  acceptTerms?: string;
  acceptPrivacy?: string;
  general?: string;
}

export interface BusinessInterestOption {
  value: string;
  label: string;
  description?: string;
}

export interface LocationOption {
  value: string;
  label: string;
  region?: string;
}

export interface SocialProvider {
  id: string;
  name: string;
  icon: string;
  color: string;
}

export interface TestimonialData {
  id: string;
  name: string;
  role: string;
  company: string;
  content: string;
  avatar: string;
  alt: string;
  rating: number;
}

export interface TrustBadge {
  id: string;
  name: string;
  icon: string;
  description: string;
}