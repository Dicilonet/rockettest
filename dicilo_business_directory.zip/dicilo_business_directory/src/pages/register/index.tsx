import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import RegistrationForm from './components/RegistrationForm';
import SocialRegistration from './components/SocialRegistration';
import TrustSignals from './components/TrustSignals';
import { RegisterFormData, FormErrors } from './types';

const RegisterPage = () => {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});

  const validateForm = (data: RegisterFormData): FormErrors => {
    const newErrors: FormErrors = {};

    if (!data.firstName.trim()) {
      newErrors.firstName = 'Vorname ist erforderlich';
    }

    if (!data.lastName.trim()) {
      newErrors.lastName = 'Nachname ist erforderlich';
    }

    if (!data.email.trim()) {
      newErrors.email = 'E-Mail-Adresse ist erforderlich';
    } else if (!/\S+@\S+\.\S+/.test(data.email)) {
      newErrors.email = 'Ungültige E-Mail-Adresse';
    }

    if (!data.password) {
      newErrors.password = 'Passwort ist erforderlich';
    } else if (data.password.length < 8) {
      newErrors.password = 'Passwort muss mindestens 8 Zeichen lang sein';
    }

    if (!data.confirmPassword) {
      newErrors.confirmPassword = 'Passwort bestätigen ist erforderlich';
    } else if (data.password !== data.confirmPassword) {
      newErrors.confirmPassword = 'Passwörter stimmen nicht überein';
    }

    if (!data.acceptTerms) {
      newErrors.acceptTerms = 'Sie müssen den Nutzungsbedingungen zustimmen';
    }

    if (!data.acceptPrivacy) {
      newErrors.acceptPrivacy = 'Sie müssen der Datenschutzerklärung zustimmen';
    }

    return newErrors;
  };

  const handleRegistration = async (formData: RegisterFormData) => {
    setErrors({});
    
    const validationErrors = validateForm(formData);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    setIsLoading(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 2000));

      // Mock successful registration
      const userData = {
        id: Date.now().toString(),
        name: `${formData.firstName} ${formData.lastName}`,
        email: formData.email,
        location: formData.location,
        businessInterests: formData.businessInterests,
        acceptMarketing: formData.acceptMarketing
      };

      // Store user data in localStorage (mock authentication)
      localStorage.setItem('dicilo_user', JSON.stringify(userData));
      localStorage.setItem('dicilo_auth_token', 'mock_token_' + Date.now());

      // Navigate to business directory
      navigate('/business-directory', { 
        state: { 
          message: 'Registrierung erfolgreich! Willkommen bei Dicilo.',
          user: userData 
        }
      });

    } catch (error) {
      setErrors({ 
        general: 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut.' 
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSocialRegistration = async (provider: string) => {
    setIsLoading(true);

    try {
      // Simulate social registration
      await new Promise(resolve => setTimeout(resolve, 1500));

      const userData = {
        id: Date.now().toString(),
        name: provider === 'google' ? 'Max Mustermann' : 'Anna Schmidt',
        email: provider === 'google' ? 'max.mustermann@gmail.com' : 'anna.schmidt@facebook.com',
        provider: provider,
        location: 'berlin',
        businessInterests: ['restaurants', 'services']
      };

      localStorage.setItem('dicilo_user', JSON.stringify(userData));
      localStorage.setItem('dicilo_auth_token', 'social_token_' + Date.now());

      navigate('/business-directory', { 
        state: { 
          message: `Erfolgreich mit ${provider === 'google' ? 'Google' : 'Facebook'} registriert!`,
          user: userData 
        }
      });

    } catch (error) {
      setErrors({ 
        general: `Fehler bei der ${provider === 'google' ? 'Google' : 'Facebook'}-Registrierung. Bitte versuchen Sie es erneut.` 
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Registrieren - Dicilo Business Directory</title>
        <meta 
          name="description" 
          content="Erstellen Sie Ihr kostenloses Konto bei Dicilo und entdecken Sie lokale Unternehmen in Deutschland. Personalisierte Empfehlungen und sichere Registrierung." 
        />
        <meta name="keywords" content="registrieren, konto erstellen, dicilo, business directory, lokale unternehmen, deutschland" />
        <meta property="og:title" content="Registrieren - Dicilo Business Directory" />
        <meta property="og:description" content="Erstellen Sie Ihr kostenloses Konto und entdecken Sie lokale Unternehmen" />
        <meta property="og:type" content="website" />
      </Helmet>

      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {/* Main Registration Form */}
            <div className="lg:col-span-2 space-y-6">
              <RegistrationForm
                onSubmit={handleRegistration}
                isLoading={isLoading}
                errors={errors}
              />
              
              {/* Social Registration */}
              <SocialRegistration
                onSocialRegister={handleSocialRegistration}
                isLoading={isLoading}
              />
            </div>

            {/* Trust Signals Sidebar */}
            <div className="lg:col-span-1">
              <TrustSignals />
            </div>
          </div>

          {/* Mobile Trust Signals */}
          <div className="lg:hidden mt-8">
            <TrustSignals />
          </div>
        </div>
      </div>
    </>
  );
};

export default RegisterPage;