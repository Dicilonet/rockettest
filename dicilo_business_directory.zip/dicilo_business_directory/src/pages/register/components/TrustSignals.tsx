import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import { TrustBadge, TestimonialData } from '../types';

const TrustSignals = () => {
  const trustBadges: TrustBadge[] = [
  {
    id: 'gdpr',
    name: 'DSGVO-konform',
    icon: 'Shield',
    description: 'Ihre Daten sind sicher geschützt'
  },
  {
    id: 'ssl',
    name: 'SSL-verschlüsselt',
    icon: 'Lock',
    description: 'Sichere Datenübertragung'
  },
  {
    id: 'verified',
    name: 'Verifizierte Unternehmen',
    icon: 'CheckCircle',
    description: 'Nur geprüfte Geschäfte'
  }];


  const testimonials: TestimonialData[] = [
  {
    id: '1',
    name: 'Anna Schmidt',
    role: 'Geschäftsführerin',
    company: 'Schmidt Marketing GmbH',
    content: `Dicilo hat mir geholfen, lokale Dienstleister schnell zu finden. Die Bewertungen sind sehr hilfreich und vertrauenswürdig.`,
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1f94bdc89-1762274217022.png",
    alt: 'Professional woman with brown hair in business attire smiling at camera',
    rating: 5
  },
  {
    id: '2',
    name: 'Michael Weber',
    role: 'Projektmanager',
    company: 'Tech Solutions Berlin',
    content: `Perfekt für die Suche nach Restaurants und Services in neuen Städten. Die Kartenansicht ist besonders praktisch.`,
    avatar: "https://images.unsplash.com/photo-1617386124435-9eb3935b1e11",
    alt: 'Professional man with beard wearing dark shirt smiling confidently',
    rating: 5
  }];


  return (
    <div className="w-full max-w-md mx-auto space-y-6">
      {/* Trust Badges */}
      <div className="bg-card rounded-lg shadow-lg p-6 border border-border">
        <h3 className="text-lg font-semibold text-card-foreground mb-4 text-center">
          Vertrauen & Sicherheit
        </h3>
        <div className="space-y-4">
          {trustBadges.map((badge) =>
          <div key={badge.id} className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                <Icon name={badge.icon} size={16} className="text-green-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-card-foreground">
                  {badge.name}
                </p>
                <p className="text-xs text-muted-foreground">
                  {badge.description}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* User Testimonials */}
      <div className="bg-card rounded-lg shadow-lg p-6 border border-border">
        <h3 className="text-lg font-semibold text-card-foreground mb-4 text-center">
          Was unsere Nutzer sagen
        </h3>
        <div className="space-y-4">
          {testimonials.map((testimonial) =>
          <div key={testimonial.id} className="border-b border-border last:border-b-0 pb-4 last:pb-0">
              <div className="flex items-start space-x-3">
                <div className="w-10 h-10 rounded-full overflow-hidden flex-shrink-0">
                  <Image
                  src={testimonial.avatar}
                  alt={testimonial.alt}
                  className="w-full h-full object-cover" />

                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-1 mb-1">
                    {[...Array(testimonial.rating)].map((_, i) =>
                  <Icon key={i} name="Star" size={12} className="text-yellow-400 fill-current" />
                  )}
                  </div>
                  <p className="text-xs text-muted-foreground mb-2">
                    "{testimonial.content}"
                  </p>
                  <div className="text-xs">
                    <p className="font-medium text-card-foreground">
                      {testimonial.name}
                    </p>
                    <p className="text-muted-foreground">
                      {testimonial.role}, {testimonial.company}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Statistics */}
      <div className="bg-card rounded-lg shadow-lg p-6 border border-border">
        <h3 className="text-lg font-semibold text-card-foreground mb-4 text-center">
          Dicilo in Zahlen
        </h3>
        <div className="grid grid-cols-2 gap-4 text-center">
          <div>
            <p className="text-2xl font-bold text-primary">15.000+</p>
            <p className="text-xs text-muted-foreground">Verifizierte Unternehmen</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-primary">50.000+</p>
            <p className="text-xs text-muted-foreground">Zufriedene Nutzer</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-primary">25+</p>
            <p className="text-xs text-muted-foreground">Deutsche Städte</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-primary">4.8★</p>
            <p className="text-xs text-muted-foreground">Durchschnittsbewertung</p>
          </div>
        </div>
      </div>
    </div>);

};

export default TrustSignals;