import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';
import Icon from '../../../components/AppIcon';
import { RegisterFormData, FormErrors, BusinessInterestOption, LocationOption } from '../types';

interface RegistrationFormProps {
  onSubmit: (data: RegisterFormData) => Promise<void>;
  isLoading: boolean;
  errors: FormErrors;
}

const RegistrationForm = ({ onSubmit, isLoading, errors }: RegistrationFormProps) => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState<RegisterFormData>({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    location: '',
    businessInterests: [],
    acceptTerms: false,
    acceptPrivacy: false,
    acceptMarketing: false
  });

  const locationOptions: LocationOption[] = [
    { value: 'berlin', label: 'Berlin', region: 'Berlin' },
    { value: 'munich', label: 'München', region: 'Bayern' },
    { value: 'hamburg', label: 'Hamburg', region: 'Hamburg' },
    { value: 'cologne', label: 'Köln', region: 'Nordrhein-Westfalen' },
    { value: 'frankfurt', label: 'Frankfurt am Main', region: 'Hessen' },
    { value: 'stuttgart', label: 'Stuttgart', region: 'Baden-Württemberg' },
    { value: 'dusseldorf', label: 'Düsseldorf', region: 'Nordrhein-Westfalen' },
    { value: 'dortmund', label: 'Dortmund', region: 'Nordrhein-Westfalen' },
    { value: 'essen', label: 'Essen', region: 'Nordrhein-Westfalen' },
    { value: 'leipzig', label: 'Leipzig', region: 'Sachsen' }
  ];

  const businessInterestOptions: BusinessInterestOption[] = [
    { value: 'restaurants', label: 'Restaurants & Gastronomie', description: 'Lokale Restaurants und Cafés' },
    { value: 'retail', label: 'Einzelhandel & Shopping', description: 'Geschäfte und Boutiquen' },
    { value: 'services', label: 'Dienstleistungen', description: 'Professionelle Services' },
    { value: 'healthcare', label: 'Gesundheit & Wellness', description: 'Ärzte, Apotheken, Fitness' },
    { value: 'automotive', label: 'Automotive', description: 'Werkstätten und Autohäuser' },
    { value: 'beauty', label: 'Beauty & Kosmetik', description: 'Friseure und Kosmetikstudios' },
    { value: 'education', label: 'Bildung & Lernen', description: 'Schulen und Kurse' },
    { value: 'entertainment', label: 'Unterhaltung & Freizeit', description: 'Kinos, Theater, Events' }
  ];

  const handleInputChange = (field: keyof RegisterFormData, value: string | boolean | string[]) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await onSubmit(formData);
  };

  const getPasswordStrength = (password: string): { strength: number; label: string; color: string } => {
    if (password.length === 0) return { strength: 0, label: '', color: '' };
    
    let strength = 0;
    if (password.length >= 8) strength += 25;
    if (/[A-Z]/.test(password)) strength += 25;
    if (/[0-9]/.test(password)) strength += 25;
    if (/[^A-Za-z0-9]/.test(password)) strength += 25;

    if (strength <= 25) return { strength, label: 'Schwach', color: 'bg-red-500' };
    if (strength <= 50) return { strength, label: 'Mittel', color: 'bg-yellow-500' };
    if (strength <= 75) return { strength, label: 'Gut', color: 'bg-blue-500' };
    return { strength, label: 'Sehr gut', color: 'bg-green-500' };
  };

  const passwordStrength = getPasswordStrength(formData.password);

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-card rounded-lg shadow-lg p-6 border border-border">
        {/* Header */}
        <div className="text-center mb-6">
          <div className="flex items-center justify-center space-x-2 mb-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Icon name="MapPin" size={24} color="white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-card-foreground">Registrieren</h1>
              <p className="text-sm text-muted-foreground">Dicilo Business Directory</p>
            </div>
          </div>
          <p className="text-muted-foreground">
            Erstellen Sie Ihr Konto und entdecken Sie lokale Unternehmen
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {errors.general && (
            <div className="p-3 bg-error/10 border border-error/20 rounded-md">
              <div className="flex items-center space-x-2">
                <Icon name="AlertCircle" size={16} className="text-error" />
                <p className="text-sm text-error">{errors.general}</p>
              </div>
            </div>
          )}

          {/* Name Fields */}
          <div className="grid grid-cols-2 gap-3">
            <Input
              label="Vorname"
              type="text"
              value={formData.firstName}
              onChange={(e) => handleInputChange('firstName', e.target.value)}
              error={errors.firstName}
              required
              placeholder="Max"
            />
            <Input
              label="Nachname"
              type="text"
              value={formData.lastName}
              onChange={(e) => handleInputChange('lastName', e.target.value)}
              error={errors.lastName}
              required
              placeholder="Mustermann"
            />
          </div>

          {/* Email */}
          <Input
            label="E-Mail-Adresse"
            type="email"
            value={formData.email}
            onChange={(e) => handleInputChange('email', e.target.value)}
            error={errors.email}
            required
            placeholder="max.mustermann@email.de"
          />

          {/* Password */}
          <div className="space-y-2">
            <Input
              label="Passwort"
              type="password"
              value={formData.password}
              onChange={(e) => handleInputChange('password', e.target.value)}
              error={errors.password}
              required
              placeholder="Mindestens 8 Zeichen"
            />
            {formData.password && (
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Passwortstärke:</span>
                  <span className={`font-medium ${
                    passwordStrength.strength <= 25 ? 'text-red-600' :
                    passwordStrength.strength <= 50 ? 'text-yellow-600' :
                    passwordStrength.strength <= 75 ? 'text-blue-600' : 'text-green-600'
                  }`}>
                    {passwordStrength.label}
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${passwordStrength.color}`}
                    style={{ width: `${passwordStrength.strength}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Confirm Password */}
          <Input
            label="Passwort bestätigen"
            type="password"
            value={formData.confirmPassword}
            onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
            error={errors.confirmPassword}
            required
            placeholder="Passwort wiederholen"
          />

          {/* Location */}
          <Select
            label="Standort (optional)"
            placeholder="Wählen Sie Ihre Stadt"
            options={locationOptions}
            value={formData.location}
            onChange={(value) => handleInputChange('location', value as string)}
            error={errors.location}
            searchable
            clearable
          />

          {/* Business Interests */}
          <Select
            label="Geschäftsinteressen (optional)"
            placeholder="Wählen Sie Ihre Interessen"
            description="Hilft uns, personalisierte Empfehlungen zu geben"
            options={businessInterestOptions}
            value={formData.businessInterests}
            onChange={(value) => handleInputChange('businessInterests', value as string[])}
            error={errors.businessInterests}
            multiple
            searchable
          />

          {/* Checkboxes */}
          <div className="space-y-3 pt-2">
            <Checkbox
              label="Ich stimme den Nutzungsbedingungen zu"
              checked={formData.acceptTerms}
              onChange={(e) => handleInputChange('acceptTerms', e.target.checked)}
              error={errors.acceptTerms}
              required
            />
            <Checkbox
              label="Ich stimme der Datenschutzerklärung zu"
              checked={formData.acceptPrivacy}
              onChange={(e) => handleInputChange('acceptPrivacy', e.target.checked)}
              error={errors.acceptPrivacy}
              required
            />
            <Checkbox
              label="Ich möchte Marketing-E-Mails erhalten (optional)"
              description="Erhalten Sie Updates über neue Unternehmen und Angebote"
              checked={formData.acceptMarketing}
              onChange={(e) => handleInputChange('acceptMarketing', e.target.checked)}
            />
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            variant="default"
            fullWidth
            loading={isLoading}
            className="mt-6"
          >
            Konto erstellen
          </Button>
        </form>

        {/* Login Link */}
        <div className="mt-6 pt-4 border-t border-border text-center">
          <p className="text-sm text-muted-foreground">
            Bereits ein Konto?
            <button
              type="button"
              onClick={() => navigate('/login')}
              className="ml-1 text-primary hover:underline font-medium"
            >
              Jetzt anmelden
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default RegistrationForm;