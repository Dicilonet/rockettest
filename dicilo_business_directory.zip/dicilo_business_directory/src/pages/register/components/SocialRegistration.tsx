import React from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';
import { SocialProvider } from '../types';

interface SocialRegistrationProps {
  onSocialRegister: (provider: string) => void;
  isLoading: boolean;
}

const SocialRegistration = ({ onSocialRegister, isLoading }: SocialRegistrationProps) => {
  const socialProviders: SocialProvider[] = [
    {
      id: 'google',
      name: 'Google',
      icon: 'Chrome',
      color: 'hover:bg-red-50 hover:border-red-200'
    },
    {
      id: 'facebook',
      name: 'Facebook',
      icon: 'Facebook',
      color: 'hover:bg-blue-50 hover:border-blue-200'
    }
  ];

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="bg-card rounded-lg shadow-lg p-6 border border-border">
        {/* Header */}
        <div className="text-center mb-6">
          <h2 className="text-lg font-semibold text-card-foreground mb-2">
            Schnelle Registrierung
          </h2>
          <p className="text-sm text-muted-foreground">
            Registrieren Sie sich mit Ihrem bestehenden Konto
          </p>
        </div>

        {/* Social Buttons */}
        <div className="space-y-3">
          {socialProviders.map((provider) => (
            <Button
              key={provider.id}
              variant="outline"
              fullWidth
              onClick={() => onSocialRegister(provider.id)}
              disabled={isLoading}
              iconName={provider.icon}
              iconPosition="left"
              className={`transition-colors duration-200 ${provider.color}`}
            >
              Mit {provider.name} registrieren
            </Button>
          ))}
        </div>

        {/* Divider */}
        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-border" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-card px-2 text-muted-foreground">Oder</span>
          </div>
        </div>

        {/* Benefits */}
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-card-foreground">
            Vorteile der Registrierung:
          </h3>
          <ul className="space-y-1 text-xs text-muted-foreground">
            <li className="flex items-center space-x-2">
              <Icon name="Check" size={12} className="text-green-600" />
              <span>Personalisierte Unternehmensempfehlungen</span>
            </li>
            <li className="flex items-center space-x-2">
              <Icon name="Check" size={12} className="text-green-600" />
              <span>Favoriten speichern und verwalten</span>
            </li>
            <li className="flex items-center space-x-2">
              <Icon name="Check" size={12} className="text-green-600" />
              <span>Bewertungen schreiben und lesen</span>
            </li>
            <li className="flex items-center space-x-2">
              <Icon name="Check" size={12} className="text-green-600" />
              <span>Exklusive Angebote erhalten</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default SocialRegistration;