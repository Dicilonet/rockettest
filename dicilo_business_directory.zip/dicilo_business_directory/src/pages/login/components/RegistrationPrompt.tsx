import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../../../components/ui/Button';

const RegistrationPrompt = () => {
  const navigate = useNavigate();

  const handleRegisterClick = () => {
    navigate('/register');
  };

  return (
    <div className="text-center space-y-4">
      <div className="pt-6 border-t border-border">
        <p className="text-sm text-muted-foreground mb-4">
          Noch kein Konto bei Dicilo?
        </p>
        <Button
          variant="outline"
          fullWidth
          onClick={handleRegisterClick}
          iconName="UserPlus"
          iconPosition="left"
          className="h-12"
        >
          Kostenloses Konto erstellen
        </Button>
      </div>

      <div className="text-xs text-muted-foreground space-y-1">
        <p>
          Mit der Anmeldung stimmen Sie unseren{' '}
          <button className="text-primary hover:underline">
            Nutzungsbedingungen
          </button>{' '}
          zu
        </p>
        <p>
          und bestätigen unsere{' '}
          <button className="text-primary hover:underline">
            Datenschutzerklärung
          </button>
        </p>
      </div>
    </div>
  );
};

export default RegistrationPrompt;