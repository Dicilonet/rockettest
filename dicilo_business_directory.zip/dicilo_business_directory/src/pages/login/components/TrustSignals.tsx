import React from 'react';
import Icon from '../../../components/AppIcon';

const TrustSignals = () => {
  const trustFeatures = [
    {
      icon: 'Shield',
      title: 'DSGVO-konform',
      description: 'Ihre Daten sind sicher'
    },
    {
      icon: 'Lock',
      title: 'SSL-verschlüsselt',
      description: 'Sichere Übertragung'
    },
    {
      icon: 'Award',
      title: 'Verifizierte Unternehmen',
      description: 'Geprüfte Geschäfte'
    }
  ];

  return (
    <div className="bg-muted/30 rounded-lg p-4">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {trustFeatures?.map((feature, index) => (
          <div key={index} className="flex items-center space-x-3 text-center sm:text-left">
            <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
              <Icon 
                name={feature?.icon} 
                size={16} 
                className="text-primary" 
              />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-medium text-foreground">
                {feature?.title}
              </p>
              <p className="text-xs text-muted-foreground">
                {feature?.description}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TrustSignals;