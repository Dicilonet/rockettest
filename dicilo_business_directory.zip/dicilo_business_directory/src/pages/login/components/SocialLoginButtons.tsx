import React from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';
import { SocialLoginProvider } from '../types';

const SocialLoginButtons = () => {
  const socialProviders: SocialLoginProvider[] = [
    {
      id: 'google',
      name: 'Google',
      icon: 'Chrome',
      color: '#4285F4',
      bgColor: '#4285F4'
    },
    {
      id: 'facebook',
      name: 'Facebook',
      icon: 'Facebook',
      color: '#1877F2',
      bgColor: '#1877F2'
    }
  ];

  const handleSocialLogin = (providerId: string) => {
    console.log(`Social login with ${providerId}`);
    // Implement social login logic here
  };

  return (
    <div className="space-y-3">
      <div className="relative">
        <div className="absolute inset-0 flex items-center">
          <div className="w-full border-t border-border" />
        </div>
        <div className="relative flex justify-center text-xs uppercase">
          <span className="bg-background px-2 text-muted-foreground">Oder</span>
        </div>
      </div>

      <div className="space-y-2">
        {socialProviders.map((provider) => (
          <Button
            key={provider.id}
            variant="outline"
            fullWidth
            onClick={() => handleSocialLogin(provider.id)}
            className="h-12 border-2 hover:bg-muted/50"
          >
            <div className="flex items-center justify-center space-x-3">
              <Icon 
                name={provider.icon} 
                size={20} 
                color={provider.color}
              />
              <span className="font-medium">
                Mit {provider.name} anmelden
              </span>
            </div>
          </Button>
        ))}
      </div>
    </div>
  );
};

export default SocialLoginButtons;