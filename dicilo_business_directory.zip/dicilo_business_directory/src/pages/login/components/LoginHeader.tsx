import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';

const LoginHeader = () => {
  const navigate = useNavigate();

  return (
    <div className="text-center space-y-4">
      {/* Logo */}
      <div 
        className="flex items-center justify-center cursor-pointer"
        onClick={() => navigate('/business-directory')}
      >
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
            <Icon name="MapPin" size={28} color="white" />
          </div>
          <div className="text-left">
            <h1 className="text-2xl font-bold text-foreground">
              Dicilo
            </h1>
            <p className="text-sm text-muted-foreground">
              Business Directory
            </p>
          </div>
        </div>
      </div>

      {/* Welcome Message */}
      <div className="space-y-2">
        <h2 className="text-2xl font-semibold text-foreground">
          Willkommen zurück
        </h2>
        <p className="text-muted-foreground">
          Melden Sie sich an, um lokale Unternehmen zu entdecken
        </p>
      </div>
    </div>
  );
};

export default LoginHeader;