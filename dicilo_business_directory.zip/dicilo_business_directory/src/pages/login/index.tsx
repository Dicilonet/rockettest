import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import LoginHeader from './components/LoginHeader';
import LoginForm from './components/LoginForm';
import SocialLoginButtons from './components/SocialLoginButtons';
import RegistrationPrompt from './components/RegistrationPrompt';
import TrustSignals from './components/TrustSignals';
import { LoginPageProps } from './types';

const LoginPage = ({ onLogin }: LoginPageProps) => {
  useEffect(() => {
    // Scroll to top on page load
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Helmet>
        <title>Anmelden - Dicilo Business Directory</title>
        <meta 
          name="description" 
          content="Melden Sie sich bei Dicilo an und entdecken Sie lokale Unternehmen in Ihrer Nähe. Sichere Anmeldung mit DSGVO-Konformität." 
        />
        <meta name="keywords" content="Anmelden, Login, Dicilo, Business Directory, lokale Unternehmen" />
      </Helmet>

      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-card rounded-xl shadow-lg border border-border p-8">
            {/* Header */}
            <LoginHeader />

            {/* Login Form */}
            <div className="mt-8">
              <LoginForm onLogin={onLogin} />
            </div>

            {/* Social Login */}
            <div className="mt-6">
              <SocialLoginButtons />
            </div>

            {/* Registration Prompt */}
            <div className="mt-8">
              <RegistrationPrompt />
            </div>
          </div>

          {/* Trust Signals */}
          <div className="mt-6">
            <TrustSignals />
          </div>

          {/* Footer */}
          <div className="mt-6 text-center">
            <p className="text-xs text-muted-foreground">
              © {new Date().getFullYear()} Dicilo Business Directory. Alle Rechte vorbehalten.
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default LoginPage;