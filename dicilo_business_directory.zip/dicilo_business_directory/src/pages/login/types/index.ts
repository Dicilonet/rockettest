export interface LoginFormData {
  email: string;
  password: string;
  rememberMe: boolean;
}

export interface LoginFormErrors {
  email?: string;
  password?: string;
  general?: string;
}

export interface SocialLoginProvider {
  id: string;
  name: string;
  icon: string;
  color: string;
  bgColor: string;
}

export interface LoginPageProps {
  onLogin?: (userData: any) => void;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}