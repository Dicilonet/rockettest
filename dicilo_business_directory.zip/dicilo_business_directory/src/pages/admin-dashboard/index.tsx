import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import MainHeader from '../../components/ui/MainHeader';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Select from '../../components/ui/Select';
import Icon from '../../components/AppIcon';
import { businessService } from '../../services/businessService';
import { reviewService } from '../../services/reviewService';
import { Business } from '../business-details/types';

const AdminDashboard = () => {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();
  const [businesses, setBusinesses] = useState<Business[]>([]);
  const [selectedBusiness, setSelectedBusiness] = useState<Business | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [isCreating, setIsCreating] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // Reviews state
  const [reviews, setReviews] = useState<any[]>([]);
  const [showReviews, setShowReviews] = useState(false);

  // Form state for editing/creating
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    address: '',
    phone: '',
    website: '',
    email: '',
    description: '',
    priceRange: '€€',
    features: [] as string[],
    socialFacebook: '',
    socialInstagram: '',
    city: '',
    state: 'Deutschland',
    zipCode: '',
    latitude: 0,
    longitude: 0
  });

  // Available categories for business registration
  const businessCategories = [
    'Restaurant',
    'Café',
    'Bar',
    'Hotel',
    'Geschäft',
    'Supermarkt',
    'Apotheke',
    'Bank',
    'Friseur',
    'Fitness',
    'Arzt',
    'Zahnarzt',
    'Anwalt',
    'Buchhaltung',
    'IT Service',
    'Autowerkstatt',
    'Tankstelle',
    'Kino',
    'Theater',
    'Museum',
    'Bibliothek',
    'Schule',
    'Kindergarten'
  ];

  useEffect(() => {
    // Check if user is superadmin
    if (!profile || profile.role !== 'superadmin') {
      navigate('/login');
      return;
    }

    loadBusinesses();
  }, [profile, navigate]);

  const loadBusinesses = async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await businessService.getAllBusinesses();
      setBusinesses(data);
    } catch (err: any) {
      console.error('Error loading businesses:', err);
      if (err.message?.includes('Database schema not applied')) {
        setError('❌ Database-Fehler: Die Datenbank-Migration wurde noch nicht angewendet. Bitte wenden Sie sich an den Support, um die Migration anzuwenden.');
      } else {
        setError('Fehler beim Laden der Unternehmen: ' + (err.message || 'Unbekannter Fehler'));
      }
    } finally {
      setLoading(false);
    }
  };

  const loadBusinessReviews = async (businessId: string) => {
    try {
      const reviewData = await reviewService.getBusinessReviews(businessId);
      setReviews(reviewData);
      setShowReviews(true);
    } catch (err: any) {
      console.error('Error loading reviews:', err);
      setError('Fehler beim Laden der Bewertungen: ' + (err.message || 'Unbekannter Fehler'));
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      category: '',
      address: '',
      phone: '',
      website: '',
      email: '',
      description: '',
      priceRange: '€€',
      features: [],
      socialFacebook: '',
      socialInstagram: '',
      city: '',
      state: 'Deutschland',
      zipCode: '',
      latitude: 0,
      longitude: 0
    });
  };

  const handleSelectBusiness = (business: Business) => {
    setSelectedBusiness(business);
    setFormData({
      name: business.name,
      category: business.category,
      address: business.address,
      phone: business.phone || '',
      website: business.website || '',
      email: business.email || '',
      description: business.description,
      priceRange: business.priceRange,
      features: business.features,
      socialFacebook: business.socialMedia?.facebook || '',
      socialInstagram: business.socialMedia?.instagram || '',
      city: business.location?.city || '',
      state: business.location?.state || 'Deutschland',
      zipCode: business.location?.zipCode || '',
      latitude: business.location?.latitude || 0,
      longitude: business.location?.longitude || 0
    });
    setIsEditing(false);
    setIsCreating(false);
    setError(null);
    setSuccess(null);
    setShowReviews(false);
  };

  const handleStartCreate = () => {
    setSelectedBusiness(null);
    resetForm();
    setIsCreating(true);
    setIsEditing(false);
    setError(null);
    setSuccess(null);
    setShowReviews(false);
  };

  const handleSave = async () => {
    if (!selectedBusiness && !isCreating) return;

    try {
      setLoading(true);
      
      if (isCreating) {
        // Create new business
        const newBusiness = {
          name: formData.name,
          category: formData.category,
          address: formData.address,
          phone: formData.phone || undefined,
          website: formData.website || undefined,
          email: formData.email || undefined,
          description: formData.description,
          priceRange: formData.priceRange,
          features: formData.features,
          location: {
            latitude: formData.latitude,
            longitude: formData.longitude,
            city: formData.city,
            state: formData.state,
            zipCode: formData.zipCode,
            country: 'Deutschland'
          },
          socialMedia: {
            facebook: formData.socialFacebook || undefined,
            instagram: formData.socialInstagram || undefined
          },
          verified: true,
          images: [],
          operatingHours: {
            monday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
            tuesday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
            wednesday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
            thursday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
            friday: { isOpen: true, openTime: '09:00', closeTime: '17:00' },
            saturday: { isOpen: true, openTime: '10:00', closeTime: '16:00' },
            sunday: { isOpen: false }
          },
          specialOffers: []
        };

        const { data, error } = await businessService.createBusiness(newBusiness);

        if (error) {
          if (error.message?.includes('Database schema not applied')) {
            setError('❌ Database-Fehler: Die Datenbank-Migration wurde noch nicht angewendet. Bitte wenden Sie sich an den Support.');
          } else {
            setError('Fehler beim Erstellen: ' + error.message);
          }
        } else {
          setSuccess('✅ Neues Unternehmen erfolgreich erstellt!');
          setIsCreating(false);
          await loadBusinesses();
          if (data) {
            setSelectedBusiness(data);
          }
        }
      } else if (selectedBusiness) {
        // Update existing business
        const updates: Partial<Business> = {
          name: formData.name,
          address: formData.address,
          phone: formData.phone,
          website: formData.website,
          email: formData.email,
          description: formData.description,
          priceRange: formData.priceRange,
          features: formData.features,
          location: {
            ...selectedBusiness.location,
            city: formData.city,
            state: formData.state,
            zipCode: formData.zipCode,
            latitude: formData.latitude,
            longitude: formData.longitude
          },
          socialMedia: {
            facebook: formData.socialFacebook,
            instagram: formData.socialInstagram
          }
        };

        const { error } = await businessService.updateBusiness(selectedBusiness.id, updates);

        if (error) {
          if (error.message?.includes('Database schema not applied')) {
            setError('❌ Database-Fehler: Die Datenbank-Migration wurde noch nicht angewendet. Bitte wenden Sie sich an den Support.');
          } else {
            setError('Fehler beim Speichern: ' + error.message);
          }
        } else {
          setSuccess('✅ Unternehmen erfolgreich aktualisiert!');
          setIsEditing(false);
          await loadBusinesses();
          
          // Update selected business with new data
          const updatedBusiness = await businessService.getBusinessById(selectedBusiness.id);
          if (updatedBusiness) {
            setSelectedBusiness(updatedBusiness);
          }
        }
      }
    } catch (err: any) {
      setError('Unerwarteter Fehler beim Speichern: ' + (err.message || 'Unbekannter Fehler'));
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    if (isCreating) {
      setIsCreating(false);
      resetForm();
    } else if (selectedBusiness) {
      setFormData({
        name: selectedBusiness.name,
        category: selectedBusiness.category,
        address: selectedBusiness.address,
        phone: selectedBusiness.phone || '',
        website: selectedBusiness.website || '',
        email: selectedBusiness.email || '',
        description: selectedBusiness.description,
        priceRange: selectedBusiness.priceRange,
        features: selectedBusiness.features,
        socialFacebook: selectedBusiness.socialMedia?.facebook || '',
        socialInstagram: selectedBusiness.socialMedia?.instagram || '',
        city: selectedBusiness.location?.city || '',
        state: selectedBusiness.location?.state || 'Deutschland',
        zipCode: selectedBusiness.location?.zipCode || '',
        latitude: selectedBusiness.location?.latitude || 0,
        longitude: selectedBusiness.location?.longitude || 0
      });
      setIsEditing(false);
    }
    setError(null);
    setSuccess(null);
  };

  const handleLogout = async () => {
    const { error } = await signOut();
    if (!error) {
      navigate('/login');
    }
  };

  const handleFeatureChange = (feature: string, checked: boolean) => {
    if (checked) {
      setFormData(prev => ({
        ...prev,
        features: [...prev.features, feature]
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        features: prev.features.filter(f => f !== feature)
      }));
    }
  };

  const availableFeatures = [
    'WLAN kostenlos',
    'Terrasse',
    'Hausgemachte Kuchen',
    'Vegane Optionen',
    'Zeitungen',
    'Kinderfreundlich',
    'Reservierungen',
    'Internationale Küche',
    'Weinauswahl',
    'Lieferservice',
    'Catering',
    'Parkplätze'
  ];

  // Add to favorites function
  const handleAddToFavorites = async () => {
    if (!selectedBusiness || !user) return;
    
    // Mock implementation - in real app, this would call the favorites API
    setSuccess('✅ Zu Favoriten hinzugefügt!');
    setTimeout(() => setSuccess(null), 3000);
  };

  // Generate URL for preview
  const getPreviewUrl = (businessId: string) => {
    return `/business-details?id=${businessId}`;
  };

  // Loading state with better error handling
  if (loading && businesses.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <MainHeader 
          isAuthenticated={!!user} 
          user={profile} 
          onLogin={() => {}} 
          onLogout={handleLogout} 
        />
        <div className="pt-16 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-muted-foreground">Lade Dashboard...</p>
            {error && (
              <div className="mt-4 p-4 bg-error/10 border border-error/20 rounded-lg max-w-md">
                <p className="text-error text-sm">{error}</p>
                <Button 
                  onClick={loadBusinesses} 
                  variant="outline" 
                  size="sm" 
                  className="mt-2"
                >
                  Erneut versuchen
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <MainHeader 
        isAuthenticated={!!user} 
        user={profile} 
        onLogin={() => {}} 
        onLogout={handleLogout} 
      />

      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 lg:px-6 py-6">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-foreground mb-2">
                  Superadmin Dashboard
                </h1>
                <p className="text-muted-foreground">
                  Verwalten Sie alle registrierten Unternehmen in Ihrem Business Directory
                </p>
              </div>
              <Button 
                onClick={handleStartCreate}
                iconName="Plus" 
                iconPosition="left"
                size="lg"
              >
                Neues Unternehmen registrieren
              </Button>
            </div>
          </div>

          {/* Global Error Display */}
          {error && (
            <div className="mb-6 p-4 bg-error/10 border border-error/20 rounded-lg">
              <div className="flex items-start space-x-3">
                <Icon name="AlertCircle" size={20} className="text-error flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-error text-sm whitespace-pre-wrap">{error}</p>
                  {error.includes('Database schema not applied') && (
                    <div className="mt-3 p-3 bg-info/10 border border-info/20 rounded">
                      <p className="text-info text-sm">
                        <strong>Lösung:</strong> Die Datenbank-Migration muss angewendet werden. 
                        Bitte wenden Sie sich an den Support oder führen Sie die Migration manuell aus.
                      </p>
                    </div>
                  )}
                </div>
                <Button 
                  onClick={() => setError(null)} 
                  variant="ghost" 
                  size="sm"
                  iconName="X"
                />
              </div>
            </div>
          )}

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Business List */}
            <div className="lg:col-span-1">
              <div className="bg-card rounded-lg shadow-sm border border-border p-6">
                <h2 className="text-xl font-semibold text-card-foreground mb-4 flex items-center space-x-2">
                  <Icon name="Building" size={20} className="text-primary" />
                  <span>Unternehmen ({businesses.length})</span>
                </h2>

                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {businesses.map((business) => (
                    <div
                      key={business.id}
                      onClick={() => handleSelectBusiness(business)}
                      className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                        selectedBusiness?.id === business.id
                          ? 'bg-primary/10 border-primary' :'bg-card border-border hover:bg-muted'
                      }`}
                    >
                      <h3 className="font-medium text-card-foreground">{business.name}</h3>
                      <p className="text-sm text-muted-foreground">{business.category}</p>
                      <p className="text-sm text-muted-foreground">{business.location?.city || 'Unbekannte Stadt'}</p>
                      <div className="flex items-center space-x-2 mt-1">
                        <div className="flex items-center">
                          <Icon name="Star" size={12} className="text-yellow-500 fill-current" />
                          <span className="text-xs text-muted-foreground ml-1">
                            {business.rating} ({business.reviewCount})
                          </span>
                        </div>
                        {business.verified && (
                          <Icon name="CheckCircle" size={12} className="text-green-500" />
                        )}
                      </div>
                    </div>
                  ))}

                  {businesses.length === 0 && !loading && (
                    <div className="text-center py-8">
                      <Icon name="Building" size={48} className="text-muted-foreground mx-auto mb-4" />
                      <p className="text-muted-foreground text-sm">Keine Unternehmen gefunden</p>
                      <p className="text-muted-foreground text-xs mt-2">
                        Erstellen Sie Ihr erstes Unternehmen über den Button oben
                      </p>
                      <Button 
                        onClick={loadBusinesses} 
                        variant="outline" 
                        size="sm" 
                        className="mt-2"
                        iconName="RefreshCw"
                        iconPosition="left"
                      >
                        Neu laden
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Business Details Editor */}
            <div className="lg:col-span-2">
              {(selectedBusiness || isCreating) ? (
                <div className="bg-card rounded-lg shadow-sm border border-border p-6">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-xl font-semibold text-card-foreground">
                      {isCreating ? 'Neues Unternehmen registrieren' : isEditing ?'Unternehmen bearbeiten' : 'Unternehmensdetails'}
                    </h2>
                    <div className="flex space-x-2">
                      {!isEditing && !isCreating ? (
                        <>
                          <Button 
                            variant="outline"
                            onClick={() => loadBusinessReviews(selectedBusiness!.id)} 
                            iconName="Star" 
                            iconPosition="left"
                            size="sm"
                          >
                            Bewertungen
                          </Button>
                          <Button onClick={() => setIsEditing(true)} iconName="Edit" iconPosition="left">
                            Bearbeiten
                          </Button>
                        </>
                      ) : (
                        <>
                          <Button variant="outline" onClick={handleCancel}>
                            Abbrechen
                          </Button>
                          <Button onClick={handleSave} disabled={loading} iconName="Save" iconPosition="left">
                            {loading ? 'Speichern...' : isCreating ? 'Erstellen' : 'Speichern'}
                          </Button>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Success Messages */}
                  {success && (
                    <div className="mb-4 p-3 bg-green-100 border border-green-200 rounded-lg">
                      <p className="text-green-800 text-sm">{success}</p>
                    </div>
                  )}

                  {/* Reviews Section */}
                  {showReviews && !isCreating && (
                    <div className="mb-6 p-4 bg-muted/30 rounded-lg">
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-medium text-card-foreground flex items-center space-x-2">
                          <Icon name="Star" size={18} className="text-primary" />
                          <span>Bewertungen ({reviews.length})</span>
                        </h3>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => setShowReviews(false)}
                          iconName="X"
                        />
                      </div>
                      
                      <div className="space-y-4 max-h-64 overflow-y-auto">
                        {reviews.map((review) => (
                          <div key={review.id} className="bg-card p-3 rounded border">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center space-x-2">
                                <span className="font-medium text-sm">{review.userName}</span>
                                <div className="flex items-center">
                                  {Array.from({ length: review.rating }, (_, i) => (
                                    <Icon key={i} name="Star" size={12} className="text-warning fill-current" />
                                  ))}
                                </div>
                              </div>
                              <span className="text-xs text-muted-foreground">
                                {new Date(review.date).toLocaleDateString('de-DE')}
                              </span>
                            </div>
                            <p className="text-sm text-muted-foreground">{review.comment}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="space-y-6">
                    {/* Basic Information */}
                    <div>
                      <h3 className="text-lg font-medium text-card-foreground mb-4">Grundinformationen</h3>
                      <div className="grid md:grid-cols-2 gap-4">
                        <Input
                          label="Titel *"
                          value={formData.name}
                          onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                          disabled={!isEditing && !isCreating}
                          required
                        />
                        <Select
                          label="Kategorie *"
                          value={formData.category}
                          onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                          disabled={!isEditing && !isCreating}
                          required
                        >
                          <option value="">Kategorie wählen</option>
                          {businessCategories.map(cat => (
                            <option key={cat} value={cat}>{cat}</option>
                          ))}
                        </Select>
                        <div className="md:col-span-2">
                          <Input
                            label="Adresse *"
                            value={formData.address}
                            onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                            disabled={!isEditing && !isCreating}
                            required
                          />
                        </div>
                        <Input
                          label="Stadt *"
                          value={formData.city}
                          onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
                          disabled={!isEditing && !isCreating}
                          required
                        />
                        <Input
                          label="PLZ"
                          value={formData.zipCode}
                          onChange={(e) => setFormData(prev => ({ ...prev, zipCode: e.target.value }))}
                          disabled={!isEditing && !isCreating}
                        />
                        <Input
                          label="Telefon (Anrufen)"
                          value={formData.phone}
                          onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                          disabled={!isEditing && !isCreating}
                        />
                        <Input
                          label="Website"
                          value={formData.website}
                          onChange={(e) => setFormData(prev => ({ ...prev, website: e.target.value }))}
                          disabled={!isEditing && !isCreating}
                          placeholder="https://example.com"
                        />
                        <Input
                          label="E-Mail"
                          type="email"
                          value={formData.email}
                          onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                          disabled={!isEditing && !isCreating}
                        />
                        <Select
                          label="Preisbereich"
                          value={formData.priceRange}
                          onChange={(e) => setFormData(prev => ({ ...prev, priceRange: e.target.value }))}
                          disabled={!isEditing && !isCreating}
                        >
                          <option value="€">€ - Günstig</option>
                          <option value="€€">€€ - Moderat</option>
                          <option value="€€€">€€€ - Gehobene Preise</option>
                          <option value="€€€€">€€€€ - Luxus</option>
                        </Select>
                      </div>
                    </div>

                    {/* Description */}
                    <div>
                      <h3 className="text-lg font-medium text-card-foreground mb-4">Über uns</h3>
                      <textarea
                        className="w-full h-32 px-3 py-2 border border-border rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary disabled:bg-muted disabled:cursor-not-allowed"
                        value={formData.description}
                        onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                        disabled={!isEditing && !isCreating}
                        placeholder="Beschreibung des Unternehmens..."
                      />
                    </div>

                    {/* Features */}
                    <div>
                      <h3 className="text-lg font-medium text-card-foreground mb-4">Features</h3>
                      <div className="grid md:grid-cols-3 gap-2">
                        {availableFeatures.map((feature) => (
                          <label key={feature} className="flex items-center space-x-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={formData.features.includes(feature)}
                              onChange={(e) => handleFeatureChange(feature, e.target.checked)}
                              disabled={!isEditing && !isCreating}
                              className="rounded border-border text-primary focus:ring-primary/20"
                            />
                            <span className="text-sm text-card-foreground">{feature}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* Social Media */}
                    <div>
                      <h3 className="text-lg font-medium text-card-foreground mb-4">Social Media</h3>
                      <div className="grid md:grid-cols-2 gap-4">
                        <Input
                          label="Facebook"
                          value={formData.socialFacebook}
                          onChange={(e) => setFormData(prev => ({ ...prev, socialFacebook: e.target.value }))}
                          disabled={!isEditing && !isCreating}
                          placeholder="https://facebook.com/..."
                        />
                        <Input
                          label="Instagram"
                          value={formData.socialInstagram}
                          onChange={(e) => setFormData(prev => ({ ...prev, socialInstagram: e.target.value }))}
                          disabled={!isEditing && !isCreating}
                          placeholder="https://instagram.com/..."
                        />
                      </div>
                    </div>

                    {/* Location Coordinates (Optional) */}
                    {(isEditing || isCreating) && (
                      <div>
                        <h3 className="text-lg font-medium text-card-foreground mb-4">
                          GPS-Koordinaten (Optional)
                        </h3>
                        <div className="grid md:grid-cols-2 gap-4">
                          <Input
                            label="Breitengrad"
                            type="number"
                            step="any"
                            value={formData.latitude}
                            onChange={(e) => setFormData(prev => ({ ...prev, latitude: parseFloat(e.target.value) || 0 }))}
                            disabled={!isEditing && !isCreating}
                            placeholder="52.520008"
                          />
                          <Input
                            label="Längengrad"
                            type="number"
                            step="any"
                            value={formData.longitude}
                            onChange={(e) => setFormData(prev => ({ ...prev, longitude: parseFloat(e.target.value) || 0 }))}
                            disabled={!isEditing && !isCreating}
                            placeholder="13.404954"
                          />
                        </div>
                      </div>
                    )}

                    {/* Operating Hours Display */}
                    {selectedBusiness && !isCreating && (
                      <div>
                        <h3 className="text-lg font-medium text-card-foreground mb-4">Öffnungszeiten</h3>
                        <div className="space-y-2">
                          {selectedBusiness.operatingHours && Object.entries(selectedBusiness.operatingHours).map(([day, hours]) => (
                            <div key={day} className="flex justify-between items-center py-2 border-b border-border">
                              <span className="text-card-foreground capitalize">
                                {day === 'monday' ? 'Montag' :
                                 day === 'tuesday' ? 'Dienstag' :
                                 day === 'wednesday' ? 'Mittwoch' :
                                 day === 'thursday' ? 'Donnerstag' :
                                 day === 'friday' ? 'Freitag' :
                                 day === 'saturday' ? 'Samstag' : 'Sonntag'}
                              </span>
                              <span className="text-muted-foreground">
                                {hours?.isOpen ? `${hours.openTime} - ${hours.closeTime}` : 'Geschlossen'}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="bg-card rounded-lg shadow-sm border border-border p-6">
                  <div className="text-center py-12">
                    <Icon name="Building" size={48} className="text-muted-foreground mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-card-foreground mb-2">
                      Kein Unternehmen ausgewählt
                    </h3>
                    <p className="text-muted-foreground mb-4">
                      Wählen Sie ein Unternehmen aus der Liste links aus, um es zu bearbeiten.
                    </p>
                    <Button 
                      onClick={handleStartCreate}
                      iconName="Plus" 
                      iconPosition="left"
                    >
                      Neues Unternehmen registrieren
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Schnellaktionen Module */}
          <div className="mt-8">
            <div className="bg-card rounded-lg shadow-sm border border-border p-6">
              <h2 className="text-xl font-semibold text-card-foreground mb-4 flex items-center space-x-2">
                <Icon name="Zap" size={20} className="text-primary" />
                <span>Schnellaktionen</span>
              </h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Button
                  variant="outline"
                  fullWidth
                  onClick={() => navigate('/business-directory')}
                  iconName="Search"
                  iconPosition="left"
                >
                  Business Directory
                </Button>
                <Button
                  variant="outline"
                  fullWidth
                  onClick={() => selectedBusiness && window.open(getPreviewUrl(selectedBusiness.id), '_blank')}
                  disabled={!selectedBusiness}
                  iconName="ExternalLink"
                  iconPosition="left"
                >
                  Vorschau anzeigen
                </Button>
                <Button
                  variant="outline"
                  fullWidth
                  onClick={handleAddToFavorites}
                  disabled={!selectedBusiness}
                  iconName="Heart"
                  iconPosition="left"
                >
                  Zu Favoriten hinzufügen
                </Button>
                <Button
                  variant="outline"
                  fullWidth
                  onClick={loadBusinesses}
                  iconName="RefreshCw"
                  iconPosition="left"
                >
                  Liste aktualisieren
                </Button>
              </div>
              
              {selectedBusiness && (
                <div className="mt-6 pt-6 border-t border-border">
                  <h3 className="text-lg font-medium text-card-foreground mb-3 flex items-center space-x-2">
                    <Icon name="Star" size={18} className="text-primary" />
                    <span>Bewertungen verwalten</span>
                  </h3>
                  <div className="grid md:grid-cols-3 gap-4">
                    <Button
                      variant="outline"
                      fullWidth
                      onClick={() => loadBusinessReviews(selectedBusiness.id)}
                      iconName="Eye"
                      iconPosition="left"
                    >
                      Bewertungen anzeigen
                    </Button>
                    <Button
                      variant="outline"
                      fullWidth
                      onClick={() => window.open(`${getPreviewUrl(selectedBusiness.id)}#write-review`, '_blank')}
                      iconName="Edit"
                      iconPosition="left"
                    >
                      Bewertung schreiben
                    </Button>
                    <Button
                      variant="outline"
                      fullWidth
                      onClick={handleLogout}
                      iconName="LogOut"
                      iconPosition="left"
                    >
                      Abmelden
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;