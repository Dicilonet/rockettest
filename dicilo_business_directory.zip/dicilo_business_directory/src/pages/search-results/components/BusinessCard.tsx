import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import { Business } from '../types';

interface BusinessCardProps {
  business: Business;
  onToggleFavorite: (businessId: string) => void;
  onViewDetails: (businessId: string) => void;
}

const BusinessCard = ({
  business,
  onToggleFavorite,
  onViewDetails
}: BusinessCardProps) => {
  const navigate = useNavigate();

  const handleCardClick = () => {
    navigate('/business-details', { 
      state: { 
        businessId: business.id,
        businessName: business.name 
      } 
    });
  };

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleFavorite(business.id);
  };

  const handleViewDetails = (e: React.MouseEvent) => {
    e.stopPropagation();
    onViewDetails(business.id);
  };

  const getPriceRangeDisplay = (priceRange: string) => {
    return priceRange;
  };

  const formatDistance = (distance: number) => {
    if (distance < 1) {
      return `${Math.round(distance * 1000)}m`;
    }
    return `${distance.toFixed(1)}km`;
  };

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Icon key={i} name="Star" size={14} className="text-yellow-400 fill-current" />
      );
    }

    if (hasHalfStar) {
      stars.push(
        <Icon key="half" name="StarHalf" size={14} className="text-yellow-400 fill-current" />
      );
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(
        <Icon key={`empty-${i}`} name="Star" size={14} className="text-gray-300" />
      );
    }

    return stars;
  };

  return (
    <div 
      className="bg-card border border-border rounded-lg overflow-hidden hover:shadow-lg transition-all duration-300 cursor-pointer group"
      onClick={handleCardClick}
    >
      {/* Image */}
      <div className="relative h-48 overflow-hidden">
        <Image
          src={business.image}
          alt={business.alt}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-3 right-3 flex space-x-2">
          <button
            onClick={handleFavoriteClick}
            className="w-8 h-8 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center hover:bg-white transition-colors duration-200"
          >
            <Icon 
              name="Heart" 
              size={16} 
              className={business.isFavorite ? 'text-red-500 fill-current' : 'text-gray-600'} 
            />
          </button>
        </div>
        <div className="absolute bottom-3 left-3 flex space-x-2">
          {business.isOpen ? (
            <span className="bg-green-500 text-white px-2 py-1 rounded-full text-xs font-medium">
              Geöffnet
            </span>
          ) : (
            <span className="bg-red-500 text-white px-2 py-1 rounded-full text-xs font-medium">
              Geschlossen
            </span>
          )}
          <span className="bg-black/70 text-white px-2 py-1 rounded-full text-xs font-medium">
            {getPriceRangeDisplay(business.priceRange)}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Header */}
        <div className="flex items-start justify-between mb-2">
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-semibold text-card-foreground truncate group-hover:text-primary transition-colors duration-200">
              {business.name}
            </h3>
            <p className="text-sm text-muted-foreground">{business.category}</p>
          </div>
          <div className="flex items-center space-x-1 ml-2">
            <Icon name="MapPin" size={14} className="text-muted-foreground" />
            <span className="text-sm text-muted-foreground">
              {formatDistance(business.distance)}
            </span>
          </div>
        </div>

        {/* Rating */}
        <div className="flex items-center space-x-2 mb-3">
          <div className="flex items-center space-x-1">
            {renderStars(business.rating)}
          </div>
          <span className="text-sm font-medium text-card-foreground">
            {business.rating.toFixed(1)}
          </span>
          <span className="text-sm text-muted-foreground">
            ({business.reviewCount} Bewertungen)
          </span>
        </div>

        {/* Description */}
        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
          {business.description}
        </p>

        {/* Features */}
        {business.features.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-4">
            {business.features.slice(0, 3).map((feature, index) => (
              <span
                key={index}
                className="bg-muted text-muted-foreground px-2 py-1 rounded-full text-xs"
              >
                {feature}
              </span>
            ))}
            {business.features.length > 3 && (
              <span className="text-xs text-muted-foreground px-2 py-1">
                +{business.features.length - 3} weitere
              </span>
            )}
          </div>
        )}

        {/* Address */}
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="MapPin" size={14} className="text-muted-foreground" />
          <span className="text-sm text-muted-foreground truncate">
            {business.address}
          </span>
        </div>

        {/* Actions */}
        <div className="flex space-x-2">
          <Button
            variant="default"
            size="sm"
            onClick={handleViewDetails}
            iconName="Eye"
            iconPosition="left"
            className="flex-1"
          >
            Details
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              window.open(`tel:${business.phone}`, '_self');
            }}
            iconName="Phone"
            className="px-3"
          />
          {business.website && (
            <Button
              variant="outline"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                window.open(business.website, '_blank');
              }}
              iconName="ExternalLink"
              className="px-3"
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default BusinessCard;