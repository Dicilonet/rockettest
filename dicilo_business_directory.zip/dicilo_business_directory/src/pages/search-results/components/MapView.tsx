import React from 'react';
import Icon from '../../../components/AppIcon';
import { Business } from '../types';

interface MapViewProps {
  businesses: Business[];
  selectedBusiness?: Business | null;
  onBusinessSelect: (business: Business) => void;
  center: { lat: number; lng: number };
}

const MapView = ({
  businesses,
  selectedBusiness,
  onBusinessSelect,
  center
}: MapViewProps) => {
  return (
    <div className="relative h-full bg-muted rounded-lg overflow-hidden">
      {/* Google Maps Iframe */}
      <iframe
        width="100%"
        height="100%"
        loading="lazy"
        title="Business Locations Map"
        referrerPolicy="no-referrer-when-downgrade"
        src={`https://www.google.com/maps?q=${center.lat},${center.lng}&z=12&output=embed`}
        className="border-0"
      />

      {/* Map Controls */}
      <div className="absolute top-4 right-4 bg-card border border-border rounded-lg shadow-lg">
        <div className="flex flex-col">
          <button className="p-2 hover:bg-muted transition-colors duration-200 border-b border-border">
            <Icon name="Plus" size={16} />
          </button>
          <button className="p-2 hover:bg-muted transition-colors duration-200">
            <Icon name="Minus" size={16} />
          </button>
        </div>
      </div>

      {/* Business Markers Overlay */}
      <div className="absolute inset-0 pointer-events-none">
        {businesses.slice(0, 10).map((business, index) => (
          <div
            key={business.id}
            className="absolute pointer-events-auto"
            style={{
              left: `${20 + (index % 3) * 30}%`,
              top: `${20 + Math.floor(index / 3) * 25}%`
            }}
          >
            <button
              onClick={() => onBusinessSelect(business)}
              className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold shadow-lg transition-all duration-200 hover:scale-110 ${
                selectedBusiness?.id === business.id
                  ? 'bg-primary ring-2 ring-white' :'bg-red-500 hover:bg-red-600'
              }`}
              title={business.name}
            >
              {index + 1}
            </button>
          </div>
        ))}
      </div>

      {/* Selected Business Info */}
      {selectedBusiness && (
        <div className="absolute bottom-4 left-4 right-4 bg-card border border-border rounded-lg shadow-lg p-4">
          <div className="flex items-start space-x-3">
            <div className="w-12 h-12 bg-muted rounded-lg overflow-hidden flex-shrink-0">
              <img
                src={selectedBusiness.image}
                alt={selectedBusiness.alt}
                className="w-full h-full object-cover"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = '/assets/images/no_image.png';
                }}
              />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-card-foreground truncate">
                {selectedBusiness.name}
              </h4>
              <p className="text-sm text-muted-foreground">
                {selectedBusiness.category}
              </p>
              <div className="flex items-center space-x-2 mt-1">
                <div className="flex items-center space-x-1">
                  <Icon name="Star" size={12} className="text-yellow-400 fill-current" />
                  <span className="text-xs text-card-foreground">
                    {selectedBusiness.rating.toFixed(1)}
                  </span>
                </div>
                <span className="text-xs text-muted-foreground">
                  {selectedBusiness.distance.toFixed(1)}km
                </span>
              </div>
            </div>
            <button
              onClick={() => onBusinessSelect(selectedBusiness)}
              className="p-1 hover:bg-muted rounded transition-colors duration-200"
            >
              <Icon name="X" size={16} />
            </button>
          </div>
        </div>
      )}

      {/* Map Legend */}
      <div className="absolute top-4 left-4 bg-card border border-border rounded-lg shadow-lg p-3">
        <div className="flex items-center space-x-2 text-sm">
          <div className="w-4 h-4 bg-red-500 rounded-full"></div>
          <span className="text-card-foreground">Unternehmen</span>
        </div>
        <div className="flex items-center space-x-2 text-sm mt-1">
          <div className="w-4 h-4 bg-primary rounded-full"></div>
          <span className="text-card-foreground">Ausgewählt</span>
        </div>
      </div>
    </div>
  );
};

export default MapView;