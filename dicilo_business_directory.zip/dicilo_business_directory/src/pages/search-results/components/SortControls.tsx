import React from 'react';
import Icon from '../../../components/AppIcon';
import Select from '../../../components/ui/Select';
import { SortOption } from '../types';

interface SortControlsProps {
  sortBy: string;
  onSortChange: (sortBy: string) => void;
  resultsCount: number;
}

const SortControls = ({
  sortBy,
  onSortChange,
  resultsCount
}: SortControlsProps) => {
  const sortOptions: SortOption[] = [
    { value: 'relevance', label: 'Relevanz', icon: 'Target' },
    { value: 'distance', label: 'Entfernung', icon: 'MapPin' },
    { value: 'rating', label: 'Bewertung', icon: 'Star' },
    { value: 'name', label: 'Name A-Z', icon: 'ArrowUpAZ' },
    { value: 'newest', label: 'Neueste zuerst', icon: 'Clock' }
  ];

  const currentSort = sortOptions.find(option => option.value === sortBy) || sortOptions[0];

  return (
    <div className="flex items-center justify-between bg-muted/50 px-4 py-3 rounded-lg">
      <div className="flex items-center space-x-2 text-sm text-muted-foreground">
        <Icon name="LayoutGrid" size={16} />
        <span>
          {resultsCount.toLocaleString('de-DE')} Ergebnisse
        </span>
      </div>

      <div className="flex items-center space-x-3">
        <span className="text-sm text-muted-foreground hidden sm:block">
          Sortieren nach:
        </span>
        <div className="flex items-center space-x-2">
          <Icon name={currentSort.icon} size={16} className="text-muted-foreground" />
          <Select
            options={sortOptions.map(option => ({
              value: option.value,
              label: option.label
            }))}
            value={sortBy}
            onChange={onSortChange}
            className="min-w-32"
          />
        </div>
      </div>
    </div>
  );
};

export default SortControls;