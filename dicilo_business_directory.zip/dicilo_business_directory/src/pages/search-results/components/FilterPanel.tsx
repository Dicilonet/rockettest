import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';
import { SearchFilters, FilterOption } from '../types';

interface FilterPanelProps {
  filters: SearchFilters;
  onFiltersChange: (filters: SearchFilters) => void;
  isOpen: boolean;
  onToggle: () => void;
  className?: string;
}

const FilterPanel = ({
  filters,
  onFiltersChange,
  isOpen,
  onToggle,
  className = ''
}: FilterPanelProps) => {
  const [localFilters, setLocalFilters] = useState<SearchFilters>(filters);

  const categoryOptions: FilterOption[] = [
    { value: '', label: 'Alle Kategorien', count: 0 },
    { value: 'restaurant', label: 'Restaurants', count: 45 },
    { value: 'hotel', label: 'Hotels', count: 23 },
    { value: 'shopping', label: 'Einkaufen', count: 67 },
    { value: 'healthcare', label: 'Gesundheit', count: 34 },
    { value: 'automotive', label: 'Automotive', count: 28 },
    { value: 'beauty', label: 'Beauty & Wellness', count: 19 },
    { value: 'services', label: 'Dienstleistungen', count: 52 }
  ];

  const ratingOptions = [
    { value: 0, label: 'Alle Bewertungen' },
    { value: 4, label: '4+ Sterne' },
    { value: 4.5, label: '4.5+ Sterne' }
  ];

  const distanceOptions = [
    { value: 50, label: 'Innerhalb 50 km' },
    { value: 25, label: 'Innerhalb 25 km' },
    { value: 10, label: 'Innerhalb 10 km' },
    { value: 5, label: 'Innerhalb 5 km' }
  ];

  const priceRanges = [
    { value: '$', label: 'Günstig ($)' },
    { value: '$$', label: 'Moderat ($$)' },
    { value: '$$$', label: 'Gehoben ($$$)' },
    { value: '$$$$', label: 'Luxus ($$$$)' }
  ];

  const handleFilterChange = (key: keyof SearchFilters, value: any) => {
    const newFilters = { ...localFilters, [key]: value };
    setLocalFilters(newFilters);
  };

  const handlePriceRangeChange = (priceRange: string, checked: boolean) => {
    const currentRanges = localFilters.priceRange || [];
    const newRanges = checked
      ? [...currentRanges, priceRange]
      : currentRanges.filter(range => range !== priceRange);
    
    handleFilterChange('priceRange', newRanges);
  };

  const applyFilters = () => {
    onFiltersChange(localFilters);
    if (window.innerWidth < 1024) {
      onToggle();
    }
  };

  const resetFilters = () => {
    const defaultFilters: SearchFilters = {
      category: '',
      minRating: 0,
      maxDistance: 50,
      priceRange: [],
      isOpen: false
    };
    setLocalFilters(defaultFilters);
    onFiltersChange(defaultFilters);
  };

  const hasActiveFilters = () => {
    return localFilters.category !== '' ||
           localFilters.minRating > 0 ||
           localFilters.maxDistance < 50 ||
           localFilters.priceRange.length > 0 ||
           localFilters.isOpen;
  };

  return (
    <>
      {/* Mobile Filter Toggle */}
      <div className="lg:hidden mb-4">
        <Button
          variant="outline"
          onClick={onToggle}
          iconName="Filter"
          iconPosition="left"
          className="w-full"
        >
          Filter {hasActiveFilters() && `(${Object.values(localFilters).filter(v => v && (Array.isArray(v) ? v.length > 0 : true)).length})`}
        </Button>
      </div>

      {/* Filter Panel */}
      <div className={`${className} ${isOpen ? 'block' : 'hidden lg:block'}`}>
        <div className="bg-card border border-border rounded-lg p-4 space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-card-foreground flex items-center space-x-2">
              <Icon name="Filter" size={20} />
              <span>Filter</span>
            </h3>
            {hasActiveFilters() && (
              <Button
                variant="ghost"
                size="sm"
                onClick={resetFilters}
                className="text-muted-foreground hover:text-foreground"
              >
                Zurücksetzen
              </Button>
            )}
            <button
              onClick={onToggle}
              className="lg:hidden p-1 rounded-md hover:bg-muted transition-colors duration-200"
            >
              <Icon name="X" size={20} />
            </button>
          </div>

          {/* Category Filter */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-card-foreground">
              Kategorie
            </label>
            <Select
              options={categoryOptions.map(cat => ({
                value: cat.value,
                label: `${cat.label} ${cat.count > 0 ? `(${cat.count})` : ''}`
              }))}
              value={localFilters.category}
              onChange={(value) => handleFilterChange('category', value)}
              placeholder="Kategorie wählen"
            />
          </div>

          {/* Rating Filter */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-card-foreground">
              Mindestbewertung
            </label>
            <Select
              options={ratingOptions.map(rating => ({
                value: rating.value,
                label: rating.label
              }))}
              value={localFilters.minRating}
              onChange={(value) => handleFilterChange('minRating', value)}
            />
          </div>

          {/* Distance Filter */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-card-foreground">
              Entfernung
            </label>
            <Select
              options={distanceOptions.map(distance => ({
                value: distance.value,
                label: distance.label
              }))}
              value={localFilters.maxDistance}
              onChange={(value) => handleFilterChange('maxDistance', value)}
            />
          </div>

          {/* Price Range Filter */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-card-foreground">
              Preisklasse
            </label>
            <div className="space-y-2">
              {priceRanges.map((range) => (
                <Checkbox
                  key={range.value}
                  label={range.label}
                  checked={localFilters.priceRange.includes(range.value)}
                  onChange={(e) => handlePriceRangeChange(range.value, e.target.checked)}
                />
              ))}
            </div>
          </div>

          {/* Open Now Filter */}
          <div className="space-y-3">
            <Checkbox
              label="Nur geöffnete Unternehmen"
              checked={localFilters.isOpen}
              onChange={(e) => handleFilterChange('isOpen', e.target.checked)}
            />
          </div>

          {/* Apply Button */}
          <Button
            variant="default"
            fullWidth
            onClick={applyFilters}
            iconName="Check"
            iconPosition="left"
          >
            Filter anwenden
          </Button>
        </div>
      </div>
    </>
  );
};

export default FilterPanel;