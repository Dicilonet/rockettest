import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { SearchParams } from '../types';

interface SearchHeaderProps {
  searchParams: SearchParams;
  resultsCount: number;
  onModifySearch: () => void;
  onToggleMapView: () => void;
  isMapView: boolean;
}

const SearchHeader = ({
  searchParams,
  resultsCount,
  onModifySearch,
  onToggleMapView,
  isMapView
}: SearchHeaderProps) => {
  const formatResultsText = () => {
    if (resultsCount === 0) return 'Keine Ergebnisse gefunden';
    if (resultsCount === 1) return '1 Unternehmen gefunden';
    return `${resultsCount.toLocaleString('de-DE')} Unternehmen gefunden`;
  };

  return (
    <div className="bg-card border-b border-border p-4 lg:p-6">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
        {/* Search Context */}
        <div className="flex-1">
          <div className="flex flex-wrap items-center gap-2 mb-2">
            {searchParams.query && (
              <div className="flex items-center space-x-2 bg-primary/10 text-primary px-3 py-1 rounded-full text-sm">
                <Icon name="Search" size={14} />
                <span>"{searchParams.query}"</span>
              </div>
            )}
            {searchParams.location && (
              <div className="flex items-center space-x-2 bg-secondary/10 text-secondary px-3 py-1 rounded-full text-sm">
                <Icon name="MapPin" size={14} />
                <span>{searchParams.location}</span>
              </div>
            )}
            {searchParams.category && (
              <div className="flex items-center space-x-2 bg-accent/10 text-accent px-3 py-1 rounded-full text-sm">
                <Icon name="Tag" size={14} />
                <span>{searchParams.category}</span>
              </div>
            )}
          </div>
          <p className="text-sm text-muted-foreground">
            {formatResultsText()}
            {searchParams.location && ` in ${searchParams.location}`}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center space-x-3">
          <Button
            variant="outline"
            size="sm"
            onClick={onModifySearch}
            iconName="Filter"
            iconPosition="left"
          >
            Suche ändern
          </Button>
          <Button
            variant={isMapView ? "default" : "outline"}
            size="sm"
            onClick={onToggleMapView}
            iconName={isMapView ? "List" : "Map"}
            iconPosition="left"
          >
            {isMapView ? 'Liste' : 'Karte'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SearchHeader;