import React from 'react';
import BusinessCard from './BusinessCard';
import { Business } from '../types';

interface BusinessGridProps {
  businesses: Business[];
  onToggleFavorite: (businessId: string) => void;
  onViewDetails: (businessId: string) => void;
  loading?: boolean;
}

const BusinessGrid = ({
  businesses,
  onToggleFavorite,
  onViewDetails,
  loading = false
}: BusinessGridProps) => {
  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {Array.from({ length: 6 }).map((_, index) => (
          <div key={index} className="bg-card border border-border rounded-lg overflow-hidden animate-pulse">
            <div className="h-48 bg-muted"></div>
            <div className="p-4 space-y-3">
              <div className="h-4 bg-muted rounded w-3/4"></div>
              <div className="h-3 bg-muted rounded w-1/2"></div>
              <div className="h-3 bg-muted rounded w-full"></div>
              <div className="h-3 bg-muted rounded w-2/3"></div>
              <div className="flex space-x-2">
                <div className="h-8 bg-muted rounded flex-1"></div>
                <div className="h-8 w-8 bg-muted rounded"></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (businesses.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
          <span className="text-2xl">🔍</span>
        </div>
        <h3 className="text-lg font-semibold text-card-foreground mb-2">
          Keine Unternehmen gefunden
        </h3>
        <p className="text-muted-foreground mb-6 max-w-md mx-auto">
          Versuchen Sie es mit anderen Suchbegriffen oder erweitern Sie Ihre Filterkriterien.
        </p>
        <div className="space-y-2 text-sm text-muted-foreground">
          <p>• Überprüfen Sie die Rechtschreibung</p>
          <p>• Verwenden Sie allgemeinere Begriffe</p>
          <p>• Erweitern Sie den Suchradius</p>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
      {businesses.map((business) => (
        <BusinessCard
          key={business.id}
          business={business}
          onToggleFavorite={onToggleFavorite}
          onViewDetails={onViewDetails}
        />
      ))}
    </div>
  );
};

export default BusinessGrid;