import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import MainHeader from '../../components/ui/MainHeader';
import BusinessNavigationBreadcrumbs from '../../components/ui/BusinessNavigationBreadcrumbs';
import AuthenticationModal from '../../components/ui/AuthenticationModal';
import SearchHeader from './components/SearchHeader';
import FilterPanel from './components/FilterPanel';
import SortControls from './components/SortControls';
import BusinessGrid from './components/BusinessGrid';
import MapView from './components/MapView';
import Pagination from './components/Pagination';
import { Business, SearchFilters, SearchParams } from './types';

const SearchResults = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [authModal, setAuthModal] = useState<{isOpen: boolean;mode: 'login' | 'register';}>({
    isOpen: false,
    mode: 'login'
  });

  // Search and filter state
  const [searchParams, setSearchParams] = useState<SearchParams>({
    query: '',
    location: '',
    category: '',
    sortBy: 'relevance',
    page: 1
  });

  const [filters, setFilters] = useState<SearchFilters>({
    category: '',
    minRating: 0,
    maxDistance: 50,
    priceRange: [],
    isOpen: false
  });

  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);
  const [isMapView, setIsMapView] = useState(false);
  const [selectedBusiness, setSelectedBusiness] = useState<Business | null>(null);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const resultsPerPage = 12;

  // Mock businesses data
  const mockBusinesses: Business[] = [
  {
    id: '1',
    name: 'Gasthof Zur Alten Post',
    category: 'Restaurant',
    rating: 4.5,
    reviewCount: 127,
    distance: 0.8,
    address: 'Hauptstraße 15, 80331 München',
    phone: '+49 89 123456',
    website: 'https://gasthof-alte-post.de',
    description: 'Traditionelles bayerisches Restaurant mit authentischer Küche und gemütlicher Atmosphäre im Herzen von München.',
    image: "https://images.unsplash.com/photo-1484063440892-03ab11fb1e04",
    alt: 'Gemütliches bayerisches Restaurant mit Holztischen und traditioneller Dekoration',
    priceRange: '$$',
    isOpen: true,
    openingHours: {
      'Mo-Fr': '11:00-22:00',
      'Sa-So': '10:00-23:00'
    },
    features: ['Biergarten', 'Parkplatz', 'Reservierung'],
    isFavorite: false
  },
  {
    id: '2',
    name: 'Hotel Vier Jahreszeiten',
    category: 'Hotel',
    rating: 4.8,
    reviewCount: 89,
    distance: 1.2,
    address: 'Maximilianstraße 17, 80539 München',
    phone: '+49 89 987654',
    website: 'https://hotel-vier-jahreszeiten.de',
    description: 'Luxuriöses 5-Sterne Hotel mit erstklassigem Service und eleganten Zimmern in bester Lage.',
    image: "https://images.unsplash.com/photo-1607550449989-e0f78408ac4b",
    alt: 'Elegante Hotellobby mit Marmorboden und luxuriöser Einrichtung',
    priceRange: '$$$$',
    isOpen: true,
    openingHours: {
      'Mo-So': '24h'
    },
    features: ['Spa', 'Restaurant', 'Concierge', 'Parkservice'],
    isFavorite: true
  },
  {
    id: '3',
    name: 'Boutique Schönheit',
    category: 'Beauty & Wellness',
    rating: 4.3,
    reviewCount: 156,
    distance: 2.1,
    address: 'Leopoldstraße 45, 80802 München',
    phone: '+49 89 555777',
    description: 'Modernes Beauty-Studio mit professionellen Behandlungen für Gesicht und Körper.',
    image: "https://images.unsplash.com/photo-1661256059201-54ac28c7449e",
    alt: 'Modernes Beauty-Studio mit weißen Behandlungsliegen und sanfter Beleuchtung',
    priceRange: '$$$',
    isOpen: false,
    openingHours: {
      'Mo-Fr': '09:00-19:00',
      'Sa': '09:00-16:00'
    },
    features: ['Gesichtsbehandlung', 'Massage', 'Maniküre'],
    isFavorite: false
  },
  {
    id: '4',
    name: 'Autowerkstatt Schmidt',
    category: 'Automotive',
    rating: 4.6,
    reviewCount: 203,
    distance: 3.5,
    address: 'Industriestraße 22, 80339 München',
    phone: '+49 89 333444',
    description: 'Zuverlässige Autowerkstatt mit über 30 Jahren Erfahrung und modernster Ausstattung.',
    image: "https://images.unsplash.com/photo-1727893141025-35d62b3f4a03",
    alt: 'Professionelle Autowerkstatt mit Hebebühnen und Mechanikern bei der Arbeit',
    priceRange: '$$',
    isOpen: true,
    openingHours: {
      'Mo-Fr': '07:00-18:00',
      'Sa': '08:00-14:00'
    },
    features: ['TÜV', 'Reparatur', 'Inspektion', 'Reifenwechsel'],
    isFavorite: false
  },
  {
    id: '5',
    name: 'Café Literatur',
    category: 'Restaurant',
    rating: 4.2,
    reviewCount: 94,
    distance: 1.8,
    address: 'Goethestraße 8, 80336 München',
    phone: '+49 89 777888',
    description: 'Gemütliches Café mit hausgemachten Kuchen und einer großen Auswahl an Büchern.',
    image: "https://images.unsplash.com/photo-1724331504791-f375eff993eb",
    alt: 'Gemütliches Café mit Bücherregalen, Holztischen und warmer Atmosphäre',
    priceRange: '$',
    isOpen: true,
    openingHours: {
      'Mo-So': '08:00-20:00'
    },
    features: ['WLAN', 'Bücher', 'Kuchen', 'Kaffee'],
    isFavorite: true
  },
  {
    id: '6',
    name: 'Fitness Studio Power',
    category: 'Dienstleistungen',
    rating: 4.4,
    reviewCount: 178,
    distance: 2.7,
    address: 'Sportstraße 33, 80809 München',
    phone: '+49 89 666555',
    description: 'Modernes Fitnessstudio mit neuesten Geräten und professioneller Betreuung.',
    image: "https://images.unsplash.com/photo-1664284602615-bc1348fa085c",
    alt: 'Modernes Fitnessstudio mit Trainingsgeräten und Menschen beim Workout',
    priceRange: '$$',
    isOpen: true,
    openingHours: {
      'Mo-Fr': '06:00-23:00',
      'Sa-So': '08:00-22:00'
    },
    features: ['Sauna', 'Kurse', 'Personal Training', 'Parkplatz'],
    isFavorite: false
  }];


  const [businesses, setBusinesses] = useState<Business[]>(mockBusinesses);
  const [filteredBusinesses, setFilteredBusinesses] = useState<Business[]>(mockBusinesses);

  // Initialize search params from URL or location state
  useEffect(() => {
    const urlParams = new URLSearchParams(location.search);
    const stateParams = location.state as SearchParams;

    setSearchParams({
      query: stateParams?.query || urlParams.get('q') || '',
      location: stateParams?.location || urlParams.get('location') || 'München',
      category: stateParams?.category || urlParams.get('category') || '',
      sortBy: urlParams.get('sort') || 'relevance',
      page: parseInt(urlParams.get('page') || '1')
    });

    if (stateParams?.filters) {
      setFilters(stateParams.filters);
    }
  }, [location]);

  // Apply filters and sorting
  useEffect(() => {
    let filtered = [...businesses];

    // Apply category filter
    if (filters.category) {
      filtered = filtered.filter((business) =>
      business.category.toLowerCase() === filters.category.toLowerCase()
      );
    }

    // Apply rating filter
    if (filters.minRating > 0) {
      filtered = filtered.filter((business) => business.rating >= filters.minRating);
    }

    // Apply distance filter
    filtered = filtered.filter((business) => business.distance <= filters.maxDistance);

    // Apply price range filter
    if (filters.priceRange.length > 0) {
      filtered = filtered.filter((business) =>
      filters.priceRange.includes(business.priceRange)
      );
    }

    // Apply open now filter
    if (filters.isOpen) {
      filtered = filtered.filter((business) => business.isOpen);
    }

    // Apply search query filter
    if (searchParams.query) {
      const query = searchParams.query.toLowerCase();
      filtered = filtered.filter((business) =>
      business.name.toLowerCase().includes(query) ||
      business.category.toLowerCase().includes(query) ||
      business.description.toLowerCase().includes(query)
      );
    }

    // Apply sorting
    switch (searchParams.sortBy) {
      case 'distance':
        filtered.sort((a, b) => a.distance - b.distance);
        break;
      case 'rating':
        filtered.sort((a, b) => b.rating - a.rating);
        break;
      case 'name':
        filtered.sort((a, b) => a.name.localeCompare(b.name, 'de'));
        break;
      case 'newest':
        // Mock newest sorting
        filtered.sort((a, b) => parseInt(b.id) - parseInt(a.id));
        break;
      default: // relevance
        // Keep original order for relevance
        break;
    }

    setFilteredBusinesses(filtered);
    setCurrentPage(1);
  }, [businesses, filters, searchParams]);

  const handleAuthenticate = (userData: any) => {
    setUser(userData);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setUser(null);
    setIsAuthenticated(false);
  };

  const handleToggleFavorite = (businessId: string) => {
    if (!isAuthenticated) {
      setAuthModal({ isOpen: true, mode: 'login' });
      return;
    }

    setBusinesses((prev) =>
    prev.map((business) =>
    business.id === businessId ?
    { ...business, isFavorite: !business.isFavorite } :
    business
    )
    );
  };

  const handleViewDetails = (businessId: string) => {
    const business = businesses.find((b) => b.id === businessId);
    navigate('/business-details', {
      state: {
        businessId,
        businessName: business?.name,
        fromSearch: true,
        searchParams
      }
    });
  };

  const handleModifySearch = () => {
    navigate('/business-directory', {
      state: {
        query: searchParams.query,
        location: searchParams.location,
        category: searchParams.category
      }
    });
  };

  const handleSortChange = (sortBy: string) => {
    setSearchParams((prev) => ({ ...prev, sortBy }));
  };

  const handleFiltersChange = (newFilters: SearchFilters) => {
    setFilters(newFilters);
  };

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBusinessSelect = (business: Business) => {
    setSelectedBusiness(selectedBusiness?.id === business.id ? null : business);
  };

  // Pagination
  const totalResults = filteredBusinesses.length;
  const totalPages = Math.ceil(totalResults / resultsPerPage);
  const startIndex = (currentPage - 1) * resultsPerPage;
  const paginatedBusinesses = filteredBusinesses.slice(startIndex, startIndex + resultsPerPage);

  const mapCenter = { lat: 48.1351, lng: 11.5820 }; // Munich coordinates

  return (
    <>
      <Helmet>
        <title>
          {searchParams.query ?
          `"${searchParams.query}" - Suchergebnisse | Dicilo Business Directory` :
          'Suchergebnisse | Dicilo Business Directory'
          }
        </title>
        <meta
          name="description"
          content={`Entdecken Sie ${totalResults} Unternehmen${searchParams.location ? ` in ${searchParams.location}` : ''}. Finden Sie die besten lokalen Geschäfte mit Bewertungen und Kontaktinformationen.`} />

      </Helmet>

      <div className="min-h-screen bg-background">
        <MainHeader
          isAuthenticated={isAuthenticated}
          user={user}
          onLogin={() => setAuthModal({ isOpen: true, mode: 'login' })}
          onLogout={handleLogout} />


        <main className="pt-16">
          <div className="max-w-7xl mx-auto px-4 lg:px-6">
            {/* Breadcrumbs */}
            <BusinessNavigationBreadcrumbs
              searchQuery={searchParams.query}
              category={searchParams.category}
              location={searchParams.location} />


            {/* Search Header */}
            <SearchHeader
              searchParams={searchParams}
              resultsCount={totalResults}
              onModifySearch={handleModifySearch}
              onToggleMapView={() => setIsMapView(!isMapView)}
              isMapView={isMapView} />


            <div className="flex flex-col lg:flex-row gap-6 py-6">
              {/* Sidebar - Filters */}
              <aside className="lg:w-80 flex-shrink-0">
                <FilterPanel
                  filters={filters}
                  onFiltersChange={handleFiltersChange}
                  isOpen={isFilterPanelOpen}
                  onToggle={() => setIsFilterPanelOpen(!isFilterPanelOpen)} />

              </aside>

              {/* Main Content */}
              <div className="flex-1 min-w-0">
                {!isMapView ?
                <>
                    {/* Sort Controls */}
                    <SortControls
                    sortBy={searchParams.sortBy || 'relevance'}
                    onSortChange={handleSortChange}
                    resultsCount={totalResults} />


                    {/* Business Grid */}
                    <div className="mt-6">
                      <BusinessGrid
                      businesses={paginatedBusinesses}
                      onToggleFavorite={handleToggleFavorite}
                      onViewDetails={handleViewDetails}
                      loading={loading} />

                    </div>

                    {/* Pagination */}
                    {totalPages > 1 &&
                  <Pagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    totalResults={totalResults}
                    resultsPerPage={resultsPerPage}
                    onPageChange={handlePageChange} />

                  }
                  </> : (

                /* Map View */
                <div className="h-[600px] lg:h-[700px]">
                    <MapView
                    businesses={filteredBusinesses}
                    selectedBusiness={selectedBusiness}
                    onBusinessSelect={handleBusinessSelect}
                    center={mapCenter} />

                  </div>)
                }
              </div>
            </div>
          </div>
        </main>

        {/* Authentication Modal */}
        <AuthenticationModal
          isOpen={authModal.isOpen}
          mode={authModal.mode}
          onClose={() => setAuthModal({ ...authModal, isOpen: false })}
          onModeChange={(mode) => setAuthModal({ ...authModal, mode })}
          onAuthenticate={handleAuthenticate} />

      </div>
    </>);

};

export default SearchResults;