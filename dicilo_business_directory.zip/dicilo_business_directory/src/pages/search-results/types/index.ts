export interface Business {
  id: string;
  name: string;
  category: string;
  rating: number;
  reviewCount: number;
  distance: number;
  address: string;
  phone: string;
  website?: string;
  description: string;
  image: string;
  alt: string;
  priceRange: '$' | '$$' | '$$$' | '$$$$';
  isOpen: boolean;
  openingHours: {
    [key: string]: string;
  };
  features: string[];
  isFavorite: boolean;
}

export interface SearchFilters {
  category: string;
  minRating: number;
  maxDistance: number;
  priceRange: string[];
  isOpen: boolean;
}

export interface SortOption {
  value: string;
  label: string;
  icon: string;
}

export interface SearchParams {
  query?: string;
  location?: string;
  category?: string;
  filters?: Partial<SearchFilters>;
  sortBy?: string;
  page?: number;
}

export interface FilterOption {
  value: string;
  label: string;
  count: number;
}