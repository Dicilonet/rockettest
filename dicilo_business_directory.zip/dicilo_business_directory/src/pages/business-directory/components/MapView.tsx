import React, { useEffect, useRef, useState, useMemo, useCallback } from 'react';
import Map, { Marker, Popup, NavigationControl, GeolocateControl } from 'react-map-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import Icon from '../../../components/AppIcon';
import { MapViewProps } from '../types';

const MapView = ({ 
  businesses, 
  selectedBusinessId, 
  onPinClick, 
  center, 
  zoom 
}: MapViewProps) => {
  const [viewState, setViewState] = useState({
    longitude: center.lng,
    latitude: center.lat,
    zoom: zoom
  });
  
  const [popupInfo, setPopupInfo] = useState<any>(null);
  const [mapError, setMapError] = useState(false);

  // Get Mapbox access token from environment
  const MAPBOX_TOKEN = import.meta.env.VITE_MAPBOX_ACCESS_TOKEN;

  // Update view state when center prop changes
  useEffect(() => {
    setViewState(prev => ({
      ...prev,
      longitude: center.lng,
      latitude: center.lat
    }));
  }, [center.lat, center.lng]);

  // Handle marker click
  const handleMarkerClick = useCallback((business: any, event: any) => {
    // Prevent map click event
    event.originalEvent?.stopPropagation();
    
    onPinClick(business.id);
    setPopupInfo(business);
  }, [onPinClick]);

  // Handle map click (close popup)
  const handleMapClick = useCallback(() => {
    setPopupInfo(null);
  }, []);

  // Close popup when selected business changes
  useEffect(() => {
    if (selectedBusinessId) {
      const selectedBusiness = businesses.find(b => b.id === selectedBusinessId);
      if (selectedBusiness) {
        setPopupInfo(selectedBusiness);
      }
    }
  }, [selectedBusinessId, businesses]);

  // Handle map errors
  const handleMapError = useCallback((error: any) => {
    console.error('Mapbox error:', error);
    setMapError(true);
  }, []);

  // Memoize markers for performance
  const markers = useMemo(() => 
    businesses.map((business) => {
      const isSelected = selectedBusinessId === business.id;
      
      return (
        <Marker
          key={business.id}
          longitude={business.coordinates.lng}
          latitude={business.coordinates.lat}
          anchor="bottom"
          onClick={(event) => handleMarkerClick(business, event)}
        >
          <div 
            className={`cursor-pointer transition-all duration-200 ${
              isSelected ? 'scale-125 z-10' : 'hover:scale-110'
            }`}
          >
            <div 
              className={`w-8 h-8 rounded-full flex items-center justify-center shadow-lg ${
                isSelected 
                  ? 'bg-green-600 border-2 border-white' :'bg-red-500 hover:bg-red-600'
              }`}
            >
              <Icon 
                name="MapPin" 
                size={16} 
                color="white" 
              />
            </div>
          </div>
        </Marker>
      );
    }),
    [businesses, selectedBusinessId, handleMarkerClick]
  );

  // Fallback UI when Mapbox fails to load
  if (mapError || !MAPBOX_TOKEN) {
    return (
      <div className="w-full h-full bg-gradient-to-br from-green-50 to-blue-50 flex flex-col items-center justify-center p-8">
        <div className="text-center mb-6">
          <Icon name="Map" size={48} className="text-muted-foreground mb-4" />
          <h3 className="text-lg font-semibold text-card-foreground mb-2">
            {!MAPBOX_TOKEN ? 'Mapbox-Konfiguration erforderlich' : 'Karte wird geladen...'}
          </h3>
          <p className="text-sm text-muted-foreground">
            {!MAPBOX_TOKEN 
              ? 'Bitte fügen Sie Ihren Mapbox-Zugriffstoken hinzu.'
              : `Die interaktive Karte mit ${businesses.length} Unternehmen wird vorbereitet.`
            }
          </p>
        </div>

        {/* Mock Business Pins */}
        <div className="relative w-full max-w-md h-64 bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-br from-green-100 to-blue-100">
            {businesses.slice(0, 6).map((business, index) => (
              <div
                key={business.id}
                className={`absolute cursor-pointer transition-all duration-200 ${
                  selectedBusinessId === business.id ? 'scale-125 z-10' : 'hover:scale-110'
                }`}
                style={{
                  left: `${20 + (index % 3) * 30}%`,
                  top: `${20 + Math.floor(index / 3) * 40}%`,
                }}
                onClick={() => onPinClick(business.id)}
              >
                <div 
                  className={`w-6 h-6 rounded-full flex items-center justify-center shadow-md ${
                    selectedBusinessId === business.id 
                      ? 'bg-green-600 border border-white' :'bg-red-500 hover:bg-red-600'
                  }`}
                >
                  <Icon name="MapPin" size={12} color="white" />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-4 text-center">
          <p className="text-xs text-muted-foreground">
            Klicken Sie auf die Pins, um Unternehmen auszuwählen
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full rounded-lg overflow-hidden">
      <Map
        {...viewState}
        onMove={(evt) => setViewState(evt.viewState)}
        onClick={handleMapClick}
        onError={handleMapError}
        mapboxAccessToken={MAPBOX_TOKEN}
        style={{ width: '100%', height: '100%' }}
        mapStyle="mapbox://styles/mapbox/streets-v12"
        attributionControl={false}
      >
        {/* Navigation Controls */}
        <NavigationControl position="top-right" />
        <GeolocateControl
          position="top-right"
          trackUserLocation={true}
          showUserHeading={true}
        />

        {/* Business Markers */}
        {markers}

        {/* Business Info Popup */}
        {popupInfo && (
          <Popup
            longitude={popupInfo.coordinates.lng}
            latitude={popupInfo.coordinates.lat}
            anchor="top"
            onClose={() => setPopupInfo(null)}
            closeButton={true}
            closeOnClick={false}
            className="business-popup"
          >
            <div className="p-2 min-w-[200px]">
              <h3 className="font-semibold text-sm mb-1">{popupInfo.name}</h3>
              <p className="text-xs text-gray-600 mb-2">{popupInfo.address}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-1">
                  <Icon name="Star" size={12} className="text-yellow-400 fill-current" />
                  <span className="text-xs">{popupInfo.rating}</span>
                  <span className="text-xs text-gray-500">({popupInfo.reviewCount})</span>
                </div>
                <span 
                  className={`text-xs px-2 py-1 rounded-full ${
                    popupInfo.isOpen 
                      ? 'bg-green-100 text-green-800' :'bg-red-100 text-red-800'
                  }`}
                >
                  {popupInfo.isOpen ? 'Geöffnet' : 'Geschlossen'}
                </span>
              </div>
            </div>
          </Popup>
        )}

        {/* Legend */}
        <div className="absolute bottom-4 left-4 bg-white rounded-md shadow-md p-3">
          <div className="flex items-center space-x-2 text-sm">
            <div className="w-4 h-4 bg-red-500 rounded-full flex items-center justify-center">
              <Icon name="MapPin" size={10} color="white" />
            </div>
            <span className="text-gray-700">Unternehmen</span>
          </div>
          <div className="flex items-center space-x-2 text-sm mt-1">
            <div className="w-4 h-4 bg-green-600 rounded-full flex items-center justify-center">
              <Icon name="MapPin" size={10} color="white" />
            </div>
            <span className="text-gray-700">Ausgewählt</span>
          </div>
        </div>
      </Map>
    </div>
  );
};

export default MapView;