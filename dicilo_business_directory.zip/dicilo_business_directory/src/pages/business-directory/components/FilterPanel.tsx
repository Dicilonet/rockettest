import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { Checkbox } from '../../../components/ui/Checkbox';
import { FilterPanelProps } from '../types';

const FilterPanel = ({ 
  filters, 
  onFiltersChange, 
  categories, 
  isOpen, 
  onToggle 
}: FilterPanelProps) => {
  const distanceOptions = [
    { value: '1', label: '1 km' },
    { value: '5', label: '5 km' },
    { value: '10', label: '10 km' },
    { value: '25', label: '25 km' },
    { value: '50', label: '50 km' }
  ];

  const sortOptions = [
    { value: 'relevance', label: 'Relevanz' },
    { value: 'rating', label: 'Bewertung' },
    { value: 'distance', label: 'Entfernung' },
    { value: 'name', label: 'Name A-Z' }
  ];

  const handleDistanceChange = (value: string) => {
    onFiltersChange({ ...filters, distance: parseInt(value) });
  };

  const handleOpenNowChange = (checked: boolean) => {
    onFiltersChange({ ...filters, isOpen: checked });
  };

  const handleCategoryToggle = (categoryValue: string, checked: boolean) => {
    // For simplicity, we'll handle single category selection
    onFiltersChange({ 
      ...filters, 
      category: checked ? categoryValue : '' 
    });
  };

  const resetFilters = () => {
    onFiltersChange({
      query: '',
      location: '',
      category: '',
      rating: 0,
      priceRange: '',
      distance: 10,
      isOpen: false
    });
  };

  return (
    <>
      {/* Mobile Filter Toggle */}
      <div className="lg:hidden mb-4">
        <Button
          variant="outline"
          onClick={onToggle}
          iconName={isOpen ? "X" : "Filter"}
          iconPosition="left"
          fullWidth
        >
          {isOpen ? 'Filter schließen' : 'Filter anzeigen'}
        </Button>
      </div>

      {/* Filter Panel */}
      <div className={`bg-card border border-border rounded-lg shadow-sm ${
        isOpen ? 'block' : 'hidden lg:block'
      }`}>
        <div className="p-4">
          {/* Header */}
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-card-foreground flex items-center space-x-2">
              <Icon name="Filter" size={20} />
              <span>Filter</span>
            </h3>
            <Button
              variant="ghost"
              size="sm"
              onClick={resetFilters}
              className="text-muted-foreground hover:text-foreground"
            >
              Zurücksetzen
            </Button>
          </div>

          {/* Distance Filter */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-card-foreground mb-2">
              Umkreis
            </label>
            <Select
              options={distanceOptions}
              value={filters.distance.toString()}
              onChange={handleDistanceChange}
              placeholder="Entfernung wählen"
            />
          </div>

          {/* Open Now Filter */}
          <div className="mb-6">
            <Checkbox
              label="Nur geöffnete Unternehmen"
              checked={filters.isOpen}
              onChange={(e) => handleOpenNowChange(e.target.checked)}
            />
          </div>

          {/* Categories Filter */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-card-foreground mb-3">
              Kategorien
            </label>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {categories.map((category) => (
                <div key={category.value} className="flex items-center justify-between">
                  <Checkbox
                    label={category.label}
                    checked={filters.category === category.value}
                    onChange={(e) => handleCategoryToggle(category.value, e.target.checked)}
                  />
                  <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">
                    {category.count}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Price Range Filter */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-card-foreground mb-3">
              Preisklasse
            </label>
            <div className="space-y-2">
              {[
                { value: 'low', label: '€ - Günstig', description: 'Bis 15€ pro Person' },
                { value: 'medium', label: '€€ - Mittel', description: '15-30€ pro Person' },
                { value: 'high', label: '€€€ - Gehoben', description: 'Über 30€ pro Person' }
              ].map((price) => (
                <div key={price.value}>
                  <Checkbox
                    label={price.label}
                    description={price.description}
                    checked={filters.priceRange === price.value}
                    onChange={(e) => onFiltersChange({ 
                      ...filters, 
                      priceRange: e.target.checked ? price.value : '' 
                    })}
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Rating Filter */}
          <div className="mb-6">
            <label className="block text-sm font-medium text-card-foreground mb-3">
              Mindestbewertung
            </label>
            <div className="space-y-2">
              {[
                { value: 4, label: '4+ Sterne' },
                { value: 3, label: '3+ Sterne' },
                { value: 2, label: '2+ Sterne' }
              ].map((rating) => (
                <div key={rating.value} className="flex items-center space-x-2">
                  <Checkbox
                    checked={filters.rating === rating.value}
                    onChange={(e) => onFiltersChange({ 
                      ...filters, 
                      rating: e.target.checked ? rating.value : 0 
                    })}
                  />
                  <div className="flex items-center space-x-1">
                    {Array.from({ length: rating.value }, (_, i) => (
                      <Icon key={i} name="Star" size={14} className="text-yellow-400 fill-current" />
                    ))}
                    <span className="text-sm text-card-foreground ml-1">
                      {rating.label}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Sort Options */}
          <div className="mb-4">
            <label className="block text-sm font-medium text-card-foreground mb-2">
              Sortierung
            </label>
            <Select
              options={sortOptions}
              value="relevance"
              onChange={() => {}}
              placeholder="Sortieren nach"
            />
          </div>

          {/* Apply Filters Button (Mobile) */}
          <div className="lg:hidden">
            <Button
              variant="default"
              fullWidth
              onClick={onToggle}
              iconName="Check"
              iconPosition="left"
            >
              Filter anwenden
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default FilterPanel;