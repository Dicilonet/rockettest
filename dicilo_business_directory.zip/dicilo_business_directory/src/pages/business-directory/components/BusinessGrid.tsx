import React from 'react';
import Icon from '../../../components/AppIcon';
import BusinessCard from './BusinessCard';
import { Business } from '../types';

interface BusinessGridProps {
  businesses: Business[];
  selectedBusinessId?: string;
  onBusinessSelect: (businessId: string) => void;
  onFavoriteToggle: (businessId: string) => void;
  isLoading?: boolean;
}

const BusinessGrid = ({ 
  businesses, 
  selectedBusinessId, 
  onBusinessSelect, 
  onFavoriteToggle,
  isLoading = false 
}: BusinessGridProps) => {
  const handleDetailsClick = (businessId: string) => {
    onBusinessSelect(businessId);
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        {/* Loading Header */}
        <div className="flex items-center justify-between">
          <div className="h-6 bg-muted rounded w-48 animate-pulse" />
          <div className="h-6 bg-muted rounded w-24 animate-pulse" />
        </div>

        {/* Loading Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {Array.from({ length: 6 }, (_, index) => (
            <div key={index} className="bg-card border border-border rounded-lg shadow-sm overflow-hidden animate-pulse">
              <div className="h-48 bg-muted" />
              <div className="p-4 space-y-3">
                <div className="h-6 bg-muted rounded w-3/4" />
                <div className="h-4 bg-muted rounded w-full" />
                <div className="h-4 bg-muted rounded w-2/3" />
                <div className="flex space-x-2">
                  <div className="h-4 w-4 bg-muted rounded" />
                  <div className="h-4 bg-muted rounded w-20" />
                </div>
                <div className="h-8 bg-muted rounded w-full" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (businesses.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="max-w-md mx-auto">
          <Icon name="Search" size={48} className="text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-card-foreground mb-2">
            Keine Unternehmen gefunden
          </h3>
          <p className="text-muted-foreground mb-6">
            Versuchen Sie es mit anderen Suchbegriffen oder erweitern Sie Ihre Filter.
          </p>
          <div className="space-y-2 text-sm text-muted-foreground">
            <p>• Überprüfen Sie die Rechtschreibung</p>
            <p>• Verwenden Sie allgemeinere Begriffe</p>
            <p>• Erweitern Sie den Suchradius</p>
            <p>• Entfernen Sie einige Filter</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Results Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <h2 className="text-lg font-semibold text-card-foreground">
            {businesses.length} Unternehmen gefunden
          </h2>
          <div className="hidden sm:flex items-center space-x-1 text-sm text-muted-foreground">
            <Icon name="MapPin" size={14} />
            <span>In Ihrer Nähe</span>
          </div>
        </div>

        {/* View Options */}
        <div className="flex items-center space-x-2">
          <button className="p-2 rounded-md bg-primary text-primary-foreground">
            <Icon name="Grid3X3" size={16} />
          </button>
          <button className="p-2 rounded-md hover:bg-muted transition-colors duration-200">
            <Icon name="List" size={16} />
          </button>
        </div>
      </div>

      {/* Business Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {businesses.map((business) => (
          <BusinessCard
            key={business.id}
            business={business}
            onDetailsClick={handleDetailsClick}
            onFavoriteToggle={onFavoriteToggle}
            isHighlighted={selectedBusinessId === business.id}
          />
        ))}
      </div>

      {/* Load More Button */}
      {businesses.length >= 9 && (
        <div className="text-center pt-6">
          <button className="inline-flex items-center space-x-2 px-6 py-3 bg-muted hover:bg-muted/80 text-muted-foreground hover:text-foreground rounded-md transition-colors duration-200">
            <Icon name="Plus" size={16} />
            <span>Weitere Unternehmen laden</span>
          </button>
        </div>
      )}

      {/* Results Info */}
      <div className="text-center text-sm text-muted-foreground pt-4 border-t border-border">
        <p>
          Zeige {businesses.length} von {businesses.length} Unternehmen
        </p>
      </div>
    </div>
  );
};

export default BusinessGrid;