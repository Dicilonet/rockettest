import React from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import { BusinessCardProps } from '../types';

const BusinessCard = ({
  business,
  onDetailsClick,
  onFavoriteToggle,
  isHighlighted = false
}: BusinessCardProps) => {
  const navigate = useNavigate();

  const handleDetailsClick = () => {
    navigate('/business-details', {
      state: {
        businessId: business.id,
        businessName: business.name
      }
    });
  };

  const handleFavoriteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onFavoriteToggle(business.id);
  };

  const getPriceRangeDisplay = (priceRange: string) => {
    switch (priceRange) {
      case 'low':return '€';
      case 'medium':return '€€';
      case 'high':return '€€€';
      default:return '€';
    }
  };

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <Icon key={i} name="Star" size={14} className="text-yellow-400 fill-current" />
      );
    }

    if (hasHalfStar) {
      stars.push(
        <Icon key="half" name="Star" size={14} className="text-yellow-400 fill-current opacity-50" />
      );
    }

    const remainingStars = 5 - Math.ceil(rating);
    for (let i = 0; i < remainingStars; i++) {
      stars.push(
        <Icon key={`empty-${i}`} name="Star" size={14} className="text-gray-300" />
      );
    }

    return stars;
  };

  return (
    <div
      className={`bg-card border border-border rounded-lg shadow-sm hover:shadow-md transition-all duration-200 overflow-hidden group cursor-pointer ${
      isHighlighted ? 'ring-2 ring-primary shadow-lg' : ''}`
      }
      onClick={handleDetailsClick}>

      {/* Image */}
      <div className="relative h-48 overflow-hidden">
        <Image
          src={business.image}
          alt={business.alt}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200" />

        
        {/* Favorite Button */}
        <button
          onClick={handleFavoriteClick}
          className="absolute top-3 right-3 w-8 h-8 bg-white/90 hover:bg-white rounded-full flex items-center justify-center shadow-sm transition-colors duration-200">

          <Icon
            name="Heart"
            size={16}
            className={business.isFavorite ? 'text-red-500 fill-current' : 'text-gray-600'} />

        </button>

        {/* Status Badge */}
        <div className="absolute top-3 left-3">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
          business.isOpen ?
          'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`
          }>
            {business.isOpen ? 'Geöffnet' : 'Geschlossen'}
          </span>
        </div>

        {/* Price Range */}
        <div className="absolute bottom-3 left-3">
          <span className="bg-black/70 text-white px-2 py-1 rounded text-sm font-medium">
            {getPriceRangeDisplay(business.priceRange)}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {/* Header */}
        <div className="mb-2">
          <h3 className="text-lg font-semibold text-card-foreground mb-1 line-clamp-1">
            {business.name}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
            {business.description}
          </p>
        </div>

        {/* Rating */}
        <div className="flex items-center space-x-2 mb-3">
          <div className="flex items-center space-x-1">
            {renderStars(business.rating)}
          </div>
          <span className="text-sm font-medium text-card-foreground">
            {business.rating.toFixed(1)}
          </span>
          <span className="text-sm text-muted-foreground">
            ({business.reviewCount} Bewertungen)
          </span>
        </div>

        {/* Location */}
        <div className="flex items-center space-x-2 mb-3">
          <Icon name="MapPin" size={14} className="text-muted-foreground" />
          <span className="text-sm text-muted-foreground line-clamp-1 Holtenstra\xDFe">
            {business.address}, {business.city}
          </span>
        </div>

        {/* Category */}
        <div className="flex items-center space-x-2 mb-4">
          <Icon name="Tag" size={14} className="text-muted-foreground" />
          <span className="text-sm text-primary font-medium">
            {business.category}
          </span>
        </div>

        {/* Tags */}
        {business.tags.length > 0 &&
        <div className="flex flex-wrap gap-1 mb-4">
            {business.tags.slice(0, 3).map((tag, index) =>
          <span
            key={index}
            className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded-full">

                {tag}
              </span>
          )}
            {business.tags.length > 3 &&
          <span className="px-2 py-1 bg-muted text-muted-foreground text-xs rounded-full">
                +{business.tags.length - 3}
              </span>
          }
          </div>
        }

        {/* Actions */}
        <div className="flex items-center justify-between">
          <Button
            variant="default"
            size="sm"
            onClick={handleDetailsClick}
            iconName="ArrowRight"
            iconPosition="right"
            className="flex-1 mr-2">

            Details anzeigen
          </Button>
          
          <div className="flex items-center space-x-2">
            {business.phone &&
            <button
              onClick={(e) => {
                e.stopPropagation();
                window.open(`tel:${business.phone}`, '_self');
              }}
              className="w-8 h-8 bg-muted hover:bg-muted/80 rounded-md flex items-center justify-center transition-colors duration-200"
              title="Anrufen">

                <Icon name="Phone" size={16} className="text-muted-foreground" />
              </button>
            }
            
            {business.website &&
            <button
              onClick={(e) => {
                e.stopPropagation();
                window.open(business.website, '_blank');
              }}
              className="w-8 h-8 bg-muted hover:bg-muted/80 rounded-md flex items-center justify-center transition-colors duration-200"
              title="Website besuchen">

                <Icon name="ExternalLink" size={16} className="text-muted-foreground" />
              </button>
            }
          </div>
        </div>
      </div>
    </div>);

};

export default BusinessCard;