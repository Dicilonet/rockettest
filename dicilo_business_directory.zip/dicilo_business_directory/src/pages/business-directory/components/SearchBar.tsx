import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import { SearchBarProps } from '../types';

const SearchBar = ({ 
  filters, 
  onFiltersChange, 
  categories, 
  locations 
}: SearchBarProps) => {
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [businessSuggestions] = useState([
    'Restaurant Zur Alten Post',
    'Bäckerei Schmidt',
    'Friseur Haargenau',
    'Apotheke am Markt',
    'Café Central',
    'Buchhandlung Lesezeit'
  ]);
  
  const searchRef = useRef<HTMLDivElement>(null);

  const categoryOptions = categories.map(cat => ({
    value: cat.value,
    label: `${cat.label} (${cat.count})`
  }));

  const locationOptions = locations.map(loc => ({
    value: loc.value,
    label: loc.label
  }));

  const ratingOptions = [
    { value: '0', label: 'Alle Bewertungen' },
    { value: '4', label: '4+ Sterne' },
    { value: '3', label: '3+ Sterne' },
    { value: '2', label: '2+ Sterne' }
  ];

  const priceRangeOptions = [
    { value: '', label: 'Alle Preisklassen' },
    { value: 'low', label: '€ - Günstig' },
    { value: 'medium', label: '€€ - Mittel' },
    { value: 'high', label: '€€€ - Gehoben' }
  ];

  const handleQueryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    onFiltersChange({ ...filters, query: value });
    setShowSuggestions(value.length > 0);
  };

  const handleSuggestionClick = (suggestion: string) => {
    onFiltersChange({ ...filters, query: suggestion });
    setShowSuggestions(false);
  };

  const handleLocationChange = (value: string) => {
    onFiltersChange({ ...filters, location: value });
  };

  const handleCategoryChange = (value: string) => {
    onFiltersChange({ ...filters, category: value });
  };

  const handleRatingChange = (value: string) => {
    onFiltersChange({ ...filters, rating: parseInt(value) });
  };

  const handlePriceRangeChange = (value: string) => {
    onFiltersChange({ ...filters, priceRange: value });
  };

  const handleOpenNowToggle = () => {
    onFiltersChange({ ...filters, isOpen: !filters.isOpen });
  };

  const handleClearFilters = () => {
    onFiltersChange({
      query: '',
      location: '',
      category: '',
      rating: 0,
      priceRange: '',
      distance: 10,
      isOpen: false
    });
    setShowSuggestions(false);
  };

  const hasActiveFilters = filters.query || filters.location || filters.category || 
                          filters.rating > 0 || filters.priceRange || filters.isOpen;

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredSuggestions = businessSuggestions.filter(suggestion =>
    suggestion.toLowerCase().includes(filters.query.toLowerCase())
  );

  return (
    <div className="bg-card border border-border rounded-lg shadow-sm p-4 mb-6">
      {/* Main Search Row */}
      <div className="flex flex-col lg:flex-row gap-4 mb-4">
        {/* Business Search */}
        <div className="flex-1 relative" ref={searchRef}>
          <div className="relative">
            <Input
              type="search"
              placeholder="Unternehmen, Dienstleistung oder Stichwort suchen..."
              value={filters.query}
              onChange={handleQueryChange}
              className="pl-10"
            />
            <Icon 
              name="Search" 
              size={18} 
              className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" 
            />
          </div>

          {/* Search Suggestions */}
          {showSuggestions && filteredSuggestions.length > 0 && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-popover border border-border rounded-md shadow-lg z-1010 animate-fade-in">
              <div className="p-2">
                {filteredSuggestions.slice(0, 5).map((suggestion, index) => (
                  <button
                    key={index}
                    onClick={() => handleSuggestionClick(suggestion)}
                    className="flex items-center space-x-2 w-full px-3 py-2 text-sm text-popover-foreground hover:bg-muted rounded-sm transition-colors duration-200"
                  >
                    <Icon name="Search" size={14} className="text-muted-foreground" />
                    <span>{suggestion}</span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Location Search */}
        <div className="lg:w-64">
          <Select
            placeholder="Standort wählen..."
            options={locationOptions}
            value={filters.location}
            onChange={handleLocationChange}
            searchable
          />
        </div>

        {/* Search Button */}
        <Button
          variant="default"
          iconName="Search"
          iconPosition="left"
          className="lg:w-auto"
        >
          Suchen
        </Button>
      </div>

      {/* Filter Row */}
      <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center">
        {/* Category Filter */}
        <div className="lg:w-48">
          <Select
            placeholder="Kategorie"
            options={[{ value: '', label: 'Alle Kategorien' }, ...categoryOptions]}
            value={filters.category}
            onChange={handleCategoryChange}
          />
        </div>

        {/* Rating Filter */}
        <div className="lg:w-40">
          <Select
            placeholder="Bewertung"
            options={ratingOptions}
            value={filters.rating.toString()}
            onChange={handleRatingChange}
          />
        </div>

        {/* Price Range Filter */}
        <div className="lg:w-44">
          <Select
            placeholder="Preisklasse"
            options={priceRangeOptions}
            value={filters.priceRange}
            onChange={handlePriceRangeChange}
          />
        </div>

        {/* Open Now Toggle */}
        <div className="flex items-center space-x-2">
          <button
            onClick={handleOpenNowToggle}
            className={`flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium transition-colors duration-200 ${
              filters.isOpen
                ? 'bg-primary text-primary-foreground'
                : 'bg-muted text-muted-foreground hover:bg-muted/80'
            }`}
          >
            <Icon name="Clock" size={16} />
            <span>Jetzt geöffnet</span>
          </button>
        </div>

        {/* Clear Filters */}
        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={handleClearFilters}
            iconName="X"
            iconPosition="left"
            className="text-muted-foreground hover:text-foreground"
          >
            Filter löschen
          </Button>
        )}
      </div>

      {/* Active Filters Display */}
      {hasActiveFilters && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="flex flex-wrap gap-2">
            {filters.query && (
              <span className="inline-flex items-center space-x-1 px-2 py-1 bg-primary/10 text-primary text-sm rounded-full">
                <span>"{filters.query}"</span>
                <button
                  onClick={() => onFiltersChange({ ...filters, query: '' })}
                  className="hover:bg-primary/20 rounded-full p-0.5"
                >
                  <Icon name="X" size={12} />
                </button>
              </span>
            )}
            
            {filters.location && (
              <span className="inline-flex items-center space-x-1 px-2 py-1 bg-primary/10 text-primary text-sm rounded-full">
                <Icon name="MapPin" size={12} />
                <span>{filters.location}</span>
                <button
                  onClick={() => onFiltersChange({ ...filters, location: '' })}
                  className="hover:bg-primary/20 rounded-full p-0.5"
                >
                  <Icon name="X" size={12} />
                </button>
              </span>
            )}

            {filters.category && (
              <span className="inline-flex items-center space-x-1 px-2 py-1 bg-primary/10 text-primary text-sm rounded-full">
                <Icon name="Tag" size={12} />
                <span>{categories.find(c => c.value === filters.category)?.label}</span>
                <button
                  onClick={() => onFiltersChange({ ...filters, category: '' })}
                  className="hover:bg-primary/20 rounded-full p-0.5"
                >
                  <Icon name="X" size={12} />
                </button>
              </span>
            )}

            {filters.rating > 0 && (
              <span className="inline-flex items-center space-x-1 px-2 py-1 bg-primary/10 text-primary text-sm rounded-full">
                <Icon name="Star" size={12} />
                <span>{filters.rating}+ Sterne</span>
                <button
                  onClick={() => onFiltersChange({ ...filters, rating: 0 })}
                  className="hover:bg-primary/20 rounded-full p-0.5"
                >
                  <Icon name="X" size={12} />
                </button>
              </span>
            )}

            {filters.isOpen && (
              <span className="inline-flex items-center space-x-1 px-2 py-1 bg-primary/10 text-primary text-sm rounded-full">
                <Icon name="Clock" size={12} />
                <span>Jetzt geöffnet</span>
                <button
                  onClick={() => onFiltersChange({ ...filters, isOpen: false })}
                  className="hover:bg-primary/20 rounded-full p-0.5"
                >
                  <Icon name="X" size={12} />
                </button>
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchBar;