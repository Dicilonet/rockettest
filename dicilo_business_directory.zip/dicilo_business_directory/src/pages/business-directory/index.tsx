import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import AuthenticationModal from '../../components/ui/AuthenticationModal';
import MapView from './components/MapView';
import BusinessCard from './components/BusinessCard';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import { Business, SearchFilters, CategoryOption, LocationOption } from './types';

const BusinessDirectory = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  // UI state
  const [selectedBusinessId, setSelectedBusinessId] = useState<string>();
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<'business' | 'location'>('business');

  // Search and filter state
  const [filters, setFilters] = useState<SearchFilters>({
    query: '',
    location: 'Berlin',
    category: '',
    rating: 0,
    priceRange: '',
    distance: 10,
    isOpen: false
  });

  // Map state
  const [mapCenter, setMapCenter] = useState({
    lat: 52.5200,
    lng: 13.4050
  });
  const [mapZoom] = useState(12);

  // Mock data - Business listings with expanded categories
  const mockBusinesses: Business[] = [
  {
    id: '1',
    name: 'Bodega Española',
    description: 'Authentische spanische Küche mit traditionellen Tapas und Paella. Gemütliche Atmosphäre mit spanischem Flair im Herzen der Stadt.',
    category: 'Gastronomie',
    rating: 4.5,
    reviewCount: 127,
    address: 'Torstraße 15',
    city: 'Bremen, Alemania',
    phone: '+49 421 12345678',
    website: 'https://bodega-espanola.de',
    email: 'info@bodega-espanola.de',
    image: "https://images.unsplash.com/photo-1696420691045-330c5669e96c",
    alt: 'Spanish restaurant interior with rustic wooden tables and traditional decorations',
    coordinates: { lat: 53.0793, lng: 8.8017 },
    openingHours: {
      'Mo-Fr': '17:00-23:00',
      'Sa-So': '12:00-23:00'
    },
    priceRange: 'medium',
    isOpen: true,
    isFavorite: false,
    tags: ['Spanisch', 'Tapas', 'Gemütlich']
  },
  {
    id: '2',
    name: 'Brückenstern - Hamburg',
    description: 'Moderne Norddeutsche Küche mit regionalem Fokus. Frische Meeresfrüchte und saisonale Spezialitäten in stilvollem Ambiente.',
    category: 'Gastronomie',
    rating: 4.8,
    reviewCount: 89,
    address: 'Speicherstadt 42',
    city: 'Hamburg, Deutschland',
    phone: '+49 40 87654321',
    image: "https://images.unsplash.com/photo-1600378624260-b851e71d5a7c",
    alt: 'Modern Hamburg restaurant with elegant dining room overlooking the harbor',
    coordinates: { lat: 53.5511, lng: 9.9937 },
    openingHours: {
      'Di-Sa': '18:00-22:00',
      'So': '12:00-20:00'
    },
    priceRange: 'high',
    isOpen: true,
    isFavorite: true,
    tags: ['Norddeutsch', 'Meeresfrüchte', 'Elegant']
  },
  {
    id: '3',
    name: 'Café Münchner Kindl',
    description: 'Traditionelles bayerisches Café mit hausgebackenen Kuchen und erstklassigem Kaffee. Perfekt für eine gemütliche Kaffeepause.',
    category: 'Gastronomie',
    rating: 4.2,
    reviewCount: 156,
    address: 'Marienplatz 8',
    city: 'München, Deutschland',
    phone: '+49 89 11223344',
    website: 'https://muenchner-kindl.de',
    image: "https://images.unsplash.com/photo-1726839114817-d1c96cbccfdf",
    alt: 'Cozy Bavarian cafe with traditional wooden furniture and display of fresh pastries',
    coordinates: { lat: 48.1351, lng: 11.5820 },
    openingHours: {
      'Mo-So': '07:00-19:00'
    },
    priceRange: 'low',
    isOpen: true,
    isFavorite: false,
    tags: ['Bayerisch', 'Kaffee', 'Hausgemacht']
  },
  {
    id: '4',
    name: 'Berliner Bäckerstube',
    description: 'Traditionelle Handwerksbäckerei mit frischen Backwaren täglich. Berliner Spezialitäten und klassische deutsche Brotsorten.',
    category: 'Lebensmittel',
    rating: 4.6,
    reviewCount: 203,
    address: 'Unter den Linden 25',
    city: 'Berlin, Deutschland',
    phone: '+49 30 55667788',
    image: "https://images.unsplash.com/photo-1672811155735-a8820653e94e",
    alt: 'Traditional German bakery with fresh bread and pretzels displayed in wooden baskets',
    coordinates: { lat: 52.5200, lng: 13.4050 },
    openingHours: {
      'Mo-Fr': '06:00-18:00',
      'Sa': '06:00-16:00'
    },
    priceRange: 'low',
    isOpen: true,
    isFavorite: false,
    tags: ['Handwerk', 'Frisch', 'Berliner Spezialitäten']
  },
  {
    id: '5',
    name: 'Kölner Brauhaus',
    description: 'Authentisches Kölner Brauhaus mit frischem Kölsch und rheinischer Küche. Lebendige Atmosphäre und kölsche Gastfreundschaft.',
    category: 'Gastronomie',
    rating: 4.4,
    reviewCount: 92,
    address: 'Heumarkt 12',
    city: 'Köln, Deutschland',
    phone: '+49 221 99887766',
    website: 'https://koelner-brauhaus.de',
    image: "https://images.unsplash.com/photo-1558710044-af6a3fdcdbad",
    alt: 'Traditional Cologne brewery with wooden tables and beer taps along the bar',
    coordinates: { lat: 50.9375, lng: 6.9603 },
    openingHours: {
      'Mo-So': '11:00-24:00'
    },
    priceRange: 'medium',
    isOpen: true,
    isFavorite: true,
    tags: ['Kölsch', 'Rheinisch', 'Brauhaus']
  },
  {
    id: '6',
    name: 'Frankfurter Apfelweinstube',
    description: 'Gemütliche Apfelweinstube mit hessischen Spezialitäten. Traditioneller Apfelwein und deftige Gerichte in urigem Ambiente.',
    category: 'Gastronomie',
    rating: 4.7,
    reviewCount: 78,
    address: 'Sachsenhausen 34',
    city: 'Frankfurt, Deutschland',
    phone: '+49 69 44556677',
    email: 'info@apfelweinstube-ffm.de',
    image: "https://images.unsplash.com/photo-1708530716700-d615f8db1fde",
    alt: 'Frankfurt apple wine tavern with rustic wooden interior and traditional German atmosphere',
    coordinates: { lat: 50.1109, lng: 8.6821 },
    openingHours: {
      'Di-So': '16:00-23:00'
    },
    priceRange: 'medium',
    isOpen: false,
    isFavorite: false,
    tags: ['Apfelwein', 'Hessisch', 'Traditionell']
  },
  {
    id: '7',
    name: 'TechConsult Berlin',
    description: 'Professionelle IT-Beratung und Digitalisierungslösungen für Unternehmen. Expertise in Cloud-Migration und Cybersecurity.',
    category: 'Beratung',
    rating: 4.9,
    reviewCount: 45,
    address: 'Potsdamer Platz 10',
    city: 'Berlin, Deutschland',
    phone: '+49 30 98765432',
    website: 'https://techconsult-berlin.de',
    email: 'info@techconsult-berlin.de',
    image: "https://images.unsplash.com/photo-1629905679177-4c4e2623654f",
    alt: 'Modern IT consulting office with professionals working at computers and whiteboards',
    coordinates: { lat: 52.5096, lng: 13.3765 },
    openingHours: {
      'Mo-Fr': '09:00-18:00'
    },
    priceRange: 'high',
    isOpen: true,
    isFavorite: false,
    tags: ['IT', 'Digital', 'Cloud']
  },
  {
    id: '8',
    name: 'Musikschule Harmony',
    description: 'Musikunterricht für alle Altersgruppen. Klavier, Gitarre, Geige und Gesangsunterricht von qualifizierten Musikpädagogen.',
    category: 'Bildung',
    rating: 4.6,
    reviewCount: 112,
    address: 'Bachstraße 22',
    city: 'München, Deutschland',
    phone: '+49 89 33445566',
    website: 'https://musikschule-harmony.de',
    image: "https://images.unsplash.com/photo-1597097205971-fee8c6f8d9b0",
    alt: 'Music school classroom with piano, guitars and students learning instruments',
    coordinates: { lat: 48.1372, lng: 11.5755 },
    openingHours: {
      'Mo-Sa': '14:00-20:00'
    },
    priceRange: 'medium',
    isOpen: true,
    isFavorite: true,
    tags: ['Musik', 'Unterricht', 'Kinder']
  }];


  const categories: CategoryOption[] = [
  { value: 'beratung', label: 'Beratung', count: 12 },
  { value: 'bildung', label: 'Bildung', count: 8 },
  { value: 'finanzdienste', label: 'Finanzdienste', count: 15 },
  { value: 'gastronomie', label: 'Gastronomie', count: 45 },
  { value: 'gesundheit', label: 'Gesundheit', count: 23 },
  { value: 'hotellerie', label: 'Hotellerie', count: 18 },
  { value: 'immobilien', label: 'Immobilien', count: 34 },
  { value: 'kleidung', label: 'Kleidung', count: 27 },
  { value: 'lebensmittel', label: 'Lebensmittel', count: 32 },
  { value: 'musik', label: 'Musik', count: 14 },
  { value: 'soziales', label: 'Soziales', count: 9 },
  { value: 'sport', label: 'Sport', count: 21 },
  { value: 'travel', label: 'Travel', count: 16 },
  { value: 'technologie', label: 'Technologie', count: 29 },
  { value: 'tier', label: 'Tier', count: 11 },
  { value: 'transport', label: 'Transport', count: 19 },
  { value: 'umwelt', label: 'Umwelt', count: 7 },
  { value: 'unterhaltung', label: 'Unterhaltung', count: 25 }];


  const locations: LocationOption[] = [
  { value: 'berlin', label: 'Berlin', coordinates: { lat: 52.5200, lng: 13.4050 } },
  { value: 'hamburg', label: 'Hamburg', coordinates: { lat: 53.5511, lng: 9.9937 } },
  { value: 'muenchen', label: 'München', coordinates: { lat: 48.1351, lng: 11.5820 } },
  { value: 'koeln', label: 'Köln', coordinates: { lat: 50.9375, lng: 6.9603 } },
  { value: 'frankfurt', label: 'Frankfurt', coordinates: { lat: 50.1109, lng: 8.6821 } }];


  // Filter businesses based on current filters
  const filteredBusinesses = mockBusinesses.filter((business) => {
    if (filters.query && !business.name.toLowerCase().includes(filters.query.toLowerCase()) &&
    !business.description.toLowerCase().includes(filters.query.toLowerCase())) {
      return false;
    }

    if (filters.category && business.category.toLowerCase() !== filters.category.toLowerCase()) {
      return false;
    }

    if (filters.rating > 0 && business.rating < filters.rating) {
      return false;
    }

    if (filters.isOpen && !business.isOpen) {
      return false;
    }

    return true;
  });

  // Handle authentication
  const handleLogin = () => {
    setAuthMode('login');
    setAuthModalOpen(true);
  };

  const handleRegister = () => {
    setAuthMode('register');
    setAuthModalOpen(true);
  };

  const handleAuthenticate = (userData: any) => {
    setIsAuthenticated(true);
    setUser(userData);
    setAuthModalOpen(false);
  };

  // Handle business interactions
  const handleBusinessSelect = (businessId: string) => {
    setSelectedBusinessId(businessId);
  };

  const handleMapPinClick = (businessId: string) => {
    setSelectedBusinessId(businessId);
  };

  const handleFavoriteToggle = (businessId: string) => {
    if (!isAuthenticated) {
      handleLogin();
      return;
    }

    console.log(`Toggle favorite for business ${businessId}`);
  };

  const handleBusinessDetails = (businessId: string) => {
    const business = filteredBusinesses.find((b) => b.id === businessId);
    if (business) {
      navigate('/business-details', {
        state: {
          businessId: business.id,
          businessName: business.name
        }
      });
    }
  };

  // Handle search input change
  const handleSearchChange = (value: string) => {
    setFilters((prev) => ({
      ...prev,
      query: value
    }));
  };

  // Handle voice search
  const handleVoiceSearch = () => {
    console.log('Voice search activated');
    // Implement voice search functionality
  };

  // Handle geolocation
  const handleGeolocation = () => {
    console.log('Geolocation search activated');
    // Implement geolocation functionality
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setMapCenter({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    }
  };

  return (
    <div className="min-h-screen bg-white flex">
      {/* Left Column - Map (45% width) */}
      <div className="w-[45%] h-screen flex-shrink-0">
        <MapView
          businesses={filteredBusinesses}
          selectedBusinessId={selectedBusinessId}
          onPinClick={handleMapPinClick}
          center={mapCenter}
          zoom={mapZoom} />

      </div>

      {/* Right Column - Content Panel (55% width) */}
      <div className="w-[55%] h-screen flex flex-col bg-white">
        {/* Fixed Header */}
        <header className="flex-shrink-0 bg-white border-b border-gray-200 px-6 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-900">Dicilo.net</h1>
            </div>

            {/* Navigation Links */}
            <nav className="hidden md:flex items-center space-x-8">
              <a href="#" className="text-gray-600 hover:text-gray-900 font-medium">Vorteile</a>
              <a href="#" className="text-gray-600 hover:text-gray-900 font-medium">Pläne</a>
              <a href="#" className="text-gray-600 hover:text-gray-900 font-medium">Über uns</a>
              <button
                onClick={handleLogin}
                className="text-gray-600 hover:text-gray-900 font-medium">

                Anmelden
              </button>
            </nav>

            {/* CTA Button */}
            <Button
              onClick={handleRegister}
              className="bg-green-600 hover:bg-green-700 text-white font-semibold px-6 py-2 rounded-lg">

              Registrieren
            </Button>
          </div>
        </header>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto">
          <div className="px-6 py-6">
            {/* Main Heading - Sentence case and two lines */}
            <div className="mb-6">
              <h2 className="text-3xl font-bold text-gray-900 mb-2 leading-tight">
                Entdecken Sie empfohlene<br />
                Unternehmen
              </h2>
              <p className="text-gray-600">
                Finden Sie die besten Produkte und Dienstleistungen in Ihrer Nähe...
              </p>
            </div>

            {/* Advanced Search Component */}
            <div className="mb-6">
              {/* Tabs */}
              <div className="flex mb-4">
                <button
                  onClick={() => setActiveTab('business')}
                  className={`flex items-center px-6 py-3 text-sm font-semibold rounded-t-lg border-b-2 transition-colors ${
                  activeTab === 'business' ? 'bg-green-100 text-green-800 border-green-500' : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'}`
                  }>

                  <Icon name="Building2" size={16} className="mr-2" />
                  Unternehmen
                </button>
                <button
                  onClick={() => setActiveTab('location')}
                  className={`flex items-center px-6 py-3 text-sm font-semibold rounded-t-lg border-b-2 transition-colors ${
                  activeTab === 'location' ? 'bg-green-100 text-green-800 border-green-500' : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'}`
                  }>

                  <Icon name="MapPin" size={16} className="mr-2" />
                  Standort
                </button>
              </div>

              {/* Search Input Bar with Action Buttons */}
              <div className="relative flex items-center">
                <div className="relative flex-1">
                  <Input
                    type="text"
                    placeholder="Name des Unternehmens oder Schlü..."
                    value={filters.query}
                    onChange={(e) => handleSearchChange(e.target.value)}
                    className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-l-lg focus:ring-2 focus:ring-green-500 focus:border-green-500" />

                  <Icon
                    name="Search"
                    size={20}
                    className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />

                </div>

                {/* Action Buttons */}
                <div className="flex">
                  {/* Voice Search Button */}
                  <button
                    onClick={handleVoiceSearch}
                    className="px-4 py-3 bg-gray-100 border-t border-b border-gray-300 hover:bg-gray-200 transition-colors"
                    title="Sprachsuche">

                    <Icon name="Mic" size={20} className="text-gray-600" />
                  </button>

                  {/* Geolocation/Submit Button */}
                  <button
                    onClick={handleGeolocation}
                    className="px-4 py-3 bg-green-600 hover:bg-green-700 text-white rounded-r-lg transition-colors"
                    title="Standort verwenden">

                    <Icon name="Send" size={20} />
                  </button>
                </div>
              </div>
            </div>

            {/* Business Listing - Two-Column Grid */}
            <div className="grid grid-cols-2 gap-4">
              {isLoading ?
              <div className="col-span-2 flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
                </div> :
              filteredBusinesses.length === 0 ?
              <div className="col-span-2 text-center py-12">
                  <Icon name="Search" size={48} className="mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Keine Unternehmen gefunden
                  </h3>
                  <p className="text-gray-600">
                    Versuchen Sie es mit anderen Suchbegriffen.
                  </p>
                </div> :

              filteredBusinesses.map((business) =>
              <div key={business.id} id={`business-${business.id}`}>
                    <BusinessCard
                  business={business}
                  onDetailsClick={handleBusinessDetails}
                  onFavoriteToggle={handleFavoriteToggle}
                  isHighlighted={selectedBusinessId === business.id} />

                  </div>
              )
              }
            </div>

            {/* Results Count */}
            <div className="mt-6 text-center">
              <p className="text-sm text-gray-600">
                {filteredBusinesses.length} Unternehmen gefunden
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Authentication Modal */}
      <AuthenticationModal
        isOpen={authModalOpen}
        mode={authMode}
        onClose={() => setAuthModalOpen(false)}
        onModeChange={setAuthMode}
        onAuthenticate={handleAuthenticate} />

    </div>);

};

export default BusinessDirectory;