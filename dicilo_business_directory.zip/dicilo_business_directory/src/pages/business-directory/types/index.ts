export interface Business {
  id: string;
  name: string;
  description: string;
  category: string;
  rating: number;
  reviewCount: number;
  address: string;
  city: string;
  phone: string;
  website?: string;
  email?: string;
  image: string;
  alt: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  openingHours: {
    [key: string]: string;
  };
  priceRange: 'low' | 'medium' | 'high';
  isOpen: boolean;
  isFavorite: boolean;
  tags: string[];
}

export interface SearchFilters {
  query: string;
  location: string;
  category: string;
  rating: number;
  priceRange: string;
  distance: number;
  isOpen: boolean;
}

export interface MapPin {
  id: string;
  coordinates: {
    lat: number;
    lng: number;
  };
  business: Business;
}

export interface CategoryOption {
  value: string;
  label: string;
  count: number;
}

export interface LocationOption {
  value: string;
  label: string;
  coordinates: {
    lat: number;
    lng: number;
  };
}

export interface BusinessCardProps {
  business: Business;
  onDetailsClick: (businessId: string) => void;
  onFavoriteToggle: (businessId: string) => void;
  isHighlighted?: boolean;
}

export interface MapViewProps {
  businesses: Business[];
  selectedBusinessId?: string;
  onPinClick: (businessId: string) => void;
  center: {
    lat: number;
    lng: number;
  };
  zoom: number;
}

export interface SearchBarProps {
  filters: SearchFilters;
  onFiltersChange: (filters: SearchFilters) => void;
  categories: CategoryOption[];
  locations: LocationOption[];
}

export interface FilterPanelProps {
  filters: SearchFilters;
  onFiltersChange: (filters: SearchFilters) => void;
  categories: CategoryOption[];
  isOpen: boolean;
  onToggle: () => void;
}