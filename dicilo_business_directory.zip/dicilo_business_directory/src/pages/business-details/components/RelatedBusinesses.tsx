import React from 'react';
import { useNavigate } from 'react-router-dom';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { RelatedBusiness } from '../types';

interface RelatedBusinessesProps {
  businesses: RelatedBusiness[];
  currentBusinessId: string;
}

const RelatedBusinesses = ({ businesses, currentBusinessId }: RelatedBusinessesProps) => {
  const navigate = useNavigate();

  const handleBusinessClick = (businessId: string) => {
    // In a real app, this would navigate to the specific business details
    navigate(`/business-details?id=${businessId}`);
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Icon
        key={index}
        name="Star"
        size={12}
        className={index < Math.floor(rating) ? 'text-warning fill-current' : 'text-muted-foreground'}
      />
    ));
  };

  if (businesses.length === 0) {
    return null;
  }

  return (
    <div className="bg-card rounded-lg shadow-sm border border-border p-6">
      <h2 className="text-xl font-semibold text-card-foreground mb-6 flex items-center space-x-2">
        <Icon name="Building" size={20} className="text-primary" />
        <span>Ähnliche Unternehmen</span>
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {businesses.slice(0, 6).map((business) => (
          <div
            key={business.id}
            className="bg-background border border-border rounded-lg overflow-hidden hover:shadow-md transition-shadow duration-200 cursor-pointer group"
            onClick={() => handleBusinessClick(business.id)}
          >
            {/* Business Image */}
            <div className="relative h-32 bg-muted overflow-hidden">
              <Image
                src={business.image}
                alt={business.alt}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
              />
              <div className="absolute top-2 right-2 bg-black/50 text-white px-2 py-1 rounded-md text-xs">
                {business.distance}
              </div>
            </div>

            {/* Business Info */}
            <div className="p-4">
              <h3 className="font-semibold text-card-foreground mb-1 group-hover:text-primary transition-colors duration-200 line-clamp-1">
                {business.name}
              </h3>
              
              <p className="text-sm text-muted-foreground mb-2 line-clamp-1">
                {business.category}
              </p>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-1">
                  <div className="flex items-center space-x-0.5">
                    {renderStars(business.rating)}
                  </div>
                  <span className="text-sm font-medium text-card-foreground">
                    {business.rating.toFixed(1)}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    ({business.reviewCount})
                  </span>
                </div>
                
                <Icon 
                  name="ArrowRight" 
                  size={16} 
                  className="text-muted-foreground group-hover:text-primary transition-colors duration-200" 
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      {businesses.length > 6 && (
        <div className="text-center mt-6">
          <Button
            variant="outline"
            onClick={() => navigate('/search-results')}
            iconName="Search"
            iconPosition="left"
          >
            Mehr ähnliche Unternehmen anzeigen
          </Button>
        </div>
      )}
    </div>
  );
};

export default RelatedBusinesses;