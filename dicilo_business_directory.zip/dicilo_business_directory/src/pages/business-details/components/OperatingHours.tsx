import React from 'react';
import Icon from '../../../components/AppIcon';
import { OperatingHours as OperatingHoursType } from '../types';

interface OperatingHoursProps {
  operatingHours: OperatingHoursType;
}

const OperatingHours = ({ operatingHours }: OperatingHoursProps) => {
  const days = [
    { key: 'monday', label: 'Montag' },
    { key: 'tuesday', label: 'Dienstag' },
    { key: 'wednesday', label: 'Mittwoch' },
    { key: 'thursday', label: 'Donnerstag' },
    { key: 'friday', label: 'Freitag' },
    { key: 'saturday', label: 'Samstag' },
    { key: 'sunday', label: 'Sonntag' }
  ];

  const getCurrentStatus = () => {
    const now = new Date();
    const currentDay = days[now.getDay() === 0 ? 6 : now.getDay() - 1]; // Adjust for Monday start
    const todayHours = operatingHours[currentDay.key as keyof OperatingHoursType];
    
    if (!todayHours.isOpen) {
      return { isOpen: false, message: 'Heute geschlossen' };
    }

    const currentTime = now.getHours() * 60 + now.getMinutes();
    const [openHour, openMinute] = todayHours.openTime!.split(':').map(Number);
    const [closeHour, closeMinute] = todayHours.closeTime!.split(':').map(Number);
    
    const openTime = openHour * 60 + openMinute;
    const closeTime = closeHour * 60 + closeMinute;

    if (currentTime >= openTime && currentTime <= closeTime) {
      return { 
        isOpen: true, 
        message: `Geöffnet bis ${todayHours.closeTime}` 
      };
    } else if (currentTime < openTime) {
      return { 
        isOpen: false, 
        message: `Öffnet um ${todayHours.openTime}` 
      };
    } else {
      return { 
        isOpen: false, 
        message: 'Heute geschlossen' 
      };
    }
  };

  const status = getCurrentStatus();

  return (
    <div className="bg-card rounded-lg shadow-sm border border-border p-6">
      <h2 className="text-xl font-semibold text-card-foreground mb-4 flex items-center space-x-2">
        <Icon name="Clock" size={20} className="text-primary" />
        <span>Öffnungszeiten</span>
      </h2>

      {/* Current Status */}
      <div className={`flex items-center space-x-2 mb-4 p-3 rounded-md ${
        status.isOpen 
          ? 'bg-success/10 text-success border border-success/20' :'bg-error/10 text-error border border-error/20'
      }`}>
        <Icon 
          name={status.isOpen ? "CheckCircle" : "XCircle"} 
          size={16} 
        />
        <span className="font-medium">{status.message}</span>
      </div>

      {/* Hours List */}
      <div className="space-y-2">
        {days.map((day) => {
          const dayHours = operatingHours[day.key as keyof OperatingHoursType];
          const isToday = new Date().getDay() === (day.key === 'sunday' ? 0 : days.indexOf(day) + 1);
          
          return (
            <div
              key={day.key}
              className={`flex items-center justify-between py-2 px-3 rounded-md transition-colors duration-200 ${
                isToday ? 'bg-primary/5 border border-primary/10' : 'hover:bg-muted/50'
              }`}
            >
              <div className="flex items-center space-x-2">
                <span className={`font-medium ${
                  isToday ? 'text-primary' : 'text-card-foreground'
                }`}>
                  {day.label}
                </span>
                {isToday && (
                  <span className="text-xs bg-primary text-primary-foreground px-2 py-0.5 rounded-full">
                    Heute
                  </span>
                )}
              </div>
              
              <div className="text-right">
                {dayHours.isOpen ? (
                  <span className="text-card-foreground">
                    {dayHours.openTime} - {dayHours.closeTime}
                  </span>
                ) : (
                  <span className="text-muted-foreground">Geschlossen</span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Additional Info */}
      <div className="mt-4 pt-4 border-t border-border">
        <p className="text-xs text-muted-foreground">
          * Öffnungszeiten können an Feiertagen abweichen
        </p>
      </div>
    </div>
  );
};

export default OperatingHours;