import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Business, ContactAction } from '../types';

interface ContactSectionProps {
  business: Business;
}

const ContactSection = ({ business }: ContactSectionProps) => {
  const contactActions: ContactAction[] = [
    {
      type: 'phone',
      label: 'Anrufen',
      value: business.phone,
      icon: 'Phone'
    },
    {
      type: 'website',
      label: 'Website',
      value: business.website || '',
      icon: 'Globe'
    },
    {
      type: 'email',
      label: 'E-Mail',
      value: business.email || '',
      icon: 'Mail'
    },
    {
      type: 'directions',
      label: 'Route',
      value: business.address,
      icon: 'Navigation'
    }
  ].filter(action => action.value);

  const handleContactAction = (action: ContactAction) => {
    switch (action.type) {
      case 'phone':
        window.open(`tel:${action.value}`, '_self');
        break;
      case 'website':
        window.open(action.value.startsWith('http') ? action.value : `https://${action.value}`, '_blank');
        break;
      case 'email':
        window.open(`mailto:${action.value}`, '_self');
        break;
      case 'directions':
        const encodedAddress = encodeURIComponent(action.value);
        window.open(`https://www.google.com/maps/search/?api=1&query=${encodedAddress}`, '_blank');
        break;
    }
  };

  const handleShare = async () => {
    const shareData = {
      title: business.name,
      text: `Schauen Sie sich ${business.name} an - ${business.category} in ${business.address}`,
      url: window.location.href
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (error) {
        console.log('Sharing failed:', error);
        fallbackShare();
      }
    } else {
      fallbackShare();
    }
  };

  const fallbackShare = () => {
    navigator.clipboard.writeText(window.location.href).then(() => {
      alert('Link wurde in die Zwischenablage kopiert!');
    });
  };

  return (
    <div className="bg-card rounded-lg shadow-sm border border-border p-6">
      <h2 className="text-xl font-semibold text-card-foreground mb-4 flex items-center space-x-2">
        <Icon name="Phone" size={20} className="text-primary" />
        <span>Kontakt</span>
      </h2>

      {/* Contact Actions Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        {contactActions.map((action) => (
          <Button
            key={action.type}
            variant="outline"
            size="sm"
            onClick={() => handleContactAction(action)}
            className="flex flex-col items-center space-y-1 h-auto py-3 hover:bg-primary/5 hover:border-primary/20"
          >
            <Icon name={action.icon} size={20} className="text-primary" />
            <span className="text-xs font-medium">{action.label}</span>
          </Button>
        ))}
      </div>

      {/* Contact Information */}
      <div className="space-y-3 mb-6">
        <div className="flex items-center space-x-3">
          <Icon name="Phone" size={16} className="text-muted-foreground" />
          <a
            href={`tel:${business.phone}`}
            className="text-primary hover:underline font-medium"
          >
            {business.phone}
          </a>
        </div>

        {business.website && (
          <div className="flex items-center space-x-3">
            <Icon name="Globe" size={16} className="text-muted-foreground" />
            <a
              href={business.website.startsWith('http') ? business.website : `https://${business.website}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline font-medium truncate"
            >
              {business.website.replace(/^https?:\/\//, '')}
            </a>
          </div>
        )}

        {business.email && (
          <div className="flex items-center space-x-3">
            <Icon name="Mail" size={16} className="text-muted-foreground" />
            <a
              href={`mailto:${business.email}`}
              className="text-primary hover:underline font-medium"
            >
              {business.email}
            </a>
          </div>
        )}

        <div className="flex items-start space-x-3">
          <Icon name="MapPin" size={16} className="text-muted-foreground mt-0.5" />
          <span className="text-card-foreground">{business.address}</span>
        </div>
      </div>

      {/* Social Media */}
      {business.socialMedia && (
        <div className="border-t border-border pt-4 mb-6">
          <h3 className="text-sm font-medium text-card-foreground mb-3">Social Media</h3>
          <div className="flex items-center space-x-3">
            {business.socialMedia.facebook && (
              <a
                href={business.socialMedia.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors duration-200"
              >
                <Icon name="Facebook" size={16} />
              </a>
            )}
            {business.socialMedia.instagram && (
              <a
                href={business.socialMedia.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-full flex items-center justify-center hover:from-purple-600 hover:to-pink-600 transition-colors duration-200"
              >
                <Icon name="Instagram" size={16} />
              </a>
            )}
            {business.socialMedia.twitter && (
              <a
                href={business.socialMedia.twitter}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 bg-blue-400 text-white rounded-full flex items-center justify-center hover:bg-blue-500 transition-colors duration-200"
              >
                <Icon name="Twitter" size={16} />
              </a>
            )}
            {business.socialMedia.linkedin && (
              <a
                href={business.socialMedia.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="w-8 h-8 bg-blue-700 text-white rounded-full flex items-center justify-center hover:bg-blue-800 transition-colors duration-200"
              >
                <Icon name="Linkedin" size={16} />
              </a>
            )}
          </div>
        </div>
      )}

      {/* Share Button */}
      <div className="border-t border-border pt-4">
        <Button
          variant="outline"
          fullWidth
          onClick={handleShare}
          iconName="Share2"
          iconPosition="left"
        >
          Teilen
        </Button>
      </div>
    </div>
  );
};

export default ContactSection;