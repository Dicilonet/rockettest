import React, { useState } from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Business } from '../types';

interface BusinessHeroProps {
  business: Business;
  onFavoriteToggle: (businessId: string) => void;
  isFavorite: boolean;
}

const BusinessHero = ({ business, onFavoriteToggle, isFavorite }: BusinessHeroProps) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);

  const primaryImages = business.images.filter(img => img.isPrimary || business.images.length === 1);
  const displayImages = primaryImages.length > 0 ? primaryImages : business.images.slice(0, 3);

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % displayImages.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + displayImages.length) % displayImages.length);
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Icon
        key={index}
        name="Star"
        size={16}
        className={index < Math.floor(rating) ? 'text-warning fill-current' : 'text-muted-foreground'}
      />
    ));
  };

  return (
    <div className="bg-card rounded-lg shadow-sm border border-border overflow-hidden">
      {/* Image Gallery */}
      <div className="relative h-64 md:h-80 bg-muted overflow-hidden">
        {displayImages.length > 0 && (
          <>
            <Image
              src={displayImages[currentImageIndex].url}
              alt={displayImages[currentImageIndex].alt}
              className="w-full h-full object-cover cursor-pointer"
              onClick={() => setIsImageModalOpen(true)}
            />
            
            {displayImages.length > 1 && (
              <>
                <button
                  onClick={prevImage}
                  className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-black/50 hover:bg-black/70 text-white rounded-full flex items-center justify-center transition-colors duration-200"
                >
                  <Icon name="ChevronLeft" size={16} />
                </button>
                <button
                  onClick={nextImage}
                  className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 bg-black/50 hover:bg-black/70 text-white rounded-full flex items-center justify-center transition-colors duration-200"
                >
                  <Icon name="ChevronRight" size={16} />
                </button>
                
                {/* Image Indicators */}
                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex space-x-1">
                  {displayImages.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`w-2 h-2 rounded-full transition-colors duration-200 ${
                        index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                      }`}
                    />
                  ))}
                </div>
              </>
            )}
            
            {/* View All Photos Button */}
            <button
              onClick={() => setIsImageModalOpen(true)}
              className="absolute top-2 right-2 bg-black/50 hover:bg-black/70 text-white px-3 py-1 rounded-md text-sm transition-colors duration-200 flex items-center space-x-1"
            >
              <Icon name="Image" size={14} />
              <span>{business.images.length} Fotos</span>
            </button>
          </>
        )}
      </div>

      {/* Business Information */}
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <h1 className="text-2xl md:text-3xl font-bold text-card-foreground">
                {business.name}
              </h1>
              {business.verified && (
                <div className="flex items-center space-x-1 bg-success/10 text-success px-2 py-1 rounded-full">
                  <Icon name="CheckCircle" size={14} />
                  <span className="text-xs font-medium">Verifiziert</span>
                </div>
              )}
            </div>
            
            <p className="text-muted-foreground mb-2">{business.category}</p>
            
            {/* Rating */}
            <div className="flex items-center space-x-2 mb-3">
              <div className="flex items-center space-x-1">
                {renderStars(business.rating)}
              </div>
              <span className="font-semibold text-card-foreground">
                {business.rating.toFixed(1)}
              </span>
              <span className="text-muted-foreground">
                ({business.reviewCount} Bewertungen)
              </span>
            </div>

            {/* Address */}
            <div className="flex items-start space-x-2 text-muted-foreground">
              <Icon name="MapPin" size={16} className="mt-0.5 flex-shrink-0" />
              <span className="text-sm">{business.address}</span>
            </div>
          </div>

          {/* Favorite Button */}
          <Button
            variant="outline"
            size="sm"
            onClick={() => onFavoriteToggle(business.id)}
            iconName={isFavorite ? "Heart" : "Heart"}
            className={isFavorite ? 'text-error border-error hover:bg-error/10' : ''}
          >
            <Icon 
              name="Heart" 
              size={16} 
              className={isFavorite ? 'fill-current' : ''} 
            />
          </Button>
        </div>

        {/* Price Range & Features */}
        <div className="flex flex-wrap items-center gap-2 mb-4">
          <span className="bg-muted text-muted-foreground px-2 py-1 rounded-md text-sm">
            {business.priceRange}
          </span>
          {business.features.slice(0, 3).map((feature, index) => (
            <span
              key={index}
              className="bg-primary/10 text-primary px-2 py-1 rounded-md text-sm"
            >
              {feature}
            </span>
          ))}
          {business.features.length > 3 && (
            <span className="text-muted-foreground text-sm">
              +{business.features.length - 3} weitere
            </span>
          )}
        </div>

        {/* Special Offers */}
        {business.specialOffers && business.specialOffers.length > 0 && (
          <div className="bg-warning/10 border border-warning/20 rounded-md p-3 mb-4">
            <div className="flex items-center space-x-2 mb-2">
              <Icon name="Tag" size={16} className="text-warning" />
              <span className="font-medium text-warning">Aktuelle Angebote</span>
            </div>
            {business.specialOffers.slice(0, 2).map((offer) => (
              <div key={offer.id} className="text-sm">
                <p className="font-medium text-card-foreground">{offer.title}</p>
                <p className="text-muted-foreground">{offer.description}</p>
                {offer.validUntil && (
                  <p className="text-xs text-warning">Gültig bis: {offer.validUntil}</p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Image Modal */}
      {isImageModalOpen && (
        <div className="fixed inset-0 bg-black/90 z-1020 flex items-center justify-center p-4">
          <div className="relative max-w-4xl max-h-full">
            <button
              onClick={() => setIsImageModalOpen(false)}
              className="absolute top-4 right-4 w-10 h-10 bg-white/20 hover:bg-white/30 text-white rounded-full flex items-center justify-center transition-colors duration-200 z-10"
            >
              <Icon name="X" size={20} />
            </button>
            
            <Image
              src={displayImages[currentImageIndex].url}
              alt={displayImages[currentImageIndex].alt}
              className="max-w-full max-h-full object-contain"
            />
            
            {displayImages.length > 1 && (
              <>
                <button
                  onClick={prevImage}
                  className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/20 hover:bg-white/30 text-white rounded-full flex items-center justify-center transition-colors duration-200"
                >
                  <Icon name="ChevronLeft" size={20} />
                </button>
                <button
                  onClick={nextImage}
                  className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-white/20 hover:bg-white/30 text-white rounded-full flex items-center justify-center transition-colors duration-200"
                >
                  <Icon name="ChevronRight" size={20} />
                </button>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default BusinessHero;