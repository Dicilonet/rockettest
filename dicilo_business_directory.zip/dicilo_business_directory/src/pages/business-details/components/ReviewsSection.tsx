import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import { Review } from '../types';

interface ReviewsSectionProps {
  reviews: Review[];
  averageRating: number;
  totalReviews: number;
  onWriteReview: () => void;
}

const ReviewsSection = ({ 
  reviews, 
  averageRating, 
  totalReviews, 
  onWriteReview 
}: ReviewsSectionProps) => {
  const [filterRating, setFilterRating] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('newest');

  const filterOptions = [
    { value: 'all', label: 'Alle Bewertungen' },
    { value: '5', label: '5 Sterne' },
    { value: '4', label: '4 Sterne' },
    { value: '3', label: '3 Sterne' },
    { value: '2', label: '2 Sterne' },
    { value: '1', label: '1 Stern' }
  ];

  const sortOptions = [
    { value: 'newest', label: 'Neueste zuerst' },
    { value: 'oldest', label: 'Älteste zuerst' },
    { value: 'highest', label: 'Höchste Bewertung' },
    { value: 'lowest', label: 'Niedrigste Bewertung' },
    { value: 'helpful', label: 'Hilfreichste' }
  ];

  const filteredReviews = reviews.filter(review => 
    filterRating === 'all' || review.rating.toString() === filterRating
  );

  const sortedReviews = [...filteredReviews].sort((a, b) => {
    switch (sortBy) {
      case 'oldest':
        return new Date(a.date).getTime() - new Date(b.date).getTime();
      case 'highest':
        return b.rating - a.rating;
      case 'lowest':
        return a.rating - b.rating;
      case 'helpful':
        return b.helpful - a.helpful;
      default: // newest
        return new Date(b.date).getTime() - new Date(a.date).getTime();
    }
  });

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Icon
        key={index}
        name="Star"
        size={14}
        className={index < rating ? 'text-warning fill-current' : 'text-muted-foreground'}
      />
    ));
  };

  const getRatingDistribution = () => {
    const distribution = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
    reviews.forEach(review => {
      distribution[review.rating as keyof typeof distribution]++;
    });
    return distribution;
  };

  const ratingDistribution = getRatingDistribution();

  const handleVote = (reviewId: string, voteType: 'helpful' | 'notHelpful') => {
    // Mock vote handling - in real app, this would make an API call
    console.log(`Voted ${voteType} for review ${reviewId}`);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('de-DE', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="bg-card rounded-lg shadow-sm border border-border p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-card-foreground flex items-center space-x-2">
          <Icon name="Star" size={20} className="text-primary" />
          <span>Bewertungen ({totalReviews})</span>
        </h2>
        <Button
          variant="default"
          size="sm"
          onClick={onWriteReview}
          iconName="Edit"
          iconPosition="left"
        >
          Bewertung schreiben
        </Button>
      </div>

      {/* Rating Overview */}
      <div className="grid md:grid-cols-2 gap-6 mb-6 p-4 bg-muted/30 rounded-lg">
        <div className="text-center">
          <div className="text-4xl font-bold text-card-foreground mb-2">
            {averageRating.toFixed(1)}
          </div>
          <div className="flex items-center justify-center space-x-1 mb-2">
            {renderStars(Math.round(averageRating))}
          </div>
          <p className="text-sm text-muted-foreground">
            Basierend auf {totalReviews} Bewertungen
          </p>
        </div>

        <div className="space-y-2">
          {[5, 4, 3, 2, 1].map(rating => {
            const count = ratingDistribution[rating as keyof typeof ratingDistribution];
            const percentage = totalReviews > 0 ? (count / totalReviews) * 100 : 0;
            
            return (
              <div key={rating} className="flex items-center space-x-2">
                <span className="text-sm w-8">{rating}</span>
                <Icon name="Star" size={12} className="text-warning" />
                <div className="flex-1 bg-muted rounded-full h-2">
                  <div
                    className="bg-warning h-2 rounded-full transition-all duration-300"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
                <span className="text-sm text-muted-foreground w-8">
                  {count}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <Select
          label="Filter nach Bewertung"
          options={filterOptions}
          value={filterRating}
          onChange={setFilterRating}
          className="flex-1"
        />
        <Select
          label="Sortieren nach"
          options={sortOptions}
          value={sortBy}
          onChange={setSortBy}
          className="flex-1"
        />
      </div>

      {/* Reviews List */}
      <div className="space-y-6">
        {sortedReviews.length > 0 ? (
          sortedReviews.map((review) => (
            <div key={review.id} className="border-b border-border pb-6 last:border-b-0">
              <div className="flex items-start space-x-4">
                <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                  {review.userAvatar ? (
                    <img
                      src={review.userAvatar}
                      alt={`${review.userName} Avatar`}
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    <span className="text-sm font-medium text-primary-foreground">
                      {review.userName.charAt(0).toUpperCase()}
                    </span>
                  )}
                </div>

                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h4 className="font-medium text-card-foreground">
                        {review.userName}
                      </h4>
                      <div className="flex items-center space-x-2">
                        <div className="flex items-center space-x-1">
                          {renderStars(review.rating)}
                        </div>
                        <span className="text-sm text-muted-foreground">
                          {formatDate(review.date)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <p className="text-card-foreground mb-4 leading-relaxed">
                    {review.comment}
                  </p>

                  {/* Vote Buttons */}
                  <div className="flex items-center space-x-4">
                    <button
                      onClick={() => handleVote(review.id, 'helpful')}
                      className={`flex items-center space-x-1 text-sm transition-colors duration-200 ${
                        review.userVoteType === 'helpful' ?'text-success' :'text-muted-foreground hover:text-success'
                      }`}
                    >
                      <Icon name="ThumbsUp" size={14} />
                      <span>Hilfreich ({review.helpful})</span>
                    </button>
                    <button
                      onClick={() => handleVote(review.id, 'notHelpful')}
                      className={`flex items-center space-x-1 text-sm transition-colors duration-200 ${
                        review.userVoteType === 'notHelpful' ?'text-error' :'text-muted-foreground hover:text-error'
                      }`}
                    >
                      <Icon name="ThumbsDown" size={14} />
                      <span>Nicht hilfreich ({review.notHelpful})</span>
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8">
            <Icon name="MessageCircle" size={48} className="text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">
              Keine Bewertungen für die ausgewählten Filter gefunden.
            </p>
          </div>
        )}
      </div>

      {/* Load More Button */}
      {sortedReviews.length > 0 && sortedReviews.length < filteredReviews.length && (
        <div className="text-center mt-6">
          <Button variant="outline">
            Mehr Bewertungen laden
          </Button>
        </div>
      )}
    </div>
  );
};

export default ReviewsSection;