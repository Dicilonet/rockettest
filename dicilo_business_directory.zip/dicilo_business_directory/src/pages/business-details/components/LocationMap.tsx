import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Location } from '../types';

interface LocationMapProps {
  location: Location;
  businessName: string;
  address: string;
}

const LocationMap = ({ location, businessName, address }: LocationMapProps) => {
  const handleDirections = () => {
    const encodedAddress = encodeURIComponent(address);
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${encodedAddress}`, '_blank');
  };

  const handleViewInMaps = () => {
    const encodedAddress = encodeURIComponent(address);
    window.open(`https://www.google.com/maps/search/?api=1&query=${encodedAddress}`, '_blank');
  };

  return (
    <div className="bg-card rounded-lg shadow-sm border border-border overflow-hidden">
      <div className="p-6 border-b border-border">
        <h2 className="text-xl font-semibold text-card-foreground mb-4 flex items-center space-x-2">
          <Icon name="MapPin" size={20} className="text-primary" />
          <span>Standort</span>
        </h2>

        <div className="space-y-3 mb-4">
          <div className="flex items-start space-x-3">
            <Icon name="MapPin" size={16} className="text-muted-foreground mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-medium text-card-foreground">{businessName}</p>
              <p className="text-muted-foreground">{address}</p>
              <p className="text-sm text-muted-foreground">
                {location.city}, {location.state} {location.zipCode}
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <Button
            variant="default"
            onClick={handleDirections}
            iconName="Navigation"
            iconPosition="left"
            className="flex-1"
          >
            Route planen
          </Button>
          <Button
            variant="outline"
            onClick={handleViewInMaps}
            iconName="ExternalLink"
            iconPosition="left"
            className="flex-1"
          >
            In Maps öffnen
          </Button>
        </div>
      </div>

      {/* Map Container */}
      <div className="relative h-64 md:h-80 bg-muted">
        <iframe
          width="100%"
          height="100%"
          loading="lazy"
          title={`Standort von ${businessName}`}
          referrerPolicy="no-referrer-when-downgrade"
          src={`https://www.google.com/maps?q=${location.latitude},${location.longitude}&z=15&output=embed`}
          className="border-0"
        />
        
        {/* Map Overlay for Mobile Touch */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm rounded-md px-2 py-1">
            <p className="text-xs text-muted-foreground">
              Zum Interagieren tippen
            </p>
          </div>
        </div>
      </div>

      {/* Location Details */}
      <div className="p-4 bg-muted/30">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div>
            <Icon name="MapPin" size={16} className="text-primary mx-auto mb-1" />
            <p className="text-xs text-muted-foreground">Koordinaten</p>
            <p className="text-sm font-medium text-card-foreground">
              {location.latitude.toFixed(4)}, {location.longitude.toFixed(4)}
            </p>
          </div>
          <div>
            <Icon name="Building" size={16} className="text-primary mx-auto mb-1" />
            <p className="text-xs text-muted-foreground">Stadt</p>
            <p className="text-sm font-medium text-card-foreground">
              {location.city}
            </p>
          </div>
          <div>
            <Icon name="Map" size={16} className="text-primary mx-auto mb-1" />
            <p className="text-xs text-muted-foreground">Bundesland</p>
            <p className="text-sm font-medium text-card-foreground">
              {location.state}
            </p>
          </div>
          <div>
            <Icon name="Hash" size={16} className="text-primary mx-auto mb-1" />
            <p className="text-xs text-muted-foreground">PLZ</p>
            <p className="text-sm font-medium text-card-foreground">
              {location.zipCode}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LocationMap;