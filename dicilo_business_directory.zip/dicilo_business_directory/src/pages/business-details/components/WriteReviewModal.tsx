import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

interface WriteReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  businessName: string;
  onSubmitReview: (review: { rating: number; comment: string; userName: string }) => void;
}

const WriteReviewModal = ({ 
  isOpen, 
  onClose, 
  businessName, 
  onSubmitReview 
}: WriteReviewModalProps) => {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [comment, setComment] = useState('');
  const [userName, setUserName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
      // Reset form
      setRating(0);
      setHoverRating(0);
      setComment('');
      setUserName('');
      setErrors({});
    } else {
      document.body.style.overflow = 'unset';
    }

    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!userName.trim()) {
      newErrors.userName = 'Name ist erforderlich';
    }

    if (rating === 0) {
      newErrors.rating = 'Bitte geben Sie eine Bewertung ab';
    }

    if (!comment.trim()) {
      newErrors.comment = 'Kommentar ist erforderlich';
    } else if (comment.trim().length < 10) {
      newErrors.comment = 'Kommentar muss mindestens 10 Zeichen lang sein';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      onSubmitReview({
        rating,
        comment: comment.trim(),
        userName: userName.trim()
      });

      onClose();
    } catch (error) {
      setErrors({ general: 'Ein Fehler ist aufgetreten. Bitte versuchen Sie es erneut.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  const renderStars = () => {
    return Array.from({ length: 5 }, (_, index) => {
      const starValue = index + 1;
      const isActive = starValue <= (hoverRating || rating);
      
      return (
        <button
          key={index}
          type="button"
          onClick={() => setRating(starValue)}
          onMouseEnter={() => setHoverRating(starValue)}
          onMouseLeave={() => setHoverRating(0)}
          className="p-1 transition-colors duration-200 hover:scale-110"
        >
          <Icon
            name="Star"
            size={24}
            className={isActive ? 'text-warning fill-current' : 'text-muted-foreground hover:text-warning'}
          />
        </button>
      );
    });
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-1020 animate-fade-in"
      onClick={handleOverlayClick}
    >
      <div className="bg-card rounded-lg shadow-xl w-full max-w-md max-h-[90vh] overflow-y-auto animate-scale-in">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-xl font-semibold text-card-foreground">
                Bewertung schreiben
              </h2>
              <p className="text-sm text-muted-foreground">
                für {businessName}
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-md hover:bg-muted transition-colors duration-200"
            >
              <Icon name="X" size={20} />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {errors.general && (
              <div className="p-3 bg-error/10 border border-error/20 rounded-md">
                <p className="text-sm text-error">{errors.general}</p>
              </div>
            )}

            {/* Name Input */}
            <Input
              label="Ihr Name"
              type="text"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              error={errors.userName}
              placeholder="Geben Sie Ihren Namen ein"
              required
            />

            {/* Rating */}
            <div>
              <label className="block text-sm font-medium text-card-foreground mb-2">
                Bewertung *
              </label>
              <div className="flex items-center space-x-1 mb-2">
                {renderStars()}
              </div>
              {rating > 0 && (
                <p className="text-sm text-muted-foreground">
                  {rating === 1 && 'Sehr schlecht'}
                  {rating === 2 && 'Schlecht'}
                  {rating === 3 && 'Durchschnittlich'}
                  {rating === 4 && 'Gut'}
                  {rating === 5 && 'Ausgezeichnet'}
                </p>
              )}
              {errors.rating && (
                <p className="text-sm text-error mt-1">{errors.rating}</p>
              )}
            </div>

            {/* Comment */}
            <div>
              <label className="block text-sm font-medium text-card-foreground mb-2">
                Ihr Kommentar *
              </label>
              <textarea
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                placeholder="Teilen Sie Ihre Erfahrungen mit diesem Unternehmen..."
                rows={4}
                className="w-full px-3 py-2 border border-border rounded-md focus:outline-none focus:ring-2 focus:ring-ring focus:border-transparent resize-none"
              />
              <div className="flex justify-between items-center mt-1">
                {errors.comment && (
                  <p className="text-sm text-error">{errors.comment}</p>
                )}
                <p className="text-xs text-muted-foreground ml-auto">
                  {comment.length}/500 Zeichen
                </p>
              </div>
            </div>

            {/* Guidelines */}
            <div className="bg-muted/30 rounded-md p-3">
              <h4 className="text-sm font-medium text-card-foreground mb-2 flex items-center space-x-1">
                <Icon name="Info" size={14} />
                <span>Bewertungsrichtlinien</span>
              </h4>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Seien Sie ehrlich und konstruktiv</li>
                <li>• Beschreiben Sie Ihre persönlichen Erfahrungen</li>
                <li>• Vermeiden Sie beleidigende Sprache</li>
                <li>• Respektieren Sie die Privatsphäre anderer</li>
              </ul>
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              variant="default"
              fullWidth
              loading={isSubmitting}
              disabled={rating === 0 || !comment.trim() || !userName.trim()}
            >
              Bewertung veröffentlichen
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default WriteReviewModal;