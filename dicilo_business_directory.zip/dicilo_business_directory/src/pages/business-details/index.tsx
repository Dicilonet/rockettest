import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import MainHeader from '../../components/ui/MainHeader';
import BusinessNavigationBreadcrumbs from '../../components/ui/BusinessNavigationBreadcrumbs';
import AuthenticationModal from '../../components/ui/AuthenticationModal';
import BusinessHero from './components/BusinessHero';
import ContactSection from './components/ContactSection';
import OperatingHours from './components/OperatingHours';
import ReviewsSection from './components/ReviewsSection';
import LocationMap from './components/LocationMap';
import RelatedBusinesses from './components/RelatedBusinesses';
import WriteReviewModal from './components/WriteReviewModal';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import { Business, Review, RelatedBusiness } from './types';
import { businessService } from '../../services/businessService';
import { reviewService } from '../../services/reviewService';

// Helper function to validate UUID format
const isValidUUID = (id: string): boolean => {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(id);
};

const BusinessDetailsPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, profile, signIn, signOut } = useAuth();
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [writeReviewModalOpen, setWriteReviewModalOpen] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [business, setBusiness] = useState<Business | null>(null);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [relatedBusinesses, setRelatedBusinesses] = useState<RelatedBusiness[]>([]);
  const [error, setError] = useState<string | null>(null);

  // Validate business ID from URL parameters
  const businessIdParam = searchParams.get('id');
  const businessId = businessIdParam && isValidUUID(businessIdParam) ? businessIdParam : null;

  useEffect(() => {
    if (businessId) {
      loadBusinessData();
    } else {
      setError('Ungültige oder fehlende Unternehmens-ID');
      setIsLoading(false);
    }
  }, [businessId]);

  useEffect(() => {
    // Load favorites from localStorage
    const savedFavorites = localStorage.getItem('favorites');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
  }, []);

  const loadBusinessData = async () => {
    if (!businessId) {
      setError('Keine gültige Unternehmens-ID gefunden');
      setIsLoading(false);
      return;
    }

    try {
      setIsLoading(true);
      setError(null);

      // Load business details
      const businessData = await businessService.getBusinessById(businessId);
      if (!businessData) {
        setError('Unternehmen nicht gefunden');
        return;
      }
      setBusiness(businessData);

      // Load reviews
      const reviewsData = await reviewService.getBusinessReviews(businessId);
      setReviews(reviewsData);

      // Load related businesses (simplified - just get other businesses)
      const allBusinesses = await businessService.getAllBusinesses();
      const related = allBusinesses
        .filter(b => b.id !== businessId)
        .slice(0, 3)
        .map(b => ({
          id: b.id,
          name: b.name,
          category: b.category,
          rating: b.rating,
          reviewCount: b.reviewCount,
          image: b.images[0]?.url || "https://images.unsplash.com/photo-1560472354-b33ff0c44a43",
          alt: b.images[0]?.alt || `${b.name} Bild`,
          distance: '0.5 km' // This would be calculated based on location
        }));
      setRelatedBusinesses(related);

    } catch (err: any) {
      console.error('Error loading business data:', err);
      if (err.message?.includes('invalid input syntax for type uuid')) {
        setError('Ungültige Unternehmens-ID Format');
      } else {
        setError('Fehler beim Laden der Daten');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogin = () => {
    setAuthMode('login');
    setAuthModalOpen(true);
  };

  const handleLogout = async () => {
    const { error } = await signOut();
    if (!error) {
      localStorage.removeItem('favorites');
      setFavorites([]);
    }
  };

  const handleAuthenticate = async (userData: { email: string; password: string; fullName?: string }) => {
    try {
      const { error } = await signIn(userData.email, userData.password);
      if (!error) {
        setAuthModalOpen(false);
      } else {
        console.error('Authentication error:', error);
      }
    } catch (err) {
      console.error('Authentication error:', err);
    }
  };

  const handleFavoriteToggle = (businessId: string) => {
    if (!user) {
      setAuthModalOpen(true);
      return;
    }

    const newFavorites = favorites.includes(businessId) ?
      favorites.filter((id) => id !== businessId) :
      [...favorites, businessId];

    setFavorites(newFavorites);
    localStorage.setItem('favorites', JSON.stringify(newFavorites));
  };

  const handleWriteReview = () => {
    if (!user) {
      setAuthModalOpen(true);
      return;
    }
    setWriteReviewModalOpen(true);
  };

  const handleSubmitReview = async (reviewData: {rating: number; comment: string; userName: string;}) => {
    if (!business) return;

    try {
      const { error } = await reviewService.createReview(
        business.id, 
        reviewData.rating, 
        reviewData.comment
      );

      if (!error) {
        setWriteReviewModalOpen(false);
        // Reload reviews and business data to get updated ratings
        await loadBusinessData();
      } else {
        console.error('Error submitting review:', error);
      }
    } catch (err) {
      console.error('Error submitting review:', err);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <MainHeader
          isAuthenticated={!!user}
          user={profile}
          onLogin={handleLogin}
          onLogout={handleLogout} />

        <div className="pt-16 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-muted-foreground">Lade Unternehmensdetails...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error || !business) {
    return (
      <div className="min-h-screen bg-background">
        <MainHeader
          isAuthenticated={!!user}
          user={profile}
          onLogin={handleLogin}
          onLogout={handleLogout} />

        <div className="pt-16 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <Icon name="AlertCircle" size={48} className="text-error mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-foreground mb-2">
              {error || 'Unternehmen nicht gefunden'}
            </h2>
            <p className="text-muted-foreground mb-4">
              Das angeforderte Unternehmen konnte nicht geladen werden.
            </p>
            <Button onClick={() => navigate('/business-directory')} iconName="ArrowLeft" iconPosition="left">
              Zurück zur Übersicht
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <MainHeader
        isAuthenticated={!!user}
        user={profile}
        onLogin={handleLogin}
        onLogout={handleLogout} />

      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 lg:px-6 py-6">
          {/* Breadcrumbs */}
          <BusinessNavigationBreadcrumbs
            businessName={business.name}
            location={searchParams.get('location') || undefined}
            searchQuery={searchParams.get('search') || undefined}
            category={searchParams.get('category') || undefined} />

          {/* Back Button */}
          <div className="mb-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate(-1)}
              iconName="ArrowLeft"
              iconPosition="left">
              Zurück zu den Ergebnissen
            </Button>
          </div>

          {/* Main Content */}
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Left Column - Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Business Hero */}
              <BusinessHero
                business={business}
                onFavoriteToggle={handleFavoriteToggle}
                isFavorite={favorites.includes(business.id)} />

              {/* Business Description */}
              <div className="bg-card rounded-lg shadow-sm border border-border p-6">
                <h2 className="text-xl font-semibold text-card-foreground mb-4 flex items-center space-x-2">
                  <Icon name="FileText" size={20} className="text-primary" />
                  <span>Über uns</span>
                </h2>
                <div className="prose prose-sm max-w-none">
                  {business.description.split('\n\n').map((paragraph, index) =>
                    <p key={index} className="text-card-foreground leading-relaxed mb-4 last:mb-0">
                      {paragraph}
                    </p>
                  )}
                </div>
              </div>

              {/* Reviews Section */}
              <ReviewsSection
                reviews={reviews}
                averageRating={business.rating}
                totalReviews={business.reviewCount}
                onWriteReview={handleWriteReview} />

              {/* Location Map */}
              <LocationMap
                location={business.location}
                businessName={business.name}
                address={business.address} />
            </div>

            {/* Right Column - Sidebar */}
            <div className="space-y-6">
              {/* Contact Section */}
              <ContactSection business={business} />

              {/* Operating Hours */}
              <OperatingHours operatingHours={business.operatingHours} />

              {/* Quick Actions Module */}
              <div className="bg-card rounded-lg shadow-sm border border-border p-6">
                <h3 className="text-lg font-semibold text-card-foreground mb-4">
                  Schnellaktionen
                </h3>
                <div className="space-y-3">
                  <Button
                    variant="outline"
                    fullWidth
                    onClick={handleWriteReview}
                    iconName="Edit"
                    iconPosition="left">
                    Bewertung schreiben
                  </Button>
                  <Button
                    variant="outline"
                    fullWidth
                    onClick={() => handleFavoriteToggle(business.id)}
                    iconName="Heart"
                    iconPosition="left"
                    className={favorites.includes(business.id) ? 'text-error border-error' : ''}>
                    {favorites.includes(business.id) ? 'Aus Favoriten entfernen' : 'Zu Favoriten hinzufügen'}
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Related Businesses */}
          <div className="mt-12">
            <RelatedBusinesses
              businesses={relatedBusinesses}
              currentBusinessId={business.id} />
          </div>
        </div>
      </main>

      {/* Authentication Modal */}
      <AuthenticationModal
        isOpen={authModalOpen}
        mode={authMode}
        onClose={() => setAuthModalOpen(false)}
        onModeChange={setAuthMode}
        onAuthenticate={handleAuthenticate} />

      {/* Write Review Modal */}
      <WriteReviewModal
        isOpen={writeReviewModalOpen}
        onClose={() => setWriteReviewModalOpen(false)}
        businessName={business.name}
        onSubmitReview={handleSubmitReview} />
    </div>
  );
};

export default BusinessDetailsPage;