export interface Business {
  id: string;
  name: string;
  category: string;
  rating: number;
  reviewCount: number;
  address: string;
  phone: string;
  website?: string;
  email?: string;
  description: string;
  images: BusinessImage[];
  operatingHours: OperatingHours;
  location: Location;
  socialMedia?: SocialMedia;
  features: string[];
  priceRange: string;
  verified: boolean;
  specialOffers?: SpecialOffer[];
}

export interface BusinessImage {
  id: string;
  url: string;
  alt: string;
  isPrimary: boolean;
  category: 'exterior' | 'interior' | 'product' | 'team' | 'other';
}

export interface OperatingHours {
  monday: DayHours;
  tuesday: DayHours;
  wednesday: DayHours;
  thursday: DayHours;
  friday: DayHours;
  saturday: DayHours;
  sunday: DayHours;
}

export interface DayHours {
  isOpen: boolean;
  openTime?: string;
  closeTime?: string;
  isCurrentDay?: boolean;
}

export interface Location {
  latitude: number;
  longitude: number;
  city: string;
  state: string;
  zipCode: string;
  country: string;
}

export interface SocialMedia {
  facebook?: string;
  instagram?: string;
  twitter?: string;
  linkedin?: string;
}

export interface SpecialOffer {
  id: string;
  title: string;
  description: string;
  validUntil: string;
  discount?: string;
}

export interface Review {
  id: string;
  userName: string;
  userAvatar?: string;
  rating: number;
  comment: string;
  date: string;
  helpful: number;
  notHelpful: number;
  userHasVoted?: boolean;
  userVoteType?: 'helpful' | 'notHelpful';
}

export interface RelatedBusiness {
  id: string;
  name: string;
  category: string;
  rating: number;
  reviewCount: number;
  image: string;
  alt: string;
  distance: string;
}

export interface ContactAction {
  type: 'phone' | 'website' | 'email' | 'directions';
  label: string;
  value: string;
  icon: string;
}