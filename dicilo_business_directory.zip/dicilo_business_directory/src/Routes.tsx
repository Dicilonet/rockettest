import React from 'react';
import { BrowserRouter, Routes as RouterRoutes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import ErrorBoundary from './components/ErrorBoundary';
import ScrollToTop from './components/ScrollToTop';

// Import pages
import BusinessDirectoryPage from './pages/business-directory';
import SearchResultsPage from './pages/search-results';
import BusinessDetailsPage from './pages/business-details';
import LoginPage from './pages/login';
import RegisterPage from './pages/register';
import UserProfilePage from './pages/user-profile';
import AdminDashboard from './pages/admin-dashboard';
import NotFound from './pages/NotFound';

const Routes = () => {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ErrorBoundary>
          <ScrollToTop />
          <RouterRoutes>
            <Route path="/" element={<BusinessDirectoryPage />} />
            <Route path="/business-directory" element={<BusinessDirectoryPage />} />
            <Route path="/search-results" element={<SearchResultsPage />} />
            <Route path="/business-details" element={<BusinessDetailsPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/user-profile" element={<UserProfilePage />} />
            <Route path="/admin-dashboard" element={<AdminDashboard />} />
            <Route path="*" element={<NotFound />} />
          </RouterRoutes>
        </ErrorBoundary>
      </AuthProvider>
    </BrowserRouter>
  );
};

export default Routes;