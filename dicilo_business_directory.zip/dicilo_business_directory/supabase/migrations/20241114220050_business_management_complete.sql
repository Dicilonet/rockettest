-- Location: supabase/migrations/20241114220050_business_management_complete.sql
-- Schema Analysis: Empty database (FRESH_PROJECT)
-- Integration Type: Complete business management system with auth
-- Dependencies: None (fresh start)

-- 1. Types and Enums
CREATE TYPE public.user_role AS ENUM ('superadmin', 'admin', 'manager', 'user');
CREATE TYPE public.business_status AS ENUM ('active', 'inactive', 'pending', 'suspended');
CREATE TYPE public.image_category AS ENUM ('exterior', 'interior', 'product', 'team', 'other');

-- 2. Core Tables
-- User profiles table (intermediary for auth.users)
CREATE TABLE public.user_profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id),
    email TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    role public.user_role DEFAULT 'user'::public.user_role,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Business categories
CREATE TABLE public.business_categories (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL UNIQUE,
    name_de TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Main businesses table
CREATE TABLE public.businesses (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    category_id UUID REFERENCES public.business_categories(id) ON DELETE SET NULL,
    rating DECIMAL(2,1) DEFAULT 0.0,
    review_count INTEGER DEFAULT 0,
    address TEXT NOT NULL,
    phone TEXT,
    website TEXT,
    email TEXT,
    description TEXT,
    price_range TEXT,
    verified BOOLEAN DEFAULT false,
    status public.business_status DEFAULT 'active'::public.business_status,
    latitude DECIMAL(10,8),
    longitude DECIMAL(11,8),
    city TEXT,
    state TEXT,
    zip_code TEXT,
    country TEXT DEFAULT 'Deutschland',
    features TEXT[],
    social_facebook TEXT,
    social_instagram TEXT,
    social_twitter TEXT,
    social_linkedin TEXT,
    created_by UUID REFERENCES public.user_profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Business images
CREATE TABLE public.business_images (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID REFERENCES public.businesses(id) ON DELETE CASCADE,
    url TEXT NOT NULL,
    alt_text TEXT NOT NULL,
    is_primary BOOLEAN DEFAULT false,
    category public.image_category DEFAULT 'other'::public.image_category,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Operating hours
CREATE TABLE public.business_hours (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID REFERENCES public.businesses(id) ON DELETE CASCADE,
    day_of_week INTEGER NOT NULL CHECK (day_of_week >= 0 AND day_of_week <= 6),
    is_open BOOLEAN DEFAULT true,
    open_time TIME,
    close_time TIME,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Special offers
CREATE TABLE public.special_offers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID REFERENCES public.businesses(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    discount TEXT,
    valid_until DATE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Reviews table
CREATE TABLE public.reviews (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    business_id UUID REFERENCES public.businesses(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    helpful_count INTEGER DEFAULT 0,
    not_helpful_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Review votes
CREATE TABLE public.review_votes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    review_id UUID REFERENCES public.reviews(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    vote_type TEXT CHECK (vote_type IN ('helpful', 'not_helpful')),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(review_id, user_id)
);

-- Favorites
CREATE TABLE public.user_favorites (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.user_profiles(id) ON DELETE CASCADE,
    business_id UUID REFERENCES public.businesses(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, business_id)
);

-- 3. Indexes
CREATE INDEX idx_user_profiles_email ON public.user_profiles(email);
CREATE INDEX idx_user_profiles_role ON public.user_profiles(role);
CREATE INDEX idx_businesses_category ON public.businesses(category_id);
CREATE INDEX idx_businesses_status ON public.businesses(status);
CREATE INDEX idx_businesses_location ON public.businesses(latitude, longitude);
CREATE INDEX idx_business_images_business_id ON public.business_images(business_id);
CREATE INDEX idx_business_hours_business_id ON public.business_hours(business_id);
CREATE INDEX idx_reviews_business_id ON public.reviews(business_id);
CREATE INDEX idx_reviews_user_id ON public.reviews(user_id);
CREATE INDEX idx_review_votes_review_id ON public.review_votes(review_id);
CREATE INDEX idx_user_favorites_user_id ON public.user_favorites(user_id);

-- 4. Functions (MUST BE BEFORE RLS POLICIES)
-- Function for superadmin role check
CREATE OR REPLACE FUNCTION public.is_superadmin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM auth.users au
    WHERE au.id = auth.uid() 
    AND (au.raw_user_meta_data->>'role' = 'superadmin' 
         OR au.raw_app_meta_data->>'role' = 'superadmin')
)
$$;

-- Function for admin role check (superadmin or admin)
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM auth.users au
    WHERE au.id = auth.uid() 
    AND (au.raw_user_meta_data->>'role' IN ('superadmin', 'admin')
         OR au.raw_app_meta_data->>'role' IN ('superadmin', 'admin'))
)
$$;

-- Trigger function for auto profile creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO public.user_profiles (id, email, full_name, role)
    VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
        COALESCE(NEW.raw_user_meta_data->>'role', 'user')::public.user_role
    );
    RETURN NEW;
END;
$$;

-- 5. Enable RLS
ALTER TABLE public.user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.business_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.businesses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.business_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.business_hours ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.special_offers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.review_votes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_favorites ENABLE ROW LEVEL SECURITY;

-- 6. RLS Policies
-- User profiles - Pattern 1 (Core User Table)
CREATE POLICY "users_manage_own_user_profiles"
ON public.user_profiles
FOR ALL
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- Business categories - Public read, admin write
CREATE POLICY "public_can_read_business_categories"
ON public.business_categories
FOR SELECT
TO public
USING (true);

CREATE POLICY "admins_manage_business_categories"
ON public.business_categories
FOR ALL
TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- Businesses - Public read, admin/superadmin write
CREATE POLICY "public_can_read_businesses"
ON public.businesses
FOR SELECT
TO public
USING (status = 'active'::public.business_status);

CREATE POLICY "admins_manage_businesses"
ON public.businesses
FOR ALL
TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- Business images - Public read, admin write
CREATE POLICY "public_can_read_business_images"
ON public.business_images
FOR SELECT
TO public
USING (true);

CREATE POLICY "admins_manage_business_images"
ON public.business_images
FOR ALL
TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- Business hours - Public read, admin write
CREATE POLICY "public_can_read_business_hours"
ON public.business_hours
FOR SELECT
TO public
USING (true);

CREATE POLICY "admins_manage_business_hours"
ON public.business_hours
FOR ALL
TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- Special offers - Public read, admin write
CREATE POLICY "public_can_read_special_offers"
ON public.special_offers
FOR SELECT
TO public
USING (true);

CREATE POLICY "admins_manage_special_offers"
ON public.special_offers
FOR ALL
TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- Reviews - Pattern 2 (Simple User Ownership)
CREATE POLICY "users_manage_own_reviews"
ON public.reviews
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "public_can_read_reviews"
ON public.reviews
FOR SELECT
TO public
USING (true);

-- Review votes - Pattern 2 (Simple User Ownership)
CREATE POLICY "users_manage_own_review_votes"
ON public.review_votes
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- User favorites - Pattern 2 (Simple User Ownership)
CREATE POLICY "users_manage_own_favorites"
ON public.user_favorites
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 7. Triggers
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 8. Mock Data
DO $$
DECLARE
    superadmin_id UUID := gen_random_uuid();
    admin_id UUID := gen_random_uuid();
    user_id UUID := gen_random_uuid();
    cafe_category_id UUID := gen_random_uuid();
    restaurant_category_id UUID := gen_random_uuid();
    business1_id UUID := gen_random_uuid();
    business2_id UUID := gen_random_uuid();
    review_id UUID;
BEGIN
    -- Create auth users with complete fields
    INSERT INTO auth.users (
        id, instance_id, aud, role, email, encrypted_password, email_confirmed_at,
        created_at, updated_at, raw_user_meta_data, raw_app_meta_data,
        is_sso_user, is_anonymous, confirmation_token, confirmation_sent_at,
        recovery_token, recovery_sent_at, email_change_token_new, email_change,
        email_change_sent_at, email_change_token_current, email_change_confirm_status,
        reauthentication_token, reauthentication_sent_at, phone, phone_change,
        phone_change_token, phone_change_sent_at
    ) VALUES
        (superadmin_id, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'superadmin@dicilo.net', crypt('admin123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Superadmin User", "role": "superadmin"}'::jsonb, '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (admin_id, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'admin@dicilo.net', crypt('admin123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Admin User", "role": "admin"}'::jsonb, '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null),
        (user_id, '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated',
         'user@dicilo.net', crypt('user123', gen_salt('bf', 10)), now(), now(), now(),
         '{"full_name": "Regular User", "role": "user"}'::jsonb, '{"provider": "email", "providers": ["email"]}'::jsonb,
         false, false, '', null, '', null, '', '', null, '', 0, '', null, null, '', '', null);

    -- Insert categories with German names
    INSERT INTO public.business_categories (id, name, name_de) VALUES
        (cafe_category_id, 'Cafe & Restaurant', 'Café & Restaurant'),
        (restaurant_category_id, 'Restaurant', 'Restaurant'),
        (gen_random_uuid(), 'Consulting', 'Beratung'),
        (gen_random_uuid(), 'Education', 'Bildung'),
        (gen_random_uuid(), 'Financial Services', 'Finanzdienste'),
        (gen_random_uuid(), 'Gastronomy', 'Gastronomie'),
        (gen_random_uuid(), 'Health', 'Gesundheit'),
        (gen_random_uuid(), 'Hotels', 'Hotellerie'),
        (gen_random_uuid(), 'Real Estate', 'Immobilien'),
        (gen_random_uuid(), 'Clothing', 'Kleidung'),
        (gen_random_uuid(), 'Food', 'Lebensmittel'),
        (gen_random_uuid(), 'Music', 'Musik'),
        (gen_random_uuid(), 'Social', 'Soziales'),
        (gen_random_uuid(), 'Sports', 'Sport'),
        (gen_random_uuid(), 'Travel', 'Travel'),
        (gen_random_uuid(), 'Technology', 'Technologie'),
        (gen_random_uuid(), 'Pets', 'Tier'),
        (gen_random_uuid(), 'Transport', 'Transport'),
        (gen_random_uuid(), 'Environment', 'Umwelt'),
        (gen_random_uuid(), 'Entertainment', 'Unterhaltung');

    -- Insert sample businesses
    INSERT INTO public.businesses (
        id, name, category_id, rating, review_count, address, phone, website, email,
        description, price_range, verified, latitude, longitude, city, state, zip_code,
        country, features, social_facebook, social_instagram, created_by
    ) VALUES
        (business1_id, 'Café Münchner Freiheit', cafe_category_id, 4.6, 127, 
         'Münchner Freiheit 15, 80802 München', '+49 89 123456789', 
         'www.cafe-muenchner-freiheit.de', 'info@cafe-muenchner-freiheit.de',
         'Willkommen im Café Münchner Freiheit - Ihrem gemütlichen Treffpunkt im Herzen von Schwabing! Seit über 20 Jahren verwöhnen wir unsere Gäste mit frisch geröstetem Kaffee, hausgemachten Kuchen und einer warmen, einladenden Atmosphäre.',
         '€€ (10-25€)', true, 48.1641, 11.5754, 'München', 'Bayern', '80802', 'Deutschland',
         ARRAY['WLAN kostenlos', 'Terrasse', 'Hausgemachte Kuchen', 'Vegane Optionen'],
         'https://facebook.com/cafe-muenchner-freiheit', 'https://instagram.com/cafe_muenchner_freiheit',
         superadmin_id),
        (business2_id, 'Restaurant Schwabing', restaurant_category_id, 4.7, 156,
         'Leopoldstraße 25, 80802 München', '+49 89 987654321',
         'www.restaurant-schwabing.de', 'info@restaurant-schwabing.de',
         'Elegantes Restaurant mit moderner deutscher Küche und internationalen Einflüssen. Perfekt für besondere Anlässe und Geschäftsessen.',
         '€€€ (25-50€)', true, 48.1650, 11.5760, 'München', 'Bayern', '80802', 'Deutschland',
         ARRAY['Reservierungen', 'Terrasse', 'Internationale Küche', 'Weinauswahl'],
         'https://facebook.com/restaurant-schwabing', 'https://instagram.com/restaurant_schwabing',
         admin_id);

    -- Insert business images
    INSERT INTO public.business_images (business_id, url, alt_text, is_primary, category) VALUES
        (business1_id, 'https://images.unsplash.com/photo-1562835155-1fa627c69744', 
         'Gemütliches Café-Interieur mit warmer Beleuchtung und Holzmöbeln', true, 'interior'),
        (business1_id, 'https://images.unsplash.com/photo-1680016790934-3a091d1d6ed4',
         'Frisch gebackene Croissants und Gebäck in der Vitrine', false, 'product'),
        (business2_id, 'https://images.unsplash.com/photo-1647695822638-a40e238ddc39',
         'Elegantes Restaurant mit moderner Einrichtung und gedämpfter Beleuchtung', true, 'interior');

    -- Insert operating hours (0=Sunday, 1=Monday, ..., 6=Saturday)
    INSERT INTO public.business_hours (business_id, day_of_week, is_open, open_time, close_time) VALUES
        (business1_id, 1, true, '07:00', '19:00'), -- Monday
        (business1_id, 2, true, '07:00', '19:00'), -- Tuesday
        (business1_id, 3, true, '07:00', '19:00'), -- Wednesday
        (business1_id, 4, true, '07:00', '20:00'), -- Thursday
        (business1_id, 5, true, '07:00', '20:00'), -- Friday
        (business1_id, 6, true, '08:00', '20:00'), -- Saturday
        (business1_id, 0, true, '09:00', '18:00'), -- Sunday
        (business2_id, 1, true, '17:00', '23:00'), -- Monday
        (business2_id, 2, true, '17:00', '23:00'), -- Tuesday
        (business2_id, 3, true, '17:00', '23:00'), -- Wednesday
        (business2_id, 4, true, '17:00', '23:00'), -- Thursday
        (business2_id, 5, true, '17:00', '24:00'), -- Friday
        (business2_id, 6, true, '17:00', '24:00'), -- Saturday
        (business2_id, 0, false, null, null); -- Sunday (closed)

    -- Insert special offers
    INSERT INTO public.special_offers (business_id, title, description, discount, valid_until) VALUES
        (business1_id, 'Happy Hour Kaffee', 'Alle Kaffeespezialitäten 20% günstiger zwischen 14:00-16:00 Uhr', '20%', '2024-12-31');

    -- Insert sample reviews
    INSERT INTO public.reviews (business_id, user_id, rating, comment, helpful_count, not_helpful_count) VALUES
        (business1_id, user_id, 5, 'Absolut fantastisches Café! Der Kaffee ist hervorragend und die hausgemachten Kuchen sind ein Traum.', 12, 1),
        (business2_id, user_id, 4, 'Sehr gemütliches Restaurant mit guter Auswahl. Die Preise sind fair und die Qualität stimmt.', 8, 0);

END $$;

-- Update business review counts
UPDATE public.businesses 
SET review_count = (SELECT COUNT(*) FROM public.reviews WHERE business_id = businesses.id),
    rating = (SELECT COALESCE(AVG(rating), 0) FROM public.reviews WHERE business_id = businesses.id);